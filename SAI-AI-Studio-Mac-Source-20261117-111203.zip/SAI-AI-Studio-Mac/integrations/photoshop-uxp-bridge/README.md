# SAI AI Studio Photoshop UXP Bridge

This is the Photoshop-side bridge for SAI AI Studio.

## Windows setup

The Windows installer offers SAI 2 and Photoshop UXP editions. Choose Photoshop
UXP, select the folder containing `Photoshop.exe`, and close Photoshop before
continuing. Setup checks Photoshop 24.4+ and installs into the selected host's
`Plug-ins/SAI AI Studio Bridge` folder for all versions, including 27.11.0.
There is no version-based redirection to a shared UXP folder.
It also grants the installing Windows account
permission to use the loopback bridge address; this can require administrator
approval. Open the panel from Photoshop's Plugins menu after installation.

For an upgrade, close Photoshop and run setup again. Setup directly replaces the
four files belonging to this plugin even if they differ from the old installation
receipt; moving or deleting the plugin directory manually is unnecessary. Other
files in the directory are kept.

The existing Photoshop 2025 folder installation has been validated manually.
Other host versions and a clean machine without .NET still need manual acceptance.
The panel supports selection capture, full-canvas capture, and image fill-back.

## Updating to 0.2.5 / Photoshop 27.11.0

Version 0.2.5 fixes a startup failure in 0.2.4. The 27.11.0 host log reported
`create method is not defined for plugin`: registering plugin destroy without
plugin create aborted main.js before startup. Both hooks are now present, and
the lifecycle regression rejects the incomplete definition before packaging.
While the first network request is pending, the panel displays Connecting
instead of remaining at Starting.

Installer 1.1.11.4 restores the host-local Plug-ins installation for every version.
The earlier assumption that 27.9+ requires the shared External folder was not
established by the host log. The confirmed startup error was the missing create
hook described above. Shared-folder copies installed by 1.1.11.2/1.1.11.3 are
left untouched by that installer. New builds detect copies with this plugin's ID
in the old shared locations and stop before changing the plugin or loopback
permissions. The error lists the conflicting folders: close Photoshop, move
those folders outside Adobe's plugin scan folders as backups, then retry setup.
An unrelated plugin in a same-named folder is left alone.

The panel explicitly declares Photoshop API v2 and initializes through UXP
panel create/show hooks as well as DOMContentLoaded. Reopening the panel keeps
the pause state and does not create duplicate command polling loops.

For a manual folder install on 27.11.0, close Photoshop and copy the entire
`SAI AI Studio Bridge` folder into the selected Photoshop's `Plug-ins` folder, then restart
Photoshop and open Plugins > SAI AI Studio Bridge. If the host does not discover
folder installs (for example, its registered plugin list overrides fallback
scanning), use Adobe UPIA/Creative Cloud to install the CCX package, or UXP
Developer Tool to load manifest.json for development. Do not change unrelated
Adobe plugin registry files.

Automated checks: `node scripts/Test-PhotoshopUxpLifecycle.cjs`,
`node scripts/Test-PhotoshopUxp.cjs`, and installer upgrade tests cover panel
startup, command behavior, and host-local target paths. Actual discovery,
selection capture, and transparent pixel-layer fill-back on 27.11.0 still require
live acceptance; automated mocks are not proof of host compatibility.

Both `scripts/package-photoshop-uxp.ps1` and `scripts/Build-WindowsInstaller.ps1`
require Node.js and run the lifecycle and command regressions before creating
output or downloading build dependencies. Either test failing stops packaging
and leaves existing packages untouched. To verify these build guards in isolated
fixtures, run `node scripts/Test-PhotoshopUxpPackaging.cjs`.

## Updating to 0.2.3

Update Studio and the panel together. Captures now return the source document ID,
name, canvas size, and a session identifier that changes when the panel reloads.
Automatic generation results return to that document even while another document
is active, including when both documents have the same name. The previously active
document is restored after fill-back. Closing the source, changing its full-canvas
dimensions, or reloading Photoshop/the panel stops automatic insertion; the image
stays in Studio output/history. History's manual Add to Canvas uses the current
document instead. Source references are not stored in the history database.

Bound insertion uses `pasteImageToDocument`; older panels reject this command
instead of ignoring its target and writing to another document. Studio asks for
a panel update if capture results lack source identity.

For live document-target acceptance, run
`node scripts/Build-PhotoshopDocumentTargetLiveTest.cjs`, then select the generated
`artifacts/photoshop-document-target-live/DocumentTargetLive.psjs` from Photoshop's
File > Scripts > Browse menu. It embeds the current plugin code, creates its own
temporary documents, reports checks in a dialog, closes only those documents,
and restores the previously active document. It does not reload the installed
panel. A successful simulated regression run does not substitute for this test.

## Pixel-layer fill-back (0.2.2 and later)

Version 0.2.2 replaces smart-object placement with native pixel-layer fill-back.
The PNG is decoded in a temporary document, then the Imaging API writes its pixels
to a new layer without DPI conversion or automatic fit-to-canvas scaling. Alpha
and trimmed transparent margins retain their original positions. Full-canvas
results align to the canvas origin; ordinary paste centers the image at its
original pixel dimensions. The insertion is one undo step.

Update Studio together with the panel: the built-in workspace now keeps the
Photoshop selection bounds and canvas size captured before generation, just as
the direct backend workflow already does.

Update the installed Photoshop plugin files or install the new CCX package, then
restart Photoshop and open the bridge panel. Open the original Photoshop document
and retry Fill Back on the saved Studio result; a new AI generation is not required.

## Simple install for testing

1. Start SAI AI Studio so the local command server is listening on `127.0.0.1:47872`.
2. Run:
   `scripts\install-photoshop-uxp.bat`
3. Restart Photoshop, or reopen the Photoshop `Plugins` menu if Photoshop was already running.
4. Open the `SAI AI Studio Bridge` panel from Photoshop's `Plugins` menu.
5. The panel should show it is connected to Studio.

The installer script packages this plugin as:

`test-dist\photoshop-uxp-bridge\SAI-AI-Studio-Photoshop-Bridge.ccx`

It then tries Adobe Unified Plugin Installer Agent first. If the agent cannot be found, it opens the `.ccx` file with the system default handler so Creative Cloud can install it.

## Load for testing

1. Start SAI AI Studio so the local command server is listening on `127.0.0.1:47872`.
2. Open Photoshop 24.4+ (the bridge uses the Imaging API).
3. Use Adobe UXP Developer Tool to add this plugin folder:
   `integrations/photoshop-uxp-bridge`
4. Load the plugin and open the `SAI AI Studio Bridge` panel.
5. The panel should show it is connected to Studio.

## First test targets

- Select an area in Photoshop.
- Trigger capture/generate/fill-back from Studio.
- Diagnostics should show:
  - `DrawingApp: Photoshop`
  - `PasteTransport: UxpBatchPlay`
  - `SupportsSelectionBounds: True`
  - `SupportsMergedSelectionCapture: True`

The plugin regression script is `node scripts/Test-PhotoshopUxp.cjs`. It checks
pixel dimensions across different document resolutions, transparent margin
offsets, oversized images, and cleanup/rollback with Photoshop API substitutes.
Live Photoshop acceptance is still required: test a full-canvas and an off-center
selection on both 72 and 300 DPI documents, confirm a normal pixel layer with the
expected bounds, then undo once. A disconnected or unsupported panel is reported
as a failure so that the saved result can be retried after reconnecting.
