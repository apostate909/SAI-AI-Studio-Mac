const photoshop = require("photoshop");
const { action, app, core, imaging } = photoshop;
const { entrypoints, storage } = require("uxp");
const { localFileSystem, formats } = storage;

const BRIDGE_URL = "http://127.0.0.1:47872";
// 每次插件加载重新生成，仅用于防止旧文档编号重用，不是桥接鉴权凭据。
const BRIDGE_SESSION_ID = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
let running = true;
let polling = false;

function setStatus(text) {
  const el = document.getElementById("status");
  if (el) el.textContent = text;
}

async function postResult(commandId, result) {
  await fetch(`${BRIDGE_URL}/commands/${commandId}/result`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(result)
  });
}

async function pollOnce() {
  const response = await fetch(`${BRIDGE_URL}/commands/next`);
  const command = await response.json();
  if (!command || !command.id || command.type === "noop") {
    return;
  }

  try {
    const data = await executeCommand(command);
    await postResult(command.id, {
      success: true,
      message: `${command.type} completed`,
      data
    });
  } catch (error) {
    const message = error && error.message ? error.message : String(error);
    setStatus(`${command.type} failed: ${message}`);
    await postResult(command.id, {
      success: false,
      message
    });
  }
}

async function executeCommand(command) {
  switch (command.type) {
    case "status":
      return getStatus();
    case "captureSelection":
      return captureSelection();
    case "captureCanvas":
      return captureSelection(true);
    case "pasteImage":
      return pasteImage(command.payload || {});
    case "pasteImageToDocument":
      if (!command.payload?.targetDocument) {
        throw new Error("定向回填缺少来源文档，已停止自动回填。");
      }
      return pasteImage(command.payload);
    default:
      throw new Error(`Unknown command: ${command.type}`);
  }
}

async function getStatus() {
  const doc = app.activeDocument;
  const selection = doc ? await getSelectionBounds() : null;
  return {
    photoshopVersion: app.version || "",
    bridgeSessionId: BRIDGE_SESSION_ID,
    supportsDocumentTargeting: true,
    hasActiveDocument: !!doc,
    documentWidth: doc ? Math.round(doc.width) : null,
    documentHeight: doc ? Math.round(doc.height) : null,
    hasSelection: !!selection
  };
}

async function getDocumentSize(doc) {
  // DOM 的宽高固定为像素，避免动作描述中的标尺单位参与尺寸计算。
  return {
    width: Math.round(doc.width),
    height: Math.round(doc.height)
  };
}

async function getSelectionBounds(documentId) {
  const result = await action.batchPlay([
    {
      _obj: "get",
      _target: [
        { _property: "selection" },
        documentId == null
          ? { _ref: "document", _enum: "ordinal", _value: "targetEnum" }
          : { _ref: "document", _id: documentId }
      ],
      _options: { dialogOptions: "dontDisplay" }
    }
  ], {});

  const selection = result && result[0] ? result[0].selection : null;
  if (!selection || !selection.left || !selection.top || !selection.right || !selection.bottom) {
    return null;
  }

  const left = Math.round(unitValueToNumber(selection.left));
  const top = Math.round(unitValueToNumber(selection.top));
  const right = Math.round(unitValueToNumber(selection.right));
  const bottom = Math.round(unitValueToNumber(selection.bottom));
  if (right <= left || bottom <= top) {
    return null;
  }

  return { left, top, right, bottom };
}

async function captureSelection(fullCanvas = false) {
  return core.executeAsModal(async () => {
    const doc = app.activeDocument;
    if (!doc) {
      throw new Error("Photoshop has no active document.");
    }
    const documentSize = await getDocumentSize(doc);
    const bounds = fullCanvas
      ? { left: 0, top: 0, right: Math.round(documentSize.width), bottom: Math.round(documentSize.height) }
      : await getSelectionBounds(doc.id);
    if (!bounds) {
      throw new Error("Photoshop has no active selection.");
    }

    const capture = await captureSelectionComposite(bounds, doc.id);
    return {
      imageBase64: capture.imageBase64,
      width: capture.width,
      height: capture.height,
      bounds,
      documentWidth: Math.round(documentSize.width),
      documentHeight: Math.round(documentSize.height),
      sourceDocument: {
        sessionId: BRIDGE_SESSION_ID,
        documentId: doc.id,
        documentName: doc.title || doc.name || "未命名文档",
        canvasWidth: documentSize.width,
        canvasHeight: documentSize.height
      },
      diagnosticText: `Photoshop UXP ${fullCanvas ? "canvas" : "selection"} capture used Imaging API composite pixels. EncodedFormat=${capture.encodedFormat}; PixelFormat=${capture.pixelFormat}; SourceBounds=${formatBounds(capture.sourceBounds)}.`
    };
  }, { commandName: fullCanvas ? "SAI AI Studio Capture Canvas" : "SAI AI Studio Capture Selection" });
}

async function captureSelectionComposite(bounds, documentId) {
  if (!imaging || !imaging.getPixels || !imaging.encodeImageData) {
    throw new Error("Photoshop Imaging API is unavailable in this host.");
  }

  const imageObj = await imaging.getPixels({
    documentID: documentId,
    sourceBounds: bounds,
    colorSpace: "RGB",
    componentSize: 8,
    applyAlpha: true
  });

  try {
    const imageData = imageObj.imageData;
    const imageBase64 = await imaging.encodeImageData({
      imageData,
      base64: true
    });
    return {
      imageBase64,
      width: imageData.width,
      height: imageData.height,
      pixelFormat: imageData.pixelFormat,
      encodedFormat: "jpeg/base64",
      sourceBounds: imageObj.sourceBounds
    };
  } finally {
    if (imageObj.imageData && imageObj.imageData.dispose) {
      imageObj.imageData.dispose();
    }
  }
}

async function pasteImage(payload) {
  return core.executeAsModal(async executionContext => {
    if (!payload.imageBase64) {
      throw new Error("pasteImage requires imageBase64.");
    }
    const previousDocument = app.activeDocument;
    const reference = payload.targetDocument;
    let targetDocument = previousDocument;
    if (reference != null) {
      if (reference.sessionId !== BRIDGE_SESSION_ID) {
        throw new Error("PS 或桥接插件会话已变化，已停止自动回填。图片保留，可从历史手动加入当前画面。");
      }
      if (!Number.isInteger(reference.documentId) || reference.documentId <= 0) {
        throw new Error("来源文档信息无效，已停止自动回填。");
      }
      targetDocument = Array.from(app.documents).find(doc => doc.id === reference.documentId);
      if (!targetDocument) {
        throw new Error(`来源文档“${reference.documentName || "未命名文档"}”已关闭，已停止自动回填。图片保留，可从历史手动加入当前画面。`);
      }
      if (payload.placement === "canvasOrigin" && (
        Math.round(targetDocument.width) !== reference.canvasWidth ||
        Math.round(targetDocument.height) !== reference.canvasHeight)) {
        throw new Error("来源文档画布尺寸已变化，已停止自动回填。请重新获取选区或从历史手动加入当前画面。");
      }
    }
    if (!targetDocument) {
      throw new Error("Photoshop has no active document.");
    }
    if (!imaging || !imaging.getPixels || !imaging.putPixels) {
      throw new Error("Photoshop Imaging API is unavailable in this host.");
    }

    const file = await writeTempPng(payload.imageBase64);
    let sourceDocument;
    let imageData;
    try {
      // 只用临时文档解码 PNG；不使用会按 DPI/画布尺寸缩放的智能对象置入。
      // app.open 接受 UXP File 对象，由 DOM 负责转换文件令牌。
      sourceDocument = await app.open(file);
      await executionContext.hostControl.registerAutoCloseDocument(sourceDocument.id);
      const sourceWidth = Math.round(sourceDocument.width);
      const sourceHeight = Math.round(sourceDocument.height);
      const pixels = await imaging.getPixels({
        documentID: sourceDocument.id,
        sourceBounds: { left: 0, top: 0, right: sourceWidth, bottom: sourceHeight },
        colorSpace: "RGB",
        componentSize: 8,
        applyAlpha: false
      });
      imageData = pixels.imageData;
      if (!imageData || imageData.width <= 0 || imageData.height <= 0) {
        throw new Error("The fill-back image contains no pixels.");
      }
      // getPixels 可能裁掉透明边缘，必须把返回区域的偏移加回去。
      const sourceBounds = pixels.sourceBounds;
      if (!sourceBounds || (pixels.level != null && pixels.level !== 0)) {
        throw new Error("Photoshop did not return full-resolution fill-back pixels.");
      }

      app.activeDocument = targetDocument;
      const canvasOrigin = payload.placement === "canvasOrigin";
      const left = canvasOrigin ? 0 : Math.round((targetDocument.width - sourceWidth) / 2);
      const top = canvasOrigin ? 0 : Math.round((targetDocument.height - sourceHeight) / 2);
      const targetBounds = { left: left + sourceBounds.left, top: top + sourceBounds.top };

      // 一次撤销即可移除回填图层；任何异常由模态作用域回滚本次修改。
      const history = await executionContext.hostControl.suspendHistory({
        documentID: targetDocument.id,
        name: "SAI AI Studio Fill Back"
      });
      const layer = await targetDocument.createPixelLayer({ name: "SAI AI Studio" });
      await imaging.putPixels({
        documentID: targetDocument.id,
        layerID: layer.id,
        imageData,
        replace: true,
        targetBounds,
        commandName: "SAI AI Studio Fill Back"
      });
      await executionContext.hostControl.resumeHistory(history);

      return {
        targetDocumentId: targetDocument.id,
        targetDocumentName: targetDocument.title || targetDocument.name || "未命名文档",
        createLayer: true,
        layerID: layer.id,
        layerKind: "pixel",
        sourceWidth,
        sourceHeight,
        targetBounds,
        diagnosticText: `Photoshop UXP paste wrote native pixels to a new pixel layer. Source=${sourceWidth}x${sourceHeight}; Target=${targetBounds.left},${targetBounds.top}; Scale=100%; Alpha=preserved.`
      };
    } finally {
      if (imageData) imageData.dispose();
      // 自动关闭登记也覆盖用户取消时 Photoshop 拒绝执行清理命令的情形。
      if (sourceDocument) {
        try { await sourceDocument.closeWithoutSaving(); } catch (_) { /* 模态结束时自动关闭。 */ }
      }
      try {
        // 用户生成期间可能在另一文档继续作画，回填完成后恢复那个文档。
        if (previousDocument && Array.from(app.documents).some(doc => doc.id === previousDocument.id)) {
          app.activeDocument = previousDocument;
        }
      } catch (_) { /* 取消时由 Photoshop 恢复焦点。 */ }
      try { await file.delete(); } catch (_) { /* 未关闭的临时文件由 UXP 临时目录管理。 */ }
    }
  }, { commandName: "SAI AI Studio Paste Image" });
}

async function clipboardPngToBase64() {
  if (!navigator.clipboard) {
    throw new Error("UXP clipboard image read is unavailable in this Photoshop host.");
  }

  if (navigator.clipboard.getContent) {
    const content = await navigator.clipboard.getContent();
    const png = content && content["image/png"];
    if (png) {
      return clipboardValueToBase64(png);
    }

    const availableTypes = content ? Object.keys(content).join(", ") : "";
    throw new Error(`Photoshop copyMerged clipboard did not include image/png. Available types: ${availableTypes || "none"}.`);
  }

  if (!navigator.clipboard.read) {
    throw new Error("UXP clipboard image read is unavailable in this Photoshop host.");
  }

  const rawItems = await navigator.clipboard.read();
  const items = Array.isArray(rawItems)
    ? rawItems
    : rawItems && typeof rawItems.length === "number"
      ? Array.from(rawItems)
      : rawItems
        ? [rawItems]
        : [];
  for (const item of items) {
    const pngType = item.types.find(type => type === "image/png");
    if (!pngType) continue;
    const blob = await item.getType(pngType);
    return clipboardValueToBase64(blob);
  }

  throw new Error("Photoshop copyMerged did not produce an image/png clipboard item.");
}

async function clipboardValueToBase64(value) {
  if (typeof value === "string") {
    return value;
  }

  if (value instanceof ArrayBuffer) {
    return arrayBufferToBase64(value);
  }

  if (ArrayBuffer.isView(value)) {
    return arrayBufferToBase64(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength));
  }

  if (value && typeof value.arrayBuffer === "function") {
    return arrayBufferToBase64(await value.arrayBuffer());
  }

  if (value && value.data) {
    return clipboardValueToBase64(value.data);
  }

  throw new Error(`Unsupported image/png clipboard value: ${Object.prototype.toString.call(value)}.`);
}

async function writeTempPng(base64) {
  const folder = await localFileSystem.getTemporaryFolder();
  const file = await folder.createFile(`sai-ai-studio-${Date.now()}.png`, { overwrite: true });
  const bytes = base64ToUint8Array(base64);
  await file.write(bytes, { format: formats.binary });
  return file;
}

function unitValueToNumber(value) {
  if (value == null) return 0;
  if (typeof value === "number") return value;
  if (typeof value._value === "number") return value._value;
  if (typeof value.value === "number") return value.value;
  return Number(value) || 0;
}

function formatBounds(bounds) {
  if (!bounds) return "unknown";
  const left = bounds.left ?? 0;
  const top = bounds.top ?? 0;
  const right = bounds.right ?? (left + (bounds.width ?? 0));
  const bottom = bounds.bottom ?? (top + (bounds.height ?? 0));
  return `L=${left},T=${top},R=${right},B=${bottom}`;
}

function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

async function pollLoop() {
  if (polling) return;
  polling = true;
  while (running) {
    try {
      await pollOnce();
      if (!document.getElementById("status")?.textContent?.includes("failed:")) {
        setStatus(`Connected to ${BRIDGE_URL}`);
      }
    } catch (error) {
      const message = error && error.message ? error.message : String(error);
      setStatus(`Waiting for Studio at ${BRIDGE_URL}: ${message}`);
    }
    await new Promise(resolve => setTimeout(resolve, 350));
  }
  polling = false;
}

function initializePanel() {
  const button = document.getElementById("toggle");
  if (!button) return;
  // DOMContentLoaded 和面板 show 都可能触发，重复打开不能重复绑定或启动轮询。
  if (button !== initializePanel.button) {
    button.addEventListener("click", () => {
      running = !running;
      button.textContent = running ? "Pause" : "Resume";
      if (running) pollLoop();
    });
    initializePanel.button = button;
  }
  button.textContent = running ? "Pause" : "Resume";
  if (running) {
    if (!polling) setStatus(`Connecting to ${BRIDGE_URL}...`);
    pollLoop();
  }
}

// 新版 Photoshop 使用 UXP 面板生命周期启动；保留 DOM 就绪入口兼容旧版。
entrypoints.setup({
  plugin: {
    create() { initializePanel(); },
    destroy() { running = false; }
  },
  panels: {
    saiAiStudioBridgePanel: {
      create() { initializePanel(); },
      show() { initializePanel(); }
    }
  }
});
document.addEventListener("DOMContentLoaded", initializePanel);
