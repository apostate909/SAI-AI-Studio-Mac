using System.Security.Cryptography;
using System.Text.Json;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Shared.Licensing;
using Xunit;

namespace SAIStudio.Core.Tests.Licensing;

public sealed class LicenseClientTests
{
    [Fact]
    public async Task FreshDeviceCannotUseWithoutSuccessfulOnlineEnrollment()
    {
        using var context = new LicenseTestContext();
        context.Transport.Offline = true;
        var client = context.Client();
        await client.InitializeAsync();
        await client.CheckAsync("one-time-invitation");
        Assert.False(client.Snapshot.CanUse);
        Assert.Throws<LicenseAccessException>(client.EnsureBusinessAllowed);
        Assert.Null(context.Store.State.Document);
    }

    [Fact]
    public async Task WeekWithoutOpeningDoesNotConsumeOfflineAllowance()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Clock.Advance(TimeSpan.FromDays(9));
        client = context.Client();
        await client.InitializeAsync();
        Assert.True(client.Snapshot.CanUse);
        Assert.Null(context.Store.State.OfflineSinceUtc);
        context.Transport.Offline = true;
        await client.CheckAsync();
        Assert.Equal(context.Clock.GetUtcNow(), context.Store.State.OfflineSinceUtc);
        context.Clock.Advance(TimeSpan.FromDays(7));
        // 即使尚未收到计时器回调，业务边界也不能继续放行。
        Assert.Throws<LicenseAccessException>(client.EnsureBusinessAllowed);
        await client.TickAsync();
        Assert.Equal(ClientAccessState.VerificationRequired, client.Snapshot.State);
        Assert.Null(context.Store.State.GraceEndsUtc);
    }

    [Fact]
    public async Task OfflineCountdownContinuesAcrossClosedApplicationAndRecoveryClearsIt()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Transport.Offline = true;
        await client.CheckAsync();
        context.Clock.Advance(TimeSpan.FromDays(6));
        client = context.Client();
        await client.InitializeAsync();
        Assert.True(client.Snapshot.CanUse);
        context.Transport.Offline = false;
        await client.CheckAsync();
        Assert.Null(context.Store.State.OfflineSinceUtc);
        context.Clock.Advance(TimeSpan.FromDays(3));
        await client.TickAsync();
        Assert.True(client.Snapshot.CanUse);
    }

    [Theory]
    [InlineData(48)]
    [InlineData(120)]
    public async Task PendingTrialGetsFullDayThenOnePersistedGrace(int hours)
    {
        using var context = new LicenseTestContext();
        context.Claims = context.Claims with { State = EntitlementState.Pending,
            AccessEndsUtc = context.Clock.GetUtcNow().AddDays(1), GraceSeconds = hours * 3600 };
        var client = await context.Enroll();
        context.Clock.Advance(TimeSpan.FromHours(23.99));
        await client.TickAsync();
        Assert.Equal(ClientAccessState.Trial, client.Snapshot.State);
        context.Clock.Advance(TimeSpan.FromMinutes(1));
        await client.TickAsync();
        Assert.Equal(LicenseProtocol.EndWarning, client.Snapshot.Message);
        Assert.True(client.Snapshot.WarningPending);
        Assert.Null(context.Store.State.GraceStartedUtc);
        Assert.True(await client.BeginWarningAsync());
        var start = context.Store.State.GraceStartedUtc;
        var end = context.Store.State.GraceEndsUtc;
        Assert.Equal(TimeSpan.FromHours(hours), end - start);
        await client.AcknowledgeWarningAsync();
        context.Clock.Advance(TimeSpan.FromHours(1));
        client = context.Client();
        await client.InitializeAsync();
        await client.CheckAsync();
        Assert.Equal(end, context.Store.State.GraceEndsUtc);
        Assert.False(client.Snapshot.WarningPending);
        context.Clock.Advance(TimeSpan.FromHours(hours));
        client = context.Client();
        await client.InitializeAsync();
        Assert.Equal(ClientAccessState.Disabled, client.Snapshot.State);
        Assert.False(client.Snapshot.CanUse);
        Assert.DoesNotContain(end!.Value.ToString("yyyy-MM-dd"), client.Snapshot.Message);
    }

    [Fact]
    public async Task RevokeCannotBePostponedByOfflineOrDifferentRepeatedEvent()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Claims = context.Claims with { Revision = 2, State = EntitlementState.Revoked, EndEventId = "revoked-1" };
        await client.CheckAsync();
        await client.BeginWarningAsync();
        var end = context.Store.State.GraceEndsUtc;
        context.Clock.Advance(TimeSpan.FromHours(10));
        context.Claims = context.Claims with { Revision = 3, EndEventId = "revoked-2" };
        await client.CheckAsync();
        Assert.Equal(end, context.Store.State.GraceEndsUtc);
        context.Transport.Offline = true;
        context.Clock.Advance(TimeSpan.FromDays(3));
        await client.CheckAsync();
        Assert.False(client.Snapshot.CanUse);
        Assert.Equal(ClientAccessState.Disabled, client.Snapshot.State);
    }

    [Fact]
    public async Task OnlyNewerSignedAuthorizationCanRecoverDisabledDevice()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Claims = context.Claims with { Revision = 3, State = EntitlementState.Revoked, EndEventId = "revoked" };
        await client.CheckAsync();
        await client.BeginWarningAsync();
        context.Clock.Advance(TimeSpan.FromDays(3));
        await client.TickAsync();
        context.Claims = context.Claims with { Revision = 2, State = EntitlementState.Active, EndEventId = "restored" };
        await client.CheckAsync();
        Assert.False(client.Snapshot.CanUse);
        context.Claims = context.Claims with { Revision = 3 };
        await client.CheckAsync();
        Assert.False(client.Snapshot.CanUse);
        context.Claims = context.Claims with { Revision = 4 };
        await client.CheckAsync();
        Assert.True(client.Snapshot.CanUse);
        Assert.Null(context.Store.State.GraceEndsUtc);
    }

    [Fact]
    public async Task WallClockRollbackRequiresOnlineValidationAndCannotResetTimer()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Transport.Offline = true;
        await client.CheckAsync();
        var offline = context.Store.State.OfflineSinceUtc;
        context.Clock.JumpWall(TimeSpan.FromDays(-10));
        Assert.Throws<LicenseAccessException>(client.EnsureBusinessAllowed);
        await client.TickAsync();
        Assert.False(client.Snapshot.CanUse);
        context.Transport.Offline = false;
        context.Clock.JumpWall(TimeSpan.FromDays(10));
        await client.CheckAsync();
        Assert.True(client.Snapshot.CanUse);
        Assert.Null(context.Store.State.OfflineSinceUtc);
    }

    [Fact]
    public async Task StorageFailureFailsClosedWithoutDestroyingUserData()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        context.Store.FailSave = true;
        await client.TickAsync();
        Assert.False(client.Snapshot.CanUse);
        Assert.Equal(ClientAccessState.VerificationRequired, client.Snapshot.State);
    }

    [Fact]
    public async Task ForwardThenBackwardClockChangeCannotCreateYearLongGrace()
    {
        using var context = new LicenseTestContext();
        context.Claims = context.Claims with { AccessEndsUtc = context.Clock.GetUtcNow().AddDays(1) };
        var client = await context.Enroll();
        context.Clock.JumpWall(TimeSpan.FromDays(365));
        await client.TickAsync();
        await client.BeginWarningAsync();
        Assert.NotNull(context.Store.State.GraceStartedUtc);
        context.Clock.JumpWall(TimeSpan.FromDays(-365));
        await client.CheckAsync();
        Assert.Equal(ClientAccessState.Active, client.Snapshot.State);
        Assert.Null(context.Store.State.GraceEndsUtc);
        context.Clock.Advance(TimeSpan.FromDays(1));
        await client.TickAsync();
        await client.BeginWarningAsync();
        Assert.Equal(context.Clock.GetUtcNow().AddHours(48), context.Store.State.GraceEndsUtc);
    }

    [Fact]
    public async Task InterruptedChecksCannotBeUsedToAvoidStartingOfflineCountdown()
    {
        using var context = new LicenseTestContext();
        var client = await context.Enroll();
        var pending = context.Store.Load();
        pending.VerificationPending = true;
        context.Store.Save(pending);
        // 关闭一周后重开才确认上次校验失败，不能倒推消耗这一周。
        context.Clock.Advance(TimeSpan.FromDays(7));
        client = context.Client();
        await client.InitializeAsync();
        var firstFailure = context.Store.State.OfflineSinceUtc;
        Assert.Equal(context.Clock.GetUtcNow(), firstFailure);
        Assert.True(client.Snapshot.CanUse);
        pending = context.Store.Load();
        pending.VerificationPending = true;
        context.Store.Save(pending);
        context.Clock.Advance(TimeSpan.FromDays(7));
        client = context.Client();
        await client.InitializeAsync();
        Assert.Equal(firstFailure, context.Store.State.OfflineSinceUtc);
        Assert.False(client.Snapshot.CanUse);
    }

    [Theory]
    [InlineData(47)]
    [InlineData(121)]
    public async Task UnsuitableSignedGraceDurationIsRejected(int hours)
    {
        using var context = new LicenseTestContext();
        context.Claims = context.Claims with { GraceSeconds = hours * 3600 };
        var client = await context.Enroll();
        Assert.False(client.Snapshot.CanUse);
    }

    [Fact]
    public async Task TrialShorterThan24HoursAndWrongDeviceAreRejected()
    {
        using var context = new LicenseTestContext();
        context.Claims = context.Claims with { State = EntitlementState.Pending, AccessEndsUtc = context.Clock.GetUtcNow().AddHours(23) };
        var client = await context.Enroll();
        Assert.False(client.Snapshot.CanUse);
        context.Claims = context.Claims with { AccessEndsUtc = context.Clock.GetUtcNow().AddDays(1), DeviceId = "another-device" };
        await client.CheckAsync();
        Assert.False(client.Snapshot.CanUse);
    }

    [Fact]
    public void PayloadTamperingAndUnknownSigningKeyAreRejected()
    {
        using var context = new LicenseTestContext();
        var signed = context.Sign(context.Claims);
        Assert.ThrowsAny<Exception>(() => context.Verifier.VerifyLicense(signed with { Payload = Convert.ToBase64String("{}"u8.ToArray()) }, "device"));
        Assert.ThrowsAny<Exception>(() => context.Verifier.VerifyLicense(signed with { KeyId = "unknown" }, "device"));
    }

    [Fact]
    public async Task UseAndUpdatePermissionsAreIndependent()
    {
        using var context = new LicenseTestContext();
        context.Claims = context.Claims with { CanUpdate = false };
        var client = await context.Enroll();
        Assert.True(client.Snapshot.CanUse);
        Assert.False(client.Snapshot.CanUpdate);
        context.Claims = context.Claims with { Revision = 2, State = EntitlementState.Revoked, CanUpdate = true };
        await client.CheckAsync();
        await client.BeginWarningAsync();
        context.Clock.Advance(TimeSpan.FromDays(3));
        await client.TickAsync();
        Assert.False(client.Snapshot.CanUse);
        Assert.True(client.Snapshot.CanUpdate);
    }
}

internal sealed class LicenseTestContext : IDisposable
{
    private readonly ECDsa _key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
    public TestClock Clock { get; } = new();
    public MemoryStateStore Store { get; } = new();
    public TestTransport Transport { get; }
    public SignedDocumentVerifier Verifier { get; }
    public LicenseClaims Claims { get; set; }
    public LicenseTestContext()
    {
        Verifier = new(new Dictionary<string, string> { ["test"] = _key.ExportSubjectPublicKeyInfoPem() });
        Claims = new() { DeviceId = "device", Revision = 1, State = EntitlementState.Active, CanUpdate = true,
            RegisteredUtc = Clock.GetUtcNow(), ServerUtc = Clock.GetUtcNow(), EndEventId = "expiry-1", GraceSeconds = 48 * 3600 };
        Transport = new(this);
    }
    public LicenseClient Client() => new(Store, Transport, Verifier, "device", time: Clock);
    public async Task<LicenseClient> Enroll()
    {
        var client = Client();
        await client.InitializeAsync();
        await client.CheckAsync("invite");
        return client;
    }
    public SignedDocument Sign<T>(T value)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, SignedDocumentVerifier.JsonOptions);
        return new("test", Convert.ToBase64String(bytes), Convert.ToBase64String(
            _key.SignData(bytes, HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation)));
    }
    public void Dispose() => _key.Dispose();
    internal sealed class TestTransport(LicenseTestContext context) : ILicenseTransport
    {
        public bool Offline { get; set; }
        public Task<SignedDocument> CheckAsync(LicenseClientState state, string? invitation, CancellationToken ct) =>
            Offline ? Task.FromException<SignedDocument>(new HttpRequestException("offline")) :
                Task.FromResult(context.Sign(context.Claims with { ServerUtc = context.Clock.GetUtcNow() }));
    }
}

internal sealed class MemoryStateStore : ILicenseStateStore
{
    public LicenseClientState State { get; private set; } = new();
    public bool FailSave { get; set; }
    public LicenseClientState Load() => Clone(State);
    public void Save(LicenseClientState state)
    {
        if (FailSave) throw new IOException("disk full");
        State = Clone(state);
    }
    private static LicenseClientState Clone(LicenseClientState state) =>
        JsonSerializer.Deserialize<LicenseClientState>(JsonSerializer.Serialize(state))!;
}

internal sealed class TestClock : TimeProvider
{
    private DateTimeOffset _wall = new(2026, 9, 14, 0, 0, 0, TimeSpan.Zero);
    private long _ticks;
    public override long TimestampFrequency => TimeSpan.TicksPerSecond;
    public override DateTimeOffset GetUtcNow() => _wall;
    public override long GetTimestamp() => _ticks;
    public void Advance(TimeSpan elapsed) { _wall += elapsed; _ticks += elapsed.Ticks; }
    public void JumpWall(TimeSpan amount) => _wall += amount;
}
