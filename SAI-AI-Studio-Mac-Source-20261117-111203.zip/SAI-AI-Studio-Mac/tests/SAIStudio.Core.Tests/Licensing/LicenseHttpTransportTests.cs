using System.Net;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Shared.Licensing;
using Xunit;

namespace SAIStudio.Core.Tests.Licensing;

public sealed class LicenseHttpTransportTests
{
    [Fact]
    public async Task EnrollmentSignsChallengeAndUsesFreshNonceForEachRequest()
    {
        using var context = new LicenseTestContext();
        using var identity = new TestDeviceIdentity();
        var nonces = new HashSet<string>();
        var handler = new Handler(async request =>
        {
            if (request.RequestUri!.AbsolutePath == "/v1/challenge")
                return Json(new DeviceChallenge("challenge-1", "server-random", context.Clock.GetUtcNow().AddMinutes(1)));
            var proof = (await request.Content!.ReadFromJsonAsync<DeviceProof>(SignedDocumentVerifier.JsonOptions))!;
            Assert.Equal(identity.PublicKey, proof.PublicKey);
            var bytes = Convert.FromBase64String(proof.Payload);
            using var publicKey = ECDsa.Create();
            publicKey.ImportSubjectPublicKeyInfo(Convert.FromBase64String(proof.PublicKey), out _);
            Assert.True(publicKey.VerifyData(bytes, Convert.FromBase64String(proof.Signature),
                HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation));
            var payload = JsonSerializer.Deserialize<LicenseRequest>(bytes, SignedDocumentVerifier.JsonOptions)!;
            Assert.Equal("enroll", payload.Operation);
            Assert.Equal("server-random", payload.ChallengeNonce);
            Assert.Equal("one-time-invitation", payload.Invitation);
            Assert.Equal(identity.DeviceId, payload.DeviceId);
            Assert.True(nonces.Add(payload.Nonce));
            return Json(context.Sign(context.Claims with { DeviceId = identity.DeviceId, RequestNonce = payload.Nonce }));
        });
        using var http = new HttpClient(handler);
        var transport = new LicenseHttpTransport(http, new Uri("https://license.example/"), identity, context.Verifier, "1.0.0.0");
        await transport.CheckAsync(new(), "one-time-invitation", default);
        await transport.CheckAsync(new(), "one-time-invitation", default);
        Assert.Equal(2, nonces.Count);
    }

    [Fact]
    public async Task ValidSignatureWithWrongRequestNonceIsRejected()
    {
        using var context = new LicenseTestContext();
        using var identity = new TestDeviceIdentity();
        using var http = new HttpClient(new Handler(request => Task.FromResult(
            request.RequestUri!.AbsolutePath.EndsWith("challenge")
                ? Json(new DeviceChallenge("challenge-1", "random", context.Clock.GetUtcNow().AddMinutes(1)))
                : Json(context.Sign(context.Claims with { DeviceId = identity.DeviceId, RequestNonce = "old-response" })))));
        var transport = new LicenseHttpTransport(http, new Uri("https://license.example/"), identity, context.Verifier, "1.0.0.0");
        await Assert.ThrowsAsync<CryptographicException>(() => transport.CheckAsync(new(), "invite", default));
    }

    [Fact]
    public async Task RedirectIsNotTreatedAsAuthorizationOrRetriedWithCredentials()
    {
        using var context = new LicenseTestContext();
        using var identity = new TestDeviceIdentity();
        var requests = 0;
        using var http = new HttpClient(new Handler(request =>
        {
            requests++;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.Redirect)
                { Headers = { Location = new Uri("https://unrelated.example/") } });
        }));
        var transport = new LicenseHttpTransport(http, new Uri("https://license.example/"), identity, context.Verifier, "1.0.0.0");
        await Assert.ThrowsAsync<HttpRequestException>(() => transport.CheckAsync(new(), "invite", default));
        Assert.Equal(1, requests);
    }

    [Fact]
    public void PlainHttpIsAllowedOnlyWithExplicitLoopbackTestOption()
    {
        using var context = new LicenseTestContext();
        using var identity = new TestDeviceIdentity();
        using var http = new HttpClient();
        Assert.Throws<ArgumentException>(() => new LicenseHttpTransport(http, new Uri("http://example.org/"), identity, context.Verifier, "1"));
        Assert.Throws<ArgumentException>(() => new LicenseHttpTransport(http, new Uri("http://example.org/"), identity, context.Verifier, "1", true));
        _ = new LicenseHttpTransport(http, new Uri("http://127.0.0.1:12345/"), identity, context.Verifier, "1", true);
    }

    [Fact]
    public async Task StalledResponseBodyCannotKeepVerificationRunningIndefinitely()
    {
        using var context = new LicenseTestContext();
        using var identity = new TestDeviceIdentity();
        using var http = new HttpClient(new Handler(request => Task.FromResult(
            request.RequestUri!.AbsolutePath.EndsWith("challenge")
                ? Json(new DeviceChallenge("id", "random", context.Clock.GetUtcNow().AddMinutes(1)))
                : new HttpResponseMessage(HttpStatusCode.OK) { Content = new StreamContent(new StalledStream()) })))
            { Timeout = TimeSpan.FromMilliseconds(200) };
        var transport = new LicenseHttpTransport(http, new Uri("https://license.example/"), identity, context.Verifier, "1.0.0.0");
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            transport.CheckAsync(new(), "invite", default).WaitAsync(TimeSpan.FromSeconds(5)));
    }

    [Fact]
    public async Task OversizedResponsesAreBounded()
    {
        using var response = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(new string('x', 8193)) };
        await Assert.ThrowsAsync<InvalidDataException>(() => LicenseHttpTransport.ReadBoundedJsonAsync<DeviceChallenge>(response, 8192, default));
    }

    private static HttpResponseMessage Json<T>(T value) => new(HttpStatusCode.OK)
        { Content = JsonContent.Create(value, options: SignedDocumentVerifier.JsonOptions) };
    private sealed class StalledStream : MemoryStream
    {
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            await Task.Delay(Timeout.Infinite, cancellationToken);
            return 0;
        }
    }
    private sealed class Handler(Func<HttpRequestMessage, Task<HttpResponseMessage>> respond) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) => respond(request);
    }
}

internal sealed class TestDeviceIdentity : IDeviceIdentity, IDisposable
{
    private readonly ECDsa _key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
    public string PublicKey => Convert.ToBase64String(_key.ExportSubjectPublicKeyInfo());
    public string DeviceId => Convert.ToHexString(SHA256.HashData(_key.ExportSubjectPublicKeyInfo()));
    public byte[] Sign(byte[] payload) => _key.SignData(payload, HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation);
    public void Dispose() => _key.Dispose();
}
