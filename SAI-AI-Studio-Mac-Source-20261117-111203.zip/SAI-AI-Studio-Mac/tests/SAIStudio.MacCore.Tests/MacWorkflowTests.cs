using System.Security.Cryptography;
using SAIStudio.Bridge;
using SAIStudio.Core.Services;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.MacCore.Imaging;
using SAIStudio.MacCore.Photoshop;
using SAIStudio.MacCore.Services;
using SAIStudio.MacCore.Storage;
using SAIStudio.Shared;
using SAIStudio.Shared.Licensing;
using SAIStudio.Shared.Services;
using SkiaSharp;
using Xunit;

namespace SAIStudio.MacCore.Tests;

public sealed class MacWorkflowTests : IDisposable
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), "sai-mac-tests-" + Guid.NewGuid().ToString("N"));
    private readonly Gate _access = new();
    private readonly Photoshop _photoshop = new();
    private MacHistoryStore History => new(_directory);
    private MacWorkflow Workflow => new(_access, _photoshop, History);
    private static byte[] Image(SKColor? color = null)
    {
        using var bitmap = new SKBitmap(4, 2); bitmap.Erase(color ?? SKColors.Red); return MacImages.Encode(bitmap);
    }
    private static PhotoshopUxpSelectionCapture Capture(int document = 7) => new(Convert.ToBase64String(Image()), 4, 2,
        new(2, 3, 6, 5), 10, 8, "capture", new("session", document, "Source", 10, 8));
    [Fact]
    public void CompositionKeepsOutsideTransparentAndUsesExactSourceBounds()
    {
        using var image = MacImages.Decode(MacImages.Compose(Image(), Capture()));
        Assert.Equal(10, image.Width); Assert.Equal(8, image.Height);
        Assert.Equal((byte)0, image.GetPixel(0, 0).Alpha);
        Assert.Equal(SKColors.Red, image.GetPixel(2, 3));
        Assert.Equal(SKColors.Red, image.GetPixel(5, 4));
        Assert.Equal((byte)0, image.GetPixel(6, 5).Alpha);
    }
    [Fact]
    public async Task DisabledLicenseBlocksCaptureGenerateImportAndPaste()
    {
        _access.Allowed = false;
        Assert.Throws<LicenseAccessException>(() => Workflow.Import(Image(), null, "test"));
        await Assert.ThrowsAsync<LicenseAccessException>(() => Workflow.CaptureAsync(false, default));
        await Assert.ThrowsAsync<LicenseAccessException>(() => Workflow.GenerateAsync(new Backend(), Capture(), "test", .5, -1, default));
        Assert.Empty(_photoshop.Pastes);
    }
    [Fact]
    public async Task GenerateRetainsOriginalAndPastesToCapturedDocumentEvenIfCurrentDocumentChanges()
    {
        var capture = await Workflow.CaptureAsync(false, default);
        var result = await Workflow.GenerateAsync(new Backend(), capture, "test", .5, -1, default);
        _photoshop.Capture = Capture(99);
        await Workflow.PasteToSourceAsync(result, default);
        Assert.Equal(7, _photoshop.Pastes.Single().Document.DocumentId);
        Assert.Equal(4, MacImages.Decode(result.Original).Width);
        Assert.Equal(10, MacImages.Decode(result.Image).Width);
        Assert.Single(History.Load());
    }
    [Fact]
    public async Task RevocationDuringGenerationKeepsResultButPreventsPaste()
    {
        var backend = new Backend { Generate = () => { _access.Allowed = false; return Image(); } };
        var result = await Workflow.GenerateAsync(backend, Capture(), "test", .5, -1, default);
        Assert.Single(History.Load());
        await Assert.ThrowsAsync<LicenseAccessException>(() => Workflow.PasteToSourceAsync(result, default));
        Assert.Empty(_photoshop.Pastes);
    }
    [Fact]
    public async Task CancellationDoesNotSaveMockOrPaste()
    {
        using var cancelled = new CancellationTokenSource();
        var backend = new Backend { Generate = () => { cancelled.Cancel(); return Image(); } };
        await Assert.ThrowsAsync<OperationCanceledException>(() => Workflow.GenerateAsync(backend, Capture(), "test", .5, -1, cancelled.Token));
        Assert.Empty(History.Load()); Assert.Empty(_photoshop.Pastes);
    }
    [Fact]
    public async Task BackendFailureDoesNotSaveMockOrPaste()
    {
        var backend = new Backend { Generate = () => throw new HttpRequestException("offline") };
        await Assert.ThrowsAsync<HttpRequestException>(() => Workflow.GenerateAsync(backend, Capture(), "test", .5, -1, default));
        Assert.Empty(History.Load()); Assert.Empty(_photoshop.Pastes);
    }
    [Fact]
    public async Task ManualHistoryFillUsesNewSelectionAndCurrentDocument()
    {
        var result = Workflow.Import(Image(), Capture(), "test"); _photoshop.Capture = Capture(99);
        await Workflow.PasteToCurrentAsync(result, default);
        Assert.Equal(99, _photoshop.Pastes.Single().Document.DocumentId);
    }
    [Fact]
    public void HistoryRetainsTwentyNewestAndRestoresFavoriteAndDocumentReference()
    {
        for (var i = 0; i < 23; i++)
        {
            var result = Workflow.Import(Image(), Capture(), "item " + i);
            if (i == 22) History.Save(result with { Favorite = true });
        }
        var items = History.Load(); Assert.Equal(20, items.Count);
        Assert.True(items[0].Favorite); Assert.Equal("session", items[0].Capture!.SourceDocument!.SessionId);
        Assert.DoesNotContain(items, x => x.Prompt == "item 0");
    }
    [Fact]
    public async Task MissingDocumentReferenceRejectsCapture()
    {
        _photoshop.Capture = Capture() with { SourceDocument = null };
        await Assert.ThrowsAsync<InvalidDataException>(() => Workflow.CaptureAsync(false, default));
    }
    [Fact]
    public void InvalidBoundsAndOversizedCanvasAreRejected()
    {
        Assert.Throws<InvalidDataException>(() => MacImages.Compose(Image(), Capture() with { Bounds = new(-1, 0, 2, 2) }));
        Assert.Throws<InvalidDataException>(() => MacImages.ValidateSize(100000, 100000));
    }
    public void Dispose() { if (Directory.Exists(_directory)) Directory.Delete(_directory, true); }
    private sealed class Gate : IApplicationAccess
    {
        public bool Allowed = true;
        public AccessSnapshot Snapshot => new(ClientAccessState.Active, Allowed, true, "test");
        public void EnsureBusinessAllowed() { if (!Allowed) throw new LicenseAccessException("blocked"); }
    }
    private sealed class Photoshop : IMacPhotoshop
    {
        public PhotoshopUxpSelectionCapture Capture = MacWorkflowTests.Capture();
        public List<(byte[] Image, PhotoshopDocumentReference Document)> Pastes = [];
        public bool IsConnected => true;
        public Task<PhotoshopUxpSelectionCapture> CaptureAsync(bool canvas, CancellationToken ct) => Task.FromResult(Capture);
        public Task PasteAsync(byte[] png, PhotoshopDocumentReference document, CancellationToken ct) { Pastes.Add((png, document)); return Task.CompletedTask; }
    }
    private sealed class Backend : IAIBackend
    {
        public Func<byte[]> Generate = () => Image();
        public BackendType Type => BackendType.OpenAIImage;
        public string DisplayName => "Test";
        public Task<bool> PingAsync(CancellationToken ct) => Task.FromResult(true);
        public Task<byte[]> GenerateAsync(byte[] source, byte[]? mask, string? prompt, EditStrength? strength, double? denoise, int seed, CancellationToken ct) => Task.FromResult(Generate());
    }
}
