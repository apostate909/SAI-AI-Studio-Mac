using System.Net;
using System.Net.Sockets;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using SAIStudio.Bridge;
using SAIStudio.Shared;
using Xunit;

namespace SAIStudio.MacCore.Tests;

public sealed class MacBridgeCancellationTests
{
    [Fact]
    public async Task CancelledPendingCommandsAreNotSentToReconnectedPlugin()
    {
        var probe = new TcpListener(IPAddress.Loopback, 0); probe.Start();
        var port = ((IPEndPoint)probe.LocalEndpoint).Port; probe.Stop();
        var settings = new AppSettings { PhotoshopBridge = { LocalCommandPort = port } };
        using var server = new PhotoshopUxpBridgeServer(Options.Create(settings), NullLogger<PhotoshopUxpBridgeServer>.Instance);
        Assert.True(server.IsAvailable);
        using var cancellation = new CancellationTokenSource();
        var paste = server.SendCommandAsync("pasteImage", new { imageBase64 = "AQID" }, cancellation.Token);
        cancellation.Cancel(); await paste;
        using var http = new HttpClient { BaseAddress = new Uri($"http://127.0.0.1:{port}"), Timeout = TimeSpan.FromSeconds(5) };
        var command = await http.GetFromJsonAsync<JsonElement>("/commands/next");
        Assert.Equal("noop", command.GetProperty("type").GetString());
        using var alreadyCancelled = new CancellationTokenSource(); alreadyCancelled.Cancel();
        await Assert.ThrowsAsync<OperationCanceledException>(() => server.SendCommandAsync("pasteImage", null, alreadyCancelled.Token));
    }
}
