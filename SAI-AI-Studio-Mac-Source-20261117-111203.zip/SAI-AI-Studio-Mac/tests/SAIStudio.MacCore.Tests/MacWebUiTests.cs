using System.Net;
using System.Text.Json;
using SAIStudio.MacCore.Backends;
using SAIStudio.MacCore.Imaging;
using SAIStudio.Shared;
using SkiaSharp;
using Xunit;

namespace SAIStudio.MacCore.Tests;

public sealed class MacWebUiTests
{
    private static byte[] Image()
    {
        using var image = new SKBitmap(128, 80); image.Erase(SKColors.Blue); return MacImages.Encode(image);
    }
    [Theory]
    [InlineData(StableDiffusionSizeStrategy.SourceImage, 128, 80)]
    [InlineData(StableDiffusionSizeStrategy.Fixed, 512, 256)]
    [InlineData(StableDiffusionSizeStrategy.WebUIDefault, 0, 0)]
    public async Task RequestsPreserveParametersAndHonorSizePolicy(StableDiffusionSizeStrategy strategy, int width, int height)
    {
        var png = Image();
        using var http = new HttpClient(new Handler(async (request, ct) =>
        {
            Assert.EndsWith("/sdapi/v1/img2img", request.RequestUri!.AbsolutePath);
            using var body = JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));
            var root = body.RootElement;
            Assert.Equal(.7, root.GetProperty("denoising_strength").GetDouble());
            Assert.Equal(123, root.GetProperty("seed").GetInt32());
            Assert.Equal("bad", root.GetProperty("negative_prompt").GetString());
            Assert.Contains("<lora:line:0.65>", root.GetProperty("prompt").GetString());
            if (width == 0) Assert.False(root.TryGetProperty("width", out _));
            else { Assert.Equal(width, root.GetProperty("width").GetInt32()); Assert.Equal(height, root.GetProperty("height").GetInt32()); }
            return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(new { images = new[] { "data:image/png;base64," + Convert.ToBase64String(png) } })) };
        }));
        var settings = new StableDiffusionWebUISettings { SizeStrategy = strategy, Width = 512, Height = 256, NegativePrompt = "bad", LoraName = "line", LoraWeight = .65 };
        var result = await new MacWebUiBackend(http, settings).GenerateAsync(png, null, "edit", null, .7, 123);
        Assert.Equal(png, result);
    }
    [Fact]
    public async Task StoppingInFlightGenerationRequestsWebUiInterrupt()
    {
        var started = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var interrupted = 0;
        using var http = new HttpClient(new Handler(async (request, ct) =>
        {
            if (request.RequestUri!.AbsolutePath.EndsWith("/interrupt"))
            {
                Interlocked.Increment(ref interrupted); return new HttpResponseMessage(HttpStatusCode.OK);
            }
            started.SetResult(); await Task.Delay(Timeout.Infinite, ct); throw new InvalidOperationException();
        }));
        using var cancellation = new CancellationTokenSource();
        var task = new MacWebUiBackend(http, new()).GenerateAsync(Image(), null, "edit", null, .5, -1, cancellation.Token);
        await started.Task.WaitAsync(TimeSpan.FromSeconds(3)); cancellation.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => task);
        Assert.Equal(1, interrupted);
    }
    private sealed class Handler(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> action) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) => action(request, cancellationToken);
    }
}
