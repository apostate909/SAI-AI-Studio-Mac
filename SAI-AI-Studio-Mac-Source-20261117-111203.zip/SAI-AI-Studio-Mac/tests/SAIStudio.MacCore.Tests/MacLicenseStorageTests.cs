using System.Security.Cryptography;
using SAIStudio.Mac.Licensing;
using SAIStudio.MacCore.Licensing;
using SAIStudio.Shared.Licensing;
using Xunit;

namespace SAIStudio.MacCore.Tests;

public sealed class MacLicenseStorageTests : IDisposable
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), "sai-keychain-tests-" + Guid.NewGuid().ToString("N"));
    private readonly Secrets _secrets = new();
    private KeychainLicenseStateStore Store => new(_secrets, _directory, "device");
    [Fact]
    public void DiskAndKeychainRecordRoundTripWithoutPlaintext()
    {
        Store.Save(new() { HighestRevision = 7, EndEventId = "secret-end-event" });
        Assert.Equal(7, Store.Load().HighestRevision);
        Assert.False(Store.Load().RequiresOnlineVerification);
        Assert.DoesNotContain("secret-end-event", System.Text.Encoding.UTF8.GetString(File.ReadAllBytes(Path.Combine(_directory, "license-state.bin"))));
    }
    [Fact]
    public void DeletedDiskFilePreservesRevisionAndRequiresOnlineRecovery()
    {
        Store.Save(new() { HighestRevision = 8 }); File.Delete(Path.Combine(_directory, "license-state.bin"));
        Assert.True(Store.Load().RequiresOnlineVerification); Assert.Equal(8, Store.Load().HighestRevision);
    }
    [Fact]
    public void RolledBackDiskCannotEraseNewerKeychainRevision()
    {
        var path = Path.Combine(_directory, "license-state.bin");
        Store.Save(new() { HighestRevision = 1 }); var old = File.ReadAllBytes(path);
        Store.Save(new() { HighestRevision = 2 }); File.WriteAllBytes(path, old);
        Assert.True(Store.Load().RequiresOnlineVerification); Assert.Equal(2, Store.Load().HighestRevision);
    }
    [Fact]
    public void DeviceBindingRejectsCopiedEncryptedRecords()
    {
        Store.Save(new() { HighestRevision = 7 });
        var copySecrets = new Secrets();
        foreach (var pair in _secrets.Values) copySecrets.Values.Add(pair.Key.Replace("device", "other"), pair.Value.ToArray());
        Assert.ThrowsAny<CryptographicException>(() => new KeychainLicenseStateStore(copySecrets, _directory, "other").Load());
    }
    [Fact]
    public void MissingEncryptionKeyCannotResetTrial()
    {
        Store.Save(new() { HighestRevision = 9 }); _secrets.Values.Remove("license-state-v1-device-key");
        Assert.Throws<CryptographicException>(() => Store.Load());
    }
    [Fact]
    public void AppleDerSignaturesConvertToExistingServerProtocol()
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        for (var i = 0; i < 50; i++)
        {
            var payload = RandomNumberGenerator.GetBytes(80);
            var der = key.SignData(payload, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);
            var fixedSignature = MacDeviceIdentity.ConvertSignature(der);
            Assert.Equal(64, fixedSignature.Length);
            Assert.True(key.VerifyData(payload, fixedSignature, HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation));
        }
    }
    public void Dispose() { if (Directory.Exists(_directory)) Directory.Delete(_directory, true); }
    private sealed class Secrets : ISecretStore
    {
        public Dictionary<string, byte[]> Values = new();
        public byte[]? Read(string account) => Values.TryGetValue(account, out var value) ? value.ToArray() : null;
        public void Write(string account, byte[] value) => Values[account] = value.ToArray();
    }
}
