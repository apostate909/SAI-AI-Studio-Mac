using System.Net;
using System.Net.Sockets;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using SAIStudio.Shared;
using SAIStudio.Shared.Services;
using Xunit;

namespace SAIStudio.Bridge.Tests;

public class PhotoshopUxpBridgeServerTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Capture_RequiresSourceIdentity_AndReportsOldPanel(bool currentPanel)
    {
        var probe = new TcpListener(IPAddress.Loopback, 0);
        probe.Start();
        var port = ((IPEndPoint)probe.LocalEndpoint).Port;
        probe.Stop();
        var settings = new AppSettings { PhotoshopBridge = { UxpEnabled = true, LocalCommandPort = port } };
        using var server = new PhotoshopUxpBridgeServer(Options.Create(settings), NullLogger<PhotoshopUxpBridgeServer>.Instance);
        var bridge = new PhotoshopUxpBridge(server, NullLogger<PhotoshopUxpBridge>.Instance);
        using var http = new HttpClient { BaseAddress = new Uri($"http://127.0.0.1:{port}"), Timeout = TimeSpan.FromSeconds(5) };
        var capture = bridge.CaptureSelectionAsync();
        var command = await http.GetFromJsonAsync<JsonElement>("/commands/next");
        var source = new PhotoshopDocumentReference("ps-session", 10, "same.psd", 120, 80);
        var data = new PhotoshopUxpSelectionCapture("AQID", 25, 34, new(5, 6, 30, 40), 120, 80,
            "capture", currentPanel ? source : null);
        using var response = await http.PostAsJsonAsync($"/commands/{command.GetProperty("id").GetString()}/result",
            new { success = true, message = "Captured", data });
        response.EnsureSuccessStatusCode();

        var result = await capture.WaitAsync(TimeSpan.FromSeconds(5));

        if (currentPanel)
        {
            Assert.Equal(source, result!.SourceDocument);
            Assert.Null(bridge.LastSelectionCaptureFailureMessage);
        }
        else
        {
            Assert.Null(result);
            Assert.Contains("0.2.3", bridge.LastSelectionCaptureFailureMessage);
        }
    }

    [Theory]
    [InlineData(true, "canvasOrigin", true, false)]
    [InlineData(false, "center", true, false)]
    [InlineData(true, "canvasOrigin", false, false)]
    [InlineData(false, "center", false, false)]
    [InlineData(true, "canvasOrigin", true, true)]
    [InlineData(false, "center", true, true)]
    public async Task PixelFillBack_SendsExplicitPlacementAndPreservesImageBytes(bool alignToCanvasOrigin, string placement, bool bound, bool legacyPanel)
    {
        var portProbe = new TcpListener(IPAddress.Loopback, 0);
        portProbe.Start();
        var port = ((IPEndPoint)portProbe.LocalEndpoint).Port;
        portProbe.Stop();
        var settings = new AppSettings { PhotoshopBridge = { UxpEnabled = true, LocalCommandPort = port } };
        using var server = new PhotoshopUxpBridgeServer(Options.Create(settings), NullLogger<PhotoshopUxpBridgeServer>.Instance);
        Assert.True(server.IsAvailable);
        var bridge = new PhotoshopUxpBridge(server, NullLogger<PhotoshopUxpBridge>.Instance);
        byte[] image = [137, 80, 78, 71];
        var target = bound ? new PhotoshopDocumentReference("ps-session", 10, "same.psd", 120, 80) : null;
        var paste = bridge.PasteImageAsync(image, true, alignToCanvasOrigin: alignToCanvasOrigin, targetDocument: target);
        using var http = new HttpClient { BaseAddress = new Uri($"http://127.0.0.1:{port}"), Timeout = TimeSpan.FromSeconds(5) };
        var command = await http.GetFromJsonAsync<JsonElement>("/commands/next");
        Assert.Equal(bound ? "pasteImageToDocument" : "pasteImage", command.GetProperty("type").GetString());
        var payload = command.GetProperty("payload");
        Assert.Equal(placement, payload.GetProperty("placement").GetString());
        Assert.Equal(image, Convert.FromBase64String(payload.GetProperty("imageBase64").GetString()!));
        Assert.True(payload.GetProperty("preserveTransparency").GetBoolean());
        if (bound)
        {
            var reference = payload.GetProperty("targetDocument");
            Assert.Equal("ps-session", reference.GetProperty("sessionId").GetString());
            Assert.Equal(10, reference.GetProperty("documentId").GetInt32());
        }
        else Assert.Equal(JsonValueKind.Null, payload.GetProperty("targetDocument").ValueKind);
        using var response = await http.PostAsJsonAsync($"/commands/{command.GetProperty("id").GetString()}/result",
            new { success = !legacyPanel,
                message = legacyPanel ? "Unknown command: pasteImageToDocument" : "Pixels written",
                data = new { layerKind = "pixel" } });
        response.EnsureSuccessStatusCode();
        var result = await paste.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(!legacyPanel, result.Success);
        if (legacyPanel)
        {
            Assert.Contains("0.2.3", result.Message);
            var next = await http.GetFromJsonAsync<JsonElement>("/commands/next");
            Assert.Equal("noop", next.GetProperty("type").GetString());
        }
        else Assert.Equal("pixel", result.Data!.Value.GetProperty("layerKind").GetString());
    }

    [Fact]
    public async Task EnablingPhotoshopAfterSaiStartupStartsExistingServer()
    {
        var portProbe = new TcpListener(IPAddress.Loopback, 0);
        portProbe.Start();
        var port = ((IPEndPoint)portProbe.LocalEndpoint).Port;
        portProbe.Stop();
        var settings = new AppSettings { PhotoshopBridge = { UxpEnabled = false, LocalCommandPort = port } };
        using var server = new PhotoshopUxpBridgeServer(Options.Create(settings), NullLogger<PhotoshopUxpBridgeServer>.Instance);
        Assert.False(server.IsAvailable);

        settings.PhotoshopBridge.UxpEnabled = true;

        Assert.True(server.IsAvailable);
        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
        var response = await http.GetStringAsync($"http://127.0.0.1:{port}/commands/next");
        Assert.Contains("noop", response);
        Assert.True(server.IsPluginConnected);
        server.Dispose();
        Assert.False(server.IsAvailable);
    }
}
