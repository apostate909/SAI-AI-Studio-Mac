using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.MacCore.Licensing;

/// <summary>钥匙串密钥加密磁盘记录，钥匙串副本检测删除、篡改或单独回滚磁盘文件。</summary>
public sealed class KeychainLicenseStateStore : ILicenseStateStore
{
    private readonly ISecretStore _secrets;
    private readonly string _path;
    private readonly byte[] _binding;
    private readonly string _account;
    public KeychainLicenseStateStore(ISecretStore secrets, string directory, string deviceId)
    {
        _secrets = secrets;
        _path = Path.Combine(directory, "license-state.bin");
        _binding = Encoding.UTF8.GetBytes(deviceId);
        _account = "license-state-v1-" + deviceId;
    }

    public LicenseClientState Load()
    {
        var anchor = _secrets.Read(_account);
        if (File.Exists(_path) && new FileInfo(_path).Length > 1024 * 1024)
            throw new CryptographicException("授权记录大小异常。");
        var file = File.Exists(_path) ? File.ReadAllBytes(_path) : null;
        if (file is null && anchor is null) return new();
        var state = Decode(anchor ?? file!);
        if (file is null || anchor is null || !file.AsSpan().SequenceEqual(anchor))
            state.RequiresOnlineVerification = true;
        return state;
    }

    public void Save(LicenseClientState state)
    {
        var key = _secrets.Read(_account + "-key");
        if (key is null)
        {
            key = RandomNumberGenerator.GetBytes(32);
            _secrets.Write(_account + "-key", key);
        }
        try
        {
            var plain = JsonSerializer.SerializeToUtf8Bytes(state, SignedDocumentVerifier.JsonOptions);
            var blob = new byte[28 + plain.Length];
            RandomNumberGenerator.Fill(blob.AsSpan(0, 12));
            using var aes = new AesGcm(key, 16);
            aes.Encrypt(blob.AsSpan(0, 12), plain, blob.AsSpan(28), blob.AsSpan(12, 16), _binding);
            Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
            using (var stream = new FileStream(_path + ".tmp", FileMode.Create, FileAccess.Write, FileShare.None))
            {
                stream.Write(blob);
                stream.Flush(true);
            }
            File.Move(_path + ".tmp", _path, true);
            _secrets.Write(_account, blob);
        }
        finally { CryptographicOperations.ZeroMemory(key); }
    }

    private LicenseClientState Decode(byte[] blob)
    {
        var key = _secrets.Read(_account + "-key") ?? throw new CryptographicException("钥匙串记录缺失。");
        try
        {
            if (blob.Length < 28) throw new CryptographicException("授权记录损坏。");
            var plain = new byte[blob.Length - 28];
            using var aes = new AesGcm(key, 16);
            aes.Decrypt(blob.AsSpan(0, 12), blob.AsSpan(28), blob.AsSpan(12, 16), plain, _binding);
            return JsonSerializer.Deserialize<LicenseClientState>(plain, SignedDocumentVerifier.JsonOptions)
                ?? throw new CryptographicException("授权记录损坏。");
        }
        finally { CryptographicOperations.ZeroMemory(key); }
    }
}
