namespace SAIStudio.MacCore.Licensing;

/// <summary>由 macOS 钥匙串提供；测试中可以注入隔离存储。</summary>
public interface ISecretStore
{
    byte[]? Read(string account);
    void Write(string account, byte[] value);
}
