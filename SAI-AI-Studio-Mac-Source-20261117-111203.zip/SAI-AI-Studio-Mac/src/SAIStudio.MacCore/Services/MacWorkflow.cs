using SAIStudio.Bridge;
using SAIStudio.Core.Services;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.MacCore.Imaging;
using SAIStudio.MacCore.Photoshop;
using SAIStudio.MacCore.Storage;

namespace SAIStudio.MacCore.Services;

public sealed class MacWorkflow(IApplicationAccess access, IMacPhotoshop photoshop, MacHistoryStore history)
{
    public async Task<PhotoshopUxpSelectionCapture> CaptureAsync(bool canvas, CancellationToken ct)
    {
        access.EnsureBusinessAllowed();
        var capture = await photoshop.CaptureAsync(canvas, ct);
        if (capture.SourceDocument is not { IsValid: true } reference ||
            reference.CanvasWidth != capture.DocumentWidth || reference.CanvasHeight != capture.DocumentHeight)
            throw new InvalidDataException("来源文档信息无效，请更新 Photoshop 插件。");
        MacImages.ValidateSize(capture.DocumentWidth, capture.DocumentHeight);
        return capture;
    }

    public async Task<MacResult> GenerateAsync(IAIBackend backend, PhotoshopUxpSelectionCapture capture,
        string prompt, double strength, int seed, CancellationToken ct)
    {
        access.EnsureBusinessAllowed();
        if (string.IsNullOrWhiteSpace(prompt)) throw new InvalidOperationException("请输入要求。");
        var source = MacImages.Png(Convert.FromBase64String(capture.ImageBase64));
        var original = await backend.GenerateAsync(source, null, prompt, null, strength, seed, ct);
        ct.ThrowIfCancellationRequested();
        // 生成期间授权可能变化；不得在过期后自动回填。结果仍保存，避免丢失已生成图片。
        return Save(original, capture, prompt, (backend as IAIBackendRequestDiagnostics)?.LastRequestDiagnosticText ?? backend.DisplayName);
    }

    public MacResult Import(byte[] bytes, PhotoshopUxpSelectionCapture? capture, string prompt)
    {
        access.EnsureBusinessAllowed();
        return Save(bytes, capture, prompt, "浏览器 / 文件 / 剪贴板导入");
    }

    private MacResult Save(byte[] bytes, PhotoshopUxpSelectionCapture? capture, string prompt, string diagnostics)
    {
        var original = MacImages.Png(bytes);
        var image = capture is null ? original : MacImages.Compose(original, capture);
        var result = new MacResult(Guid.NewGuid(), DateTimeOffset.UtcNow, prompt, original, image,
            capture is null ? [] : MacImages.Png(Convert.FromBase64String(capture.ImageBase64)),
            capture is null ? null : capture with { ImageBase64 = "" }, diagnostics);
        history.Save(result);
        return result;
    }

    public async Task PasteToSourceAsync(MacResult result, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        access.EnsureBusinessAllowed();
        var document = result.Capture?.SourceDocument ?? throw new InvalidOperationException("该图片没有来源文档，请使用“加入当前选区”。");
        await photoshop.PasteAsync(result.Image, document, ct);
    }

    public async Task PasteToCurrentAsync(MacResult result, CancellationToken ct)
    {
        var capture = await CaptureAsync(false, ct);
        var image = MacImages.Compose(result.Original, capture);
        ct.ThrowIfCancellationRequested();
        access.EnsureBusinessAllowed();
        await photoshop.PasteAsync(image, capture.SourceDocument!, ct);
    }
}
