using SAIStudio.Bridge;
using SkiaSharp;

namespace SAIStudio.MacCore.Imaging;

public static class MacImages
{
    public const long MaximumPixels = 80_000_000;
    public static SKBitmap Decode(byte[] bytes)
    {
        if (bytes.Length > 64 * 1024 * 1024) throw new InvalidDataException("图片文件超过 64 MB。");
        using var data = SKData.CreateCopy(bytes);
        using var codec = SKCodec.Create(data) ?? throw new InvalidDataException("无法识别图片。");
        ValidateSize(codec.Info.Width, codec.Info.Height);
        return SKBitmap.Decode(bytes) ?? throw new InvalidDataException("图片解码失败。");
    }

    public static void ValidateSize(int width, int height)
    {
        if (width < 1 || height < 1 || (long)width * height > MaximumPixels)
            throw new InvalidDataException("画布尺寸无效或超过 8000 万像素。");
    }

    public static byte[] Png(byte[] bytes)
    {
        using var image = Decode(bytes);
        return Encode(image);
    }

    public static byte[] Encode(SKBitmap bitmap)
    {
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 100);
        return data.ToArray();
    }

    /// <summary>按来源文档的矩形选区居中覆盖裁切，选区外透明，像素原点与 PS 一致。</summary>
    public static byte[] Compose(byte[] bytes, PhotoshopUxpSelectionCapture capture)
    {
        ValidateSize(capture.DocumentWidth, capture.DocumentHeight);
        var b = capture.Bounds;
        if (b.Left < 0 || b.Top < 0 || b.Right > capture.DocumentWidth || b.Bottom > capture.DocumentHeight ||
            b.Width < 1 || b.Height < 1)
            throw new InvalidDataException("Photoshop 选区边界无效。");
        using var source = Decode(bytes);
        using var result = new SKBitmap(capture.DocumentWidth, capture.DocumentHeight, SKColorType.Rgba8888, SKAlphaType.Premul);
        using var canvas = new SKCanvas(result);
        canvas.Clear(SKColors.Transparent);
        canvas.ClipRect(new SKRect(b.Left, b.Top, b.Right, b.Bottom));
        var scale = Math.Max((float)b.Width / source.Width, (float)b.Height / source.Height);
        var w = source.Width * scale; var h = source.Height * scale;
        var left = b.Left + (b.Width - w) / 2; var top = b.Top + (b.Height - h) / 2;
        using var paint = new SKPaint { FilterQuality = SKFilterQuality.High };
        canvas.DrawBitmap(source, new SKRect(left, top, left + w, top + h), paint);
        return Encode(result);
    }
}
