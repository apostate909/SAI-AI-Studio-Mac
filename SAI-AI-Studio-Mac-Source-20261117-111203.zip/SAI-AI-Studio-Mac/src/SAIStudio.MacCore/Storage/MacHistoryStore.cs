using System.Text.Json;
using SAIStudio.Bridge;
using SAIStudio.Core.Services.Licensing;

namespace SAIStudio.MacCore.Storage;

public sealed record MacResult(Guid Id, DateTimeOffset CreatedUtc, string Prompt, byte[] Original,
    byte[] Image, byte[] Source, PhotoshopUxpSelectionCapture? Capture, string Diagnostics, bool Favorite = false);

/// <summary>每张结果独立原子保存；最多保留 20 张，不把历史写入签名 .app 内。</summary>
public sealed class MacHistoryStore(string directory)
{
    private readonly object _gate = new();
    public IReadOnlyList<MacResult> Load()
    {
        lock (_gate)
        {
            Directory.CreateDirectory(directory);
            var results = new List<MacResult>();
            foreach (var path in Directory.EnumerateFiles(directory, "*.json"))
            {
                if (!Guid.TryParseExact(Path.GetFileNameWithoutExtension(path), "N", out _)) continue;
                try
                {
                    if (new FileInfo(path).Length > 256L * 1024 * 1024) continue;
                    var entry = JsonSerializer.Deserialize<MacResult>(File.ReadAllBytes(path), SignedDocumentVerifier.JsonOptions);
                    if (entry is not null) results.Add(entry);
                }
                catch (Exception ex) when (ex is JsonException or IOException or FormatException) { }
            }
            return results.OrderByDescending(x => x.CreatedUtc).Take(20).ToArray();
        }
    }
    public void Save(MacResult result)
    {
        lock (_gate)
        {
            Directory.CreateDirectory(directory);
            var path = Path.Combine(directory, result.Id.ToString("N") + ".json");
            File.WriteAllBytes(path + ".tmp", JsonSerializer.SerializeToUtf8Bytes(result, SignedDocumentVerifier.JsonOptions));
            File.Move(path + ".tmp", path, true);
            // 不依赖文件修改时间，收藏切换不会让旧图片逃离容量限制。
            var entries = Directory.EnumerateFiles(directory, "*.json").Select(p =>
            {
                try { return (Path: p, Entry: JsonSerializer.Deserialize<MacResult>(File.ReadAllBytes(p), SignedDocumentVerifier.JsonOptions)); }
                catch (Exception ex) when (ex is JsonException or IOException) { return (Path: p, Entry: (MacResult?)null); }
            }).Where(x => x.Entry is not null).OrderByDescending(x => x.Entry!.CreatedUtc).Skip(20).ToArray();
            foreach (var entry in entries) File.Delete(entry.Path);
        }
    }
    public void Delete(Guid id)
    {
        lock (_gate) File.Delete(Path.Combine(directory, id.ToString("N") + ".json"));
    }
}
