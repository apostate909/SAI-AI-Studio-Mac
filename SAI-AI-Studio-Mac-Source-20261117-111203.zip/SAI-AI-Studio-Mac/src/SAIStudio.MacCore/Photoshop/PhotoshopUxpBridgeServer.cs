using System.Collections.Concurrent;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SAIStudio.Shared;

namespace SAIStudio.Bridge;

/// <summary>Mac 使用 Kestrel 实现同一 UXP 协议，不依赖 Windows HTTP.SYS / URL ACL。</summary>
public sealed class PhotoshopUxpBridgeServer : IDisposable
{
    private readonly PhotoshopBridgeSettings _settings;
    private readonly ILogger<PhotoshopUxpBridgeServer> _logger;
    private readonly object _gate = new();
    private readonly ConcurrentQueue<PhotoshopUxpCommandEnvelope> _queue = new();
    private readonly ConcurrentDictionary<string, TaskCompletionSource<PhotoshopUxpCommandResult>> _waiting = new();
    private WebApplication? _app;
    private long _lastSeen;
    private bool _disposed;
    public PhotoshopUxpBridgeServer(IOptions<AppSettings> options, ILogger<PhotoshopUxpBridgeServer> logger)
    {
        _settings = options.Value.PhotoshopBridge; _logger = logger; EnsureStarted();
    }
    public bool IsAvailable { get { EnsureStarted(); lock (_gate) return !_disposed && _app is not null; } }
    public bool IsPluginConnected => DateTime.UtcNow.Ticks - Interlocked.Read(ref _lastSeen) < TimeSpan.FromSeconds(10).Ticks;
    private void Seen() => Interlocked.Exchange(ref _lastSeen, DateTime.UtcNow.Ticks);
    private void EnsureStarted()
    {
        lock (_gate)
        {
            if (_disposed || !_settings.UxpEnabled || _app is not null) return;
            WebApplication? app = null;
            try
            {
                var builder = WebApplication.CreateSlimBuilder(new WebApplicationOptions
                {
                    Args = [], ContentRootPath = AppContext.BaseDirectory, EnvironmentName = "Production"
                });
                builder.Logging.ClearProviders();
                builder.WebHost.UseKestrel(options => options.Limits.MaxRequestBodySize = 128L * 1024 * 1024)
                    .UseUrls($"http://127.0.0.1:{_settings.LocalCommandPort}");
                app = builder.Build();
                app.Use(async (context, next) =>
                {
                    context.Response.Headers.AccessControlAllowOrigin = "*";
                    context.Response.Headers.AccessControlAllowMethods = "GET, POST, OPTIONS";
                    context.Response.Headers.AccessControlAllowHeaders = "Content-Type";
                    if (context.Request.Method == "OPTIONS") { context.Response.StatusCode = 204; return; }
                    await next(context);
                });
                app.MapGet("/status", () => Results.Json(new { ok = true, pluginConnected = IsPluginConnected, pending = _queue.Count }));
                app.MapGet("/commands/next", () =>
                {
                    Seen();
                    while (_queue.TryDequeue(out var command))
                    {
                        if (_waiting.TryGetValue(command.Id, out var waiter) && !waiter.Task.IsCompleted)
                            return Results.Json((object)command);
                    }
                    return Results.Json((object)new { id = "", type = "noop" });
                });
                app.MapPost("/commands/{id}/result", async (string id, HttpContext context) =>
                {
                    var result = await context.Request.ReadFromJsonAsync<PhotoshopUxpCommandResult>(cancellationToken: context.RequestAborted);
                    if (result is null) return Results.BadRequest();
                    Seen();
                    if (_waiting.TryRemove(id, out var waiter)) waiter.TrySetResult(result);
                    return Results.Json(new { ok = true });
                });
                app.StartAsync().GetAwaiter().GetResult(); _app = app;
            }
            catch (Exception ex)
            {
                if (app is not null) app.DisposeAsync().AsTask().GetAwaiter().GetResult();
                _logger.LogWarning(ex, "Mac Photoshop bridge could not start on {Port}", _settings.LocalCommandPort);
            }
        }
    }
    public async Task<PhotoshopUxpCommandResult> SendCommandAsync(string type, object? payload = null, CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        if (!IsAvailable) return PhotoshopUxpCommandResult.Fail("本地桥接端口不可用，请关闭其他 Studio 实例后重试。");
        var id = Guid.NewGuid().ToString("N");
        var waiter = new TaskCompletionSource<PhotoshopUxpCommandResult>(TaskCreationOptions.RunContinuationsAsynchronously);
        _waiting[id] = waiter;
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(Math.Clamp(_settings.CommandTimeoutSeconds, 1, 120)));
        using var registration = timeout.Token.Register(() => waiter.TrySetCanceled(timeout.Token));
        _queue.Enqueue(new(id, type, payload is null ? null : JsonSerializer.SerializeToElement(payload, new JsonSerializerOptions(JsonSerializerDefaults.Web)), DateTime.UtcNow));
        try { return await waiter.Task; }
        catch (OperationCanceledException) { return PhotoshopUxpCommandResult.Fail("Photoshop 命令已取消或超时。"); }
        finally { _waiting.TryRemove(id, out _); }
    }
    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return; _disposed = true;
            foreach (var waiter in _waiting.Values) waiter.TrySetCanceled();
            _waiting.Clear(); _queue.Clear();
            _app?.DisposeAsync().AsTask().GetAwaiter().GetResult(); _app = null;
        }
    }
}

public sealed record PhotoshopUxpCommandEnvelope(string Id, string Type, JsonElement? Payload, DateTime CreatedAtUtc);
public sealed record PhotoshopUxpCommandResult(bool Success, string Message, JsonElement? Data = null)
{
    public static PhotoshopUxpCommandResult Fail(string message) => new(false, message);
}
