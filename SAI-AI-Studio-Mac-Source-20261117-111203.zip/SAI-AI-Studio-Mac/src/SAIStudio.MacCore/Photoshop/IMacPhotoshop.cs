using SAIStudio.Bridge;
using SAIStudio.Shared.Services;

namespace SAIStudio.MacCore.Photoshop;

public interface IMacPhotoshop
{
    bool IsConnected { get; }
    Task<PhotoshopUxpSelectionCapture> CaptureAsync(bool canvas, CancellationToken ct);
    Task PasteAsync(byte[] png, PhotoshopDocumentReference document, CancellationToken ct);
}

public sealed class MacPhotoshop(PhotoshopUxpBridge bridge) : IMacPhotoshop
{
    public bool IsConnected => bridge.IsConnected;
    public async Task<PhotoshopUxpSelectionCapture> CaptureAsync(bool canvas, CancellationToken ct)
    {
        if (!IsConnected) throw new InvalidOperationException("请打开 Photoshop 和 SAI AI Studio Bridge 插件面板。");
        return await (canvas ? bridge.CaptureCanvasAsync(ct) : bridge.CaptureSelectionAsync(ct))
            ?? throw new InvalidOperationException(bridge.LastSelectionCaptureFailureMessage ?? "无法捕获 Photoshop 图像。");
    }
    public async Task PasteAsync(byte[] png, PhotoshopDocumentReference document, CancellationToken ct)
    {
        var result = await bridge.PasteImageAsync(png, true, ct, true, document);
        if (!result.Success) throw new InvalidOperationException(result.Message);
    }
}
