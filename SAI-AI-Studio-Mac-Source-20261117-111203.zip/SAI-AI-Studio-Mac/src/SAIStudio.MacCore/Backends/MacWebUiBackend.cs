using System.Net.Http.Json;
using System.Text.Json;
using SAIStudio.Core.Services;
using SAIStudio.MacCore.Imaging;
using SAIStudio.Shared;

namespace SAIStudio.MacCore.Backends;

/// <summary>macOS 的 WebUI 图生图传输；图像解码采用 Skia，不依赖 Windows GDI。</summary>
public sealed class MacWebUiBackend(HttpClient http, StableDiffusionWebUISettings settings) : IAIBackend
{
    public BackendType Type => BackendType.StableDiffusionWebUI;
    public string DisplayName => "Stable Diffusion WebUI";
    private string BaseUrl => settings.BaseUrl.TrimEnd('/');
    public async Task<bool> PingAsync(CancellationToken ct = default)
    {
        using var response = await http.GetAsync(BaseUrl + "/sdapi/v1/sd-models", ct);
        return response.IsSuccessStatusCode;
    }
    public async Task<byte[]> GenerateAsync(byte[] sourceImage, byte[]? maskImage, string? prompt,
        EditStrength? strength, double? denoisingStrength, int seed, CancellationToken ct = default)
    {
        using var source = MacImages.Decode(sourceImage);
        var width = settings.SizeStrategy == StableDiffusionSizeStrategy.Fixed ? settings.Width : source.Width;
        var height = settings.SizeStrategy == StableDiffusionSizeStrategy.Fixed ? settings.Height : source.Height;
        var scale = Math.Min(1.0, 2048.0 / Math.Max(width, height));
        width = Math.Clamp((int)Math.Round(width * scale / 8) * 8, 64, 4096);
        height = Math.Clamp((int)Math.Round(height * scale / 8) * 8, 64, 4096);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(Math.Clamp(settings.TimeoutSeconds, 30, 3600)));
        try
        {
            if (!string.IsNullOrWhiteSpace(settings.ModelTitle))
            {
                using var options = await http.PostAsJsonAsync(BaseUrl + "/sdapi/v1/options",
                    new { sd_model_checkpoint = settings.ModelTitle }, timeout.Token);
                options.EnsureSuccessStatusCode();
            }
            var fullPrompt = string.IsNullOrWhiteSpace(settings.LoraName) ? prompt :
                $"{prompt}, <lora:{settings.LoraName}:{settings.LoraWeight.ToString(System.Globalization.CultureInfo.InvariantCulture)}>";
            var request = new Dictionary<string, object?>
            {
                ["init_images"] = new[] { Convert.ToBase64String(sourceImage) }, ["prompt"] = fullPrompt,
                ["negative_prompt"] = settings.NegativePrompt, ["denoising_strength"] = denoisingStrength ?? 0.5,
                ["sampler_name"] = settings.SamplerName, ["steps"] = Math.Clamp(settings.Steps, 1, 150),
                ["cfg_scale"] = settings.CfgScale, ["seed"] = seed
            };
            if (settings.SizeStrategy != StableDiffusionSizeStrategy.WebUIDefault) { request["width"] = width; request["height"] = height; }
            using var response = await http.PostAsJsonAsync(BaseUrl + "/sdapi/v1/img2img", request, timeout.Token);
            response.EnsureSuccessStatusCode();
            using var document = await response.Content.ReadFromJsonAsync<JsonDocument>(cancellationToken: timeout.Token)
                ?? throw new InvalidDataException("WebUI 没有返回结果。");
            var images = document.RootElement.GetProperty("images");
            if (images.GetArrayLength() == 0) throw new InvalidDataException("WebUI 没有返回图片。");
            var encoded = images[0].GetString()!;
            return Convert.FromBase64String(encoded.StartsWith("data:") ? encoded[(encoded.IndexOf(',') + 1)..] : encoded);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            using var interruptTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(3));
            try { using var response = await http.PostAsync(BaseUrl + "/sdapi/v1/interrupt", null, interruptTimeout.Token); }
            catch (Exception ex) when (ex is HttpRequestException or OperationCanceledException) { }
            throw;
        }
    }
}
