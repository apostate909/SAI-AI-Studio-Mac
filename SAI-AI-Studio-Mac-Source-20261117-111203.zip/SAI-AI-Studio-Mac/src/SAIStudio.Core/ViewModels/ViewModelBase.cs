using CommunityToolkit.Mvvm.ComponentModel;

namespace SAIStudio.Core;

/// <summary>
/// 所有 ViewModel 的基类。
/// 继承自 CommunityToolkit.Mvvm 的 ObservableObject，
/// 提供统一的属性变更通知和错误处理钩子。
/// </summary>
public abstract partial class ViewModelBase : ObservableObject
{
    /// <summary>
    /// 当前 ViewModel 是否正在执行异步操作。
    /// UI 层可绑定此属性来显示加载状态。
    /// </summary>
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsNotBusy))]
    private bool _isBusy;

    public bool IsNotBusy => !IsBusy;

    /// <summary>
    /// 在派生类的构造函数完成后调用的初始化钩子。
    /// </summary>
    public virtual Task InitializeAsync() => Task.CompletedTask;
}
