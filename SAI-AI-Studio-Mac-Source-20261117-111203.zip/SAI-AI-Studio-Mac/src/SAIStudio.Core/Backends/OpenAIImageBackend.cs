using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SAIStudio.Core.Services;
using SAIStudio.Shared;

namespace SAIStudio.Core.Backends;

/// <summary>Responses 图像工作流：整理要求、生图、可选审核及最多一次二改。</summary>
public sealed class OpenAIImageBackend : IAIBackend, IAIBackendRequestDiagnostics, IGenerationStageReporting
{
    private readonly HttpClient _http;
    private readonly ILogger<OpenAIImageBackend> _logger;
    private readonly OpenAIImageSettings _settings;
    public BackendType Type => BackendType.OpenAIImage;
    public string DisplayName => "GPT Image";
    public string? LastRequestDiagnosticText { get; private set; }
    public event Action<string>? StageChanged;

    public OpenAIImageBackend(HttpClient http, IOptions<AppSettings> options, ILogger<OpenAIImageBackend> logger)
    {
        _http = http;
        _logger = logger;
        _settings = options.Value.OpenAIImage;
    }

    public async Task<bool> PingAsync(CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(_settings.ApiKey)) return false;
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromSeconds(30));
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get,
                $"{OpenAIImageApiUrl.NormalizeBaseUrl(_settings.BaseUrl)}/models");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _settings.ApiKey);
            using var response = await _http.SendAsync(request, deadline.Token);
            return response.IsSuccessStatusCode;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "OpenAI Models API connection failed");
            return false;
        }
    }

    public async Task<byte[]> GenerateAsync(byte[] sourceImage, byte[]? maskImage, string? prompt,
        EditStrength? strength, double? denoisingStrength, int seed, CancellationToken ct = default)
    {
        LastRequestDiagnosticText = null;
        // 固定本轮配置，避免等待期间切换模型使审核和生图使用不同配置。
        var settings = JsonSerializer.Deserialize<OpenAIImageSettings>(JsonSerializer.Serialize(_settings))!;
        if (string.IsNullOrWhiteSpace(settings.ApiKey)) throw new InvalidOperationException("OpenAI API Key 未配置。");
        if (string.IsNullOrWhiteSpace(settings.TextModel)) throw new InvalidOperationException("请选择思考模型。");
        if (string.IsNullOrWhiteSpace(settings.Model)) throw new InvalidOperationException("请选择图片模型。");
        if (string.IsNullOrWhiteSpace(prompt)) throw new InvalidOperationException("请输入你的要求。");
        var baseUrl = OpenAIImageApiUrl.NormalizeBaseUrl(settings.BaseUrl);
        var size = OpenAIImageSize.GetRequestSize(settings, sourceImage);
        var diagnostic = new List<string>
        {
            $"BaseUrl: {new Uri(baseUrl).Host}{new Uri(baseUrl).AbsolutePath}", "Endpoint: POST /responses",
            $"Thinking model: {settings.TextModel}", $"Thinking effort: {settings.TextReasoningEffort}",
            $"Image model: {settings.Model}", $"Image quality: {settings.ImageQuality}",
            $"Review: {(settings.EnableReview ? "enabled; at most one edit" : "disabled")}",
            $"Request size: {size}", $"Source image bytes: {sourceImage.Length}",
            $"Request timeout: {Math.Clamp(settings.TimeoutSeconds, 300, 3600)} seconds per stage"
        };
        void Record(string text)
        {
            diagnostic.Add(Redact(text, settings.ApiKey));
            LastRequestDiagnosticText = string.Join('\n', diagnostic);
        }
        void Stage(string text) { Record($"Stage: {text}"); StageChanged?.Invoke(text); }

        Stage("思考模型正在整理要求");
        using var plan = await RequestAsync(settings, baseUrl,
            BuildRequest(settings, PlannerPrompt(prompt, sourceImage.Length > 0), [sourceImage]), "整理要求", Record, ct);
        var plannedPrompt = ReadText(plan.RootElement);
        if (string.IsNullOrWhiteSpace(plannedPrompt)) throw new InvalidOperationException("思考模型没有返回整理后的生图指令。");
        Record($"Prepared image instruction:\n{plannedPrompt}");
        Stage("图片模型正在生成");
        using var generation = await RequestAsync(settings, baseUrl,
            BuildRequest(settings, plannedPrompt, [sourceImage], size, "auto"), "生成图片", Record, ct);
        var image = ReadImage(generation.RootElement, Record);

        if (settings.EnableReview)
        {
            Stage("思考模型正在审核生成结果");
            var reviewImages = sourceImage.Length > 0 ? new[] { sourceImage, image } : new[] { image };
            using var review = await RequestAsync(settings, baseUrl,
                BuildRequest(settings, ReviewPrompt(prompt, plannedPrompt, sourceImage.Length > 0), reviewImages), "审核结果", Record, ct);
            var reviewText = ReadText(review.RootElement);
            if (string.IsNullOrWhiteSpace(reviewText)) throw new InvalidOperationException("审核模型没有返回结论，已停止自动回填。");
            Record($"Review result:\n{reviewText}");
            if (!string.Equals(reviewText.Trim(), "PASS", StringComparison.OrdinalIgnoreCase))
            {
                Stage("图片模型正在按审核意见修改（仅一轮）");
                var refineImages = sourceImage.Length > 0 ? new[] { image, sourceImage } : new[] { image };
                var refinePrompt = $"编辑 Image A（本轮生成结果）。{(sourceImage.Length > 0 ? "Image B 是原始参考图，请参考它保留用户要求不变的部分。" : "")}\n"
                    + $"用户原始要求：\n{prompt}\n审核修正指令：\n{reviewText}";
                using var refinement = await RequestAsync(settings, baseUrl,
                    BuildRequest(settings, refinePrompt, refineImages, size, "edit"), "按审核意见修改", Record, ct);
                image = ReadImage(refinement.RootElement, Record);
                Record("Review correction: completed one edit; no further review loop");
            }
        }
        ct.ThrowIfCancellationRequested();
        Stage("图像工作流完成，准备保存和回填");
        _logger.LogInformation("OpenAI image workflow completed TextModel={TextModel} ImageModel={ImageModel} Review={Review}",
            settings.TextModel, settings.Model, settings.EnableReview);
        return image;
    }

    private static Dictionary<string, object> BuildRequest(OpenAIImageSettings settings, string prompt,
        IEnumerable<byte[]> images, string? size = null, string? action = null)
    {
        var content = new List<object> { new { type = "input_text", text = prompt } };
        foreach (var image in images.Where(x => x.Length > 0))
            content.Add(new { type = "input_image", image_url = $"data:image/png;base64,{Convert.ToBase64String(image)}", detail = "auto" });
        var request = new Dictionary<string, object>
        {
            ["model"] = settings.TextModel, ["store"] = false,
            ["input"] = new[] { new { role = "user", content } }
        };
        if (!string.IsNullOrWhiteSpace(settings.TextReasoningEffort) && settings.TextReasoningEffort != "auto")
            request["reasoning"] = new { effort = settings.TextReasoningEffort };
        if (size != null)
        {
            request["tool_choice"] = new { type = "image_generation" };
            request["tools"] = new[] { new { type = "image_generation", model = settings.Model,
                quality = settings.ImageQuality, size, background = "auto", action, output_format = "png" } };
        }
        return request;
    }

    private async Task<JsonDocument> RequestAsync(OpenAIImageSettings settings, string baseUrl,
        Dictionary<string, object> payload, string stage, Action<string> record, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        var configuredTimeout = TimeSpan.FromSeconds(Math.Clamp(settings.TimeoutSeconds, 300, 3600));
        var effectiveTimeout = _http.Timeout == Timeout.InfiniteTimeSpan || _http.Timeout > configuredTimeout
            ? configuredTimeout : _http.Timeout;
        // 每个阶段使用本轮配置独立计时；收到响应头之后，读响应体也受同一截止时间约束。
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(effectiveTimeout);
        var timer = Stopwatch.StartNew();
        record($"Request stage: {stage}; timeout: {effectiveTimeout.TotalSeconds:0.###} seconds");
        _logger.LogInformation("Responses request started Stage={Stage} Model={Model} TimeoutSeconds={TimeoutSeconds}",
            stage, settings.TextModel, effectiveTimeout.TotalSeconds);
        using var request = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/responses") { Content = JsonContent.Create(payload) };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", settings.ApiKey);
        try
        {
            using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, deadline.Token);
            var requestId = response.Headers.TryGetValues("x-request-id", out var values) ? string.Join(", ", values) : "(未提供)";
            record($"Response stage: {stage}; HTTP: {(int)response.StatusCode}; Request ID: {requestId}; headers after: {timer.Elapsed.TotalSeconds:0.###} seconds");
            var raw = await response.Content.ReadAsStringAsync(deadline.Token);
            record($"Response received: {stage}; elapsed: {timer.Elapsed.TotalSeconds:0.###} seconds");
            if (!response.IsSuccessStatusCode)
            {
                raw = Redact(raw, settings.ApiKey);
                record($"HTTP: {(int)response.StatusCode}\nRequest ID: {requestId}\n服务端完整错误：\n{raw}");
                _logger.LogWarning("Responses HTTP failure Stage={Stage} StatusCode={StatusCode} RequestId={RequestId} ElapsedSeconds={ElapsedSeconds}",
                    stage, (int)response.StatusCode, Redact(requestId, settings.ApiKey), timer.Elapsed.TotalSeconds);
                throw new InvalidOperationException(HttpError(response.StatusCode, raw));
            }
            var document = JsonDocument.Parse(raw);
            try
            {
                var root = document.RootElement;
                if (root.TryGetProperty("error", out var error) && error.ValueKind != JsonValueKind.Null)
                    throw new InvalidOperationException($"Responses 返回错误：{Redact(error.ToString(), settings.ApiKey)}");
                if (root.TryGetProperty("status", out var status) && status.GetString() is { } state && state != "completed")
                {
                    var detail = root.TryGetProperty("incomplete_details", out var incomplete) ? incomplete.ToString() : "";
                    throw new InvalidOperationException($"Responses 尚未完成或已失败：{state} {Redact(detail, settings.ApiKey)}");
                }
                return document;
            }
            catch { document.Dispose(); throw; }
        }
        catch (OperationCanceledException ex) when (!ct.IsCancellationRequested)
        {
            var timedOut = deadline.IsCancellationRequested || ex.InnerException is TimeoutException;
            record($"Request failure: {stage}; elapsed: {timer.Elapsed.TotalSeconds:0.###} seconds; cause: {(timedOut ? "client timeout" : "request interrupted")}");
            _logger.LogWarning("Responses request interrupted Stage={Stage} ClientTimeout={ClientTimeout} ElapsedSeconds={ElapsedSeconds} TimeoutSeconds={TimeoutSeconds}",
                stage, timedOut, timer.Elapsed.TotalSeconds, effectiveTimeout.TotalSeconds);
            var message = timedOut
                ? $"OpenAI Responses 在“{stage}”阶段请求超时，已等待 {timer.Elapsed.TotalSeconds:0.#} 秒，等待上限 {effectiveTimeout.TotalSeconds:0.#} 秒。可在高级设置中提高请求超时；若仍失败，请检查网关的排队和转发记录。"
                : $"OpenAI Responses 在“{stage}”阶段请求被中断，已等待 {timer.Elapsed.TotalSeconds:0.#} 秒，请检查网关或网络状态。";
            throw new InvalidOperationException(message, ex);
        }
        catch (HttpRequestException ex)
        {
            record($"Request failure: {stage}; elapsed: {timer.Elapsed.TotalSeconds:0.###} seconds; cause: network error; detail: {ex.Message}");
            _logger.LogWarning("Responses network failure Stage={Stage} ElapsedSeconds={ElapsedSeconds}", stage, timer.Elapsed.TotalSeconds);
            throw new InvalidOperationException($"无法连接 OpenAI Responses API，请检查 BaseUrl 或网络状态。{Redact(ex.Message, settings.ApiKey)}", ex);
        }
    }

    private static string ReadText(JsonElement root)
    {
        var texts = new List<string>();
        if (root.TryGetProperty("output", out var output) && output.ValueKind == JsonValueKind.Array)
            foreach (var item in output.EnumerateArray())
            {
                if (!item.TryGetProperty("type", out var type) || type.GetString() != "message"
                    || !item.TryGetProperty("content", out var content) || content.ValueKind != JsonValueKind.Array) continue;
                foreach (var part in content.EnumerateArray())
                {
                    if (!part.TryGetProperty("type", out var partType)) continue;
                    if (partType.GetString() == "refusal") throw new InvalidOperationException("模型拒绝了本次请求，请调整要求后再试。");
                    if (partType.GetString() == "output_text" && part.TryGetProperty("text", out var text)) texts.Add(text.GetString() ?? "");
                }
            }
        // 部分兼容服务提供 SDK 风格的便捷字段。
        if (texts.Count == 0 && root.TryGetProperty("output_text", out var shortcut)) texts.Add(shortcut.GetString() ?? "");
        return string.Join('\n', texts).Trim();
    }

    private static byte[] ReadImage(JsonElement root, Action<string> record)
    {
        if (root.TryGetProperty("output", out var output) && output.ValueKind == JsonValueKind.Array)
            foreach (var item in output.EnumerateArray())
            {
                if (!item.TryGetProperty("type", out var type) || type.GetString() != "image_generation_call") continue;
                if (item.TryGetProperty("status", out var status) && status.GetString() != "completed") throw new InvalidOperationException("图片工具没有完成生成。");
                if (item.TryGetProperty("revised_prompt", out var revised)) record($"Image tool revised prompt:\n{revised.GetString()}");
                if (!item.TryGetProperty("result", out var result) || string.IsNullOrWhiteSpace(result.GetString())) continue;
                try
                {
                    var encoded = result.GetString()!;
                    if (encoded.StartsWith("data:", StringComparison.OrdinalIgnoreCase)) encoded = encoded[(encoded.IndexOf(',') + 1)..];
                    var image = Convert.FromBase64String(encoded);
                    if (image.Length == 0) throw new FormatException();
                    return image;
                }
                catch (FormatException ex) { throw new InvalidOperationException("图片工具返回了无效的 base64 图片。", ex); }
            }
        throw new InvalidOperationException("图片模型没有返回 image_generation_call 图片结果，请确认所选思考模型和服务支持图片工具。");
    }

    private static string PlannerPrompt(string prompt, bool hasSource) => $"""
        你是图像生成前的需求整理助手。请理解用户要求，整理成可直接交给图片模型执行的最终指令。
        只输出最终生图指令，不要输出思考过程、解释或标题。
        {(hasSource ? "Image A 是用户在绘画软件中的原始选区图，请结合图像理解修改目标。" : "没有参考图，请根据要求生成新图。")}
        改图时只修改用户指定部分，保留未提及区域。保留用户要求的构图、颜色、亮度、位置、大小、风格等约束。
        用户原始要求：
        {prompt}
        """;

    private static string ReviewPrompt(string prompt, string planned, bool hasSource) => $"""
        请审核生成结果是否满足用户原始要求，并检查应保留的部分是否改变。
        {(hasSource ? "Image A 是原始选区图，Image B 是生成结果。" : "Image A 是生成结果。")}
        满足要求时只输出 PASS。不满足时只输出可直接用于修改当前生成结果的一段修正指令，不要解释。
        用户原始要求：
        {prompt}
        第一次整理后的生图指令：
        {planned}
        """;

    private static string Redact(string value, string apiKey) => string.IsNullOrEmpty(apiKey)
        ? value : value.Replace(apiKey, "[已隐藏密钥]", StringComparison.Ordinal);

    private static string HttpError(HttpStatusCode code, string detail)
    {
        var message = code switch
        {
            HttpStatusCode.Unauthorized => "OpenAI Responses 接口鉴权失败，HTTP 401，请检查密钥及接口权限。",
            HttpStatusCode.Forbidden => "当前 API Key 没有使用所选模型或图片工具的权限，HTTP 403。",
            HttpStatusCode.NotFound => "Responses 接口或所选模型不可用，HTTP 404；模型列表可访问不代表 /v1/responses 和图片工具可用。",
            HttpStatusCode.BadRequest => "工作流参数被服务拒绝，HTTP 400，请核对模型、思考档位、图片档位和尺寸。",
            HttpStatusCode.RequestTimeout => "服务端返回请求超时，HTTP 408，请检查网关或上游服务的等待上限。",
            HttpStatusCode.BadGateway => "网关无法取得上游结果，HTTP 502，请检查网关转发状态。",
            HttpStatusCode.ServiceUnavailable => "网关或上游服务暂时不可用，HTTP 503，请检查服务状态或排队情况。",
            HttpStatusCode.GatewayTimeout => "网关等待上游结果超时，HTTP 504；提高客户端超时无法延长网关的等待上限。",
            (HttpStatusCode)429 when detail.Contains("insufficient_quota", StringComparison.OrdinalIgnoreCase) => "OpenAI 额度不足或计费状态不可用。",
            (HttpStatusCode)429 => "OpenAI 请求被限流，请稍后再试。",
            _ => $"OpenAI Responses 请求失败，HTTP {(int)code}。"
        };
        return $"{message} {detail}";
    }
}
