namespace SAIStudio.Core.Services;

internal static class OpenAIImageApiUrl
{
    public const string DefaultBaseUrl = "https://api.openai.com/v1";

    public static string NormalizeBaseUrl(string? baseUrl)
    {
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            return DefaultBaseUrl;
        }

        var normalized = baseUrl.Trim().TrimEnd('/');
        if (!Uri.TryCreate(normalized, UriKind.Absolute, out var uri))
        {
            return normalized;
        }

        var path = uri.AbsolutePath.TrimEnd('/');
        if (string.IsNullOrEmpty(path) || path == "/")
        {
            return $"{normalized}/v1";
        }

        return normalized;
    }
}
