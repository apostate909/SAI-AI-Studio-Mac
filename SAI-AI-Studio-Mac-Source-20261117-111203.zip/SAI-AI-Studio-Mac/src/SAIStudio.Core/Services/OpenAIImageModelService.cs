using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using SAIStudio.Shared;

namespace SAIStudio.Core.Services;

/// <summary>
/// 通过 OpenAI Models API 读取当前 API Key 可访问的 GPT Image 模型。
/// </summary>
public sealed class OpenAIImageModelService : IOpenAIImageModelService
{
    private readonly HttpClient _http;
    private readonly ILogger<OpenAIImageModelService> _logger;

    public OpenAIImageModelService(
        HttpClient http,
        ILogger<OpenAIImageModelService> logger)
    {
        _http = http;
        _logger = logger;
    }

    public async Task<IReadOnlyList<OpenAIImageModelInfo>> GetModelsAsync(
        OpenAIImageSettings settings,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(settings.ApiKey))
        {
            throw new InvalidOperationException("请先填写 OpenAI API Key。");
        }

        var baseUrl = OpenAIImageApiUrl.NormalizeBaseUrl(settings.BaseUrl);

        using var req = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/models");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", settings.ApiKey);

        try
        {
            using var resp = await _http.SendAsync(req, ct);
            if (!resp.IsSuccessStatusCode)
            {
                throw await CreateHttpFailureExceptionAsync(resp, settings.ApiKey, ct);
            }

            var payload = await resp.Content.ReadFromJsonAsync<ModelListResponse>(cancellationToken: ct);
            return payload?.Data?
                .Where(x => !string.IsNullOrWhiteSpace(x.Id))
                .Select(x => new OpenAIImageModelInfo(x.Id, x.Created, x.OwnedBy ?? "",
                    ReadOptions(x, "reasoning_efforts", "supported_reasoning_efforts"),
                    ReadOptions(x, "quality_options", "supported_quality", "image_qualities"),
                    ReadToolSupport(x)))
                .ToList()
                ?? [];
        }
        catch (TaskCanceledException ex) when (!ct.IsCancellationRequested)
        {
            throw new InvalidOperationException("读取 OpenAI 模型列表超时，请检查 BaseUrl 或网络状态。", ex);
        }
        catch (HttpRequestException ex)
        {
            throw new InvalidOperationException(
                $"无法连接 OpenAI Models API，请检查 BaseUrl 或网络状态。{ex.Message}",
                ex);
        }
        catch (InvalidOperationException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "OpenAI GPT Image model list failed.");
            throw;
        }
    }

    private static async Task<InvalidOperationException> CreateHttpFailureExceptionAsync(
        HttpResponseMessage resp,
        string apiKey,
        CancellationToken ct)
    {
        var detail = await resp.Content.ReadAsStringAsync(ct);
        detail = detail.Replace(apiKey, "[已隐藏密钥]", StringComparison.Ordinal);
        if (detail.Length > 300)
        {
            detail = detail[..300];
        }

        var message = resp.StatusCode switch
        {
            System.Net.HttpStatusCode.Unauthorized => "API Key 无效或已过期，请检查密钥。",
            System.Net.HttpStatusCode.Forbidden => "当前 API Key 没有读取模型列表的权限。",
            (System.Net.HttpStatusCode)429 => "请求被限流，请稍后再试。",
            _ => $"读取模型列表失败：HTTP {(int)resp.StatusCode}。"
        };

        if (!string.IsNullOrWhiteSpace(detail))
        {
            message = $"{message} {detail}";
        }

        return new InvalidOperationException(message);
    }

    private sealed class ModelListResponse
    {
        [JsonPropertyName("data")]
        public List<ModelItem>? Data { get; init; }
    }

    private sealed class ModelItem
    {
        [JsonPropertyName("id")]
        public string Id { get; init; } = "";

        [JsonPropertyName("created")]
        public long Created { get; init; }

        [JsonPropertyName("owned_by")]
        public string? OwnedBy { get; init; }

        [JsonExtensionData]
        public Dictionary<string, JsonElement>? Extra { get; init; }
    }

    private static IReadOnlyList<string>? ReadOptions(ModelItem item, params string[] names)
    {
        if (item.Extra == null) return null;
        foreach (var container in new[] { item.Extra }
            .Concat(item.Extra.Where(x => x.Key is "capabilities" or "metadata")
                .Where(x => x.Value.ValueKind == JsonValueKind.Object)
                .Select(x => x.Value.EnumerateObject().ToDictionary(p => p.Name, p => p.Value))))
        {
            foreach (var name in names)
            {
                if (container.TryGetValue(name, out var array) && array.ValueKind == JsonValueKind.Array)
                {
                    var values = array.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                        .Select(x => x.GetString()!.Trim().ToLowerInvariant())
                        .Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToArray();
                    if (values.Length > 0) return values;
                }
            }
        }
        return null;
    }

    private static bool? ReadToolSupport(ModelItem item)
    {
        if (item.Extra?.TryGetValue("supports_image_generation", out var value) == true
            && value.ValueKind is JsonValueKind.True or JsonValueKind.False) return value.GetBoolean();
        return null;
    }
}
