namespace SAIStudio.Core.Services;

/// <summary>多步骤后端报告当前阶段；不把阶段计数作为真实生成百分比。</summary>
public interface IGenerationStageReporting
{
    event Action<string>? StageChanged;
}
