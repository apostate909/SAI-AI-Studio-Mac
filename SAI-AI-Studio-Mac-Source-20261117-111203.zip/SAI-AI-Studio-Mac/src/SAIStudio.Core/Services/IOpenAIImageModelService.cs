using SAIStudio.Shared;

namespace SAIStudio.Core.Services;

/// <summary>
/// GPT Image 模型列表服务。
/// </summary>
public interface IOpenAIImageModelService
{
    Task<IReadOnlyList<OpenAIImageModelInfo>> GetModelsAsync(
        OpenAIImageSettings settings,
        CancellationToken ct = default);
}

public sealed record OpenAIImageModelInfo(
    string Id,
    long Created,
    string OwnedBy,
    IReadOnlyList<string>? ReasoningEfforts = null,
    IReadOnlyList<string>? ImageQualities = null,
    bool? SupportsImageGenerationTool = null);
