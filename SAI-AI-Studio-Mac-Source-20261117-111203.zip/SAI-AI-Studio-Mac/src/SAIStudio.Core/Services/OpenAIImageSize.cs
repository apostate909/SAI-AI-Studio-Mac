using SAIStudio.Shared;

namespace SAIStudio.Core.Services;

/// <summary>将源图、固定尺寸和缩放策略转换为图片模型接受的请求尺寸。</summary>
public static class OpenAIImageSize
{
    public static string GetRequestSize(OpenAIImageSettings settings, byte[] sourceImage)
    {
        var (width, height) = settings.SizeStrategy switch
        {
            OpenAIImageSizeStrategy.SourceImage => GetSourceImageSize(sourceImage) ?? GetFixedSize(settings),
            OpenAIImageSizeStrategy.Scale => ScaleSize(GetSourceImageSize(sourceImage) ?? GetFixedSize(settings), settings.Scale),
            _ => GetFixedSize(settings)
        };

        return IsFlexibleSizeModel(settings.Model)
            ? BuildFlexibleSize(width, height)
            : BuildStandardImageSize(width, height);
    }

    private static (int Width, int Height) GetFixedSize(OpenAIImageSettings settings)
    {
        return (
            Math.Clamp(settings.Width, 64, 4096),
            Math.Clamp(settings.Height, 64, 4096));
    }

    private static (int Width, int Height) ScaleSize((int Width, int Height) size, double scale)
    {
        var safeScale = Math.Clamp(scale, 0.1, 8.0);
        return (
            Math.Max(64, (int)Math.Round(size.Width * safeScale)),
            Math.Max(64, (int)Math.Round(size.Height * safeScale)));
    }

    private static string BuildStandardImageSize(int width, int height)
    {
        var aspect = height <= 0 ? 1.0 : (double)width / height;
        if (aspect >= 1.2)
        {
            return "1536x1024";
        }

        if (aspect <= 1.0 / 1.2)
        {
            return "1024x1536";
        }

        return "1024x1024";
    }

    private static string BuildFlexibleSize(int width, int height)
    {
        const int minimumPixels = 655_360;
        const int maximumPixels = 8_294_400;
        const int maximumSide = 3840;

        var normalizedWidth = Math.Clamp((double)width, 16, maximumSide);
        var normalizedHeight = Math.Clamp((double)height, 16, maximumSide);
        NormalizeAspectRatio(ref normalizedWidth, ref normalizedHeight);

        var pixels = normalizedWidth * normalizedHeight;
        if (pixels < minimumPixels)
        {
            var scale = Math.Sqrt(minimumPixels / pixels);
            normalizedWidth *= scale;
            normalizedHeight *= scale;
        }
        else if (pixels > maximumPixels)
        {
            var scale = Math.Sqrt(maximumPixels / pixels);
            normalizedWidth *= scale;
            normalizedHeight *= scale;
        }

        normalizedWidth = Math.Clamp(normalizedWidth, 16, maximumSide);
        normalizedHeight = Math.Clamp(normalizedHeight, 16, maximumSide);
        NormalizeAspectRatio(ref normalizedWidth, ref normalizedHeight);

        // 在最终的 16 像素网格上选择最接近目标的合法尺寸，避免四舍五入后重新越过像素/比例边界。
        var finalWidth = 1024;
        var finalHeight = 1024;
        var bestDistance = double.PositiveInfinity;
        for (var candidateWidth = 16; candidateWidth <= maximumSide; candidateWidth += 16)
        {
            var minimumHeight = (int)Math.Ceiling(Math.Max(
                minimumPixels / (double)candidateWidth, candidateWidth / 3.0) / 16) * 16;
            var maximumHeight = (int)Math.Floor(Math.Min(maximumSide, Math.Min(
                maximumPixels / (double)candidateWidth, candidateWidth * 3.0)) / 16) * 16;
            if (minimumHeight > maximumHeight)
            {
                continue;
            }

            var candidateHeight = Math.Clamp(RoundToMultipleOf16(normalizedHeight), minimumHeight, maximumHeight);
            var distance = Math.Pow((candidateWidth - normalizedWidth) / normalizedWidth, 2)
                + Math.Pow((candidateHeight - normalizedHeight) / normalizedHeight, 2);
            if (distance < bestDistance)
            {
                bestDistance = distance;
                finalWidth = candidateWidth;
                finalHeight = candidateHeight;
            }
        }

        return $"{finalWidth}x{finalHeight}";
    }

    private static void NormalizeAspectRatio(ref double width, ref double height)
    {
        if (height <= 0)
        {
            height = 16;
        }

        if (width <= 0)
        {
            width = 16;
        }

        var aspect = width / height;
        if (aspect > 3.0)
        {
            width = height * 3.0;
        }
        else if (aspect < 1.0 / 3.0)
        {
            height = width * 3.0;
        }
    }

    private static int RoundToMultipleOf16(double value)
    {
        return Math.Clamp((int)Math.Round(value / 16.0) * 16, 16, 3840);
    }

    private static bool IsFlexibleSizeModel(string model)
    {
        return model.StartsWith("gpt-image-2", StringComparison.OrdinalIgnoreCase);
    }

    private static (int Width, int Height)? GetSourceImageSize(byte[] sourceImage)
    {
        if (sourceImage.Length == 0)
        {
            return null;
        }

        try
        {
#if MACOS_CLIENT
            using var image = SkiaSharp.SKBitmap.Decode(sourceImage);
            return image is null ? null : (image.Width, image.Height);
#else
            using var stream = new MemoryStream(sourceImage);
            using var image = System.Drawing.Image.FromStream(stream, useEmbeddedColorManagement: false, validateImageData: false);
            return (image.Width, image.Height);
#endif
        }
        catch
        {
            return null;
        }
    }

}
