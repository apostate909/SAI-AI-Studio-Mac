namespace SAIStudio.Core.Services;

/// <summary>
/// Models API 没有标准档位字段。优先使用服务扩展信息，否则使用已核对的模型兼容规则。
/// auto 表示不发送 reasoning.effort，让服务选择默认值；不通过付费请求探测档位。
/// </summary>
public static class OpenAIWorkflowCapabilities
{
    public static bool IsImageModel(string? id) =>
        id?.StartsWith("gpt-image-", StringComparison.OrdinalIgnoreCase) == true
        || id?.StartsWith("chatgpt-image-", StringComparison.OrdinalIgnoreCase) == true;

    public static bool IsTextModel(OpenAIImageModelInfo model) =>
        model.SupportsImageGenerationTool != false
        && model.Id.StartsWith("gpt-", StringComparison.OrdinalIgnoreCase)
        && !IsImageModel(model.Id)
        && !new[] { "audio", "realtime", "transcrib", "tts", "codex", "search", "deep-research" }
            .Any(x => model.Id.Contains(x, StringComparison.OrdinalIgnoreCase));

    public static OpenAIWorkflowOptions Reasoning(string? id, OpenAIImageModelInfo? info = null)
    {
        if (info?.ReasoningEfforts is { Count: > 0 } values)
            return new(["auto", .. values.Where(x => x != "auto").Distinct()], "服务返回");

        var model = (id ?? "").ToLowerInvariant();
        // 2026-10 官方模型页核对；日期快照继承模型系列规则。
        if (model.StartsWith("gpt-6-astra") || model.StartsWith("gpt-6.1-sol"))
            return new(["auto", "low", "medium", "high", "xhigh", "max"], "内置兼容规则");
        if (model.StartsWith("gpt-6-luna") || model.StartsWith("gpt-5.6-luna"))
            return new(["auto", "none", "low", "medium", "high", "xhigh", "max"], "内置兼容规则");
        if (model == "gpt-5" || model.StartsWith("gpt-5-mini") || model.StartsWith("gpt-5-nano")
            || model.StartsWith("gpt-5-20"))
            return new(["auto", "minimal", "low", "medium", "high"], "内置兼容规则");
        if (model.StartsWith("gpt-4"))
            return new(["auto"], "不发送思考档位");

        return new(["auto", "none", "minimal", "low", "medium", "high", "xhigh", "max"],
            "通用候选，服务未声明能力");
    }

    public static OpenAIWorkflowOptions Quality(string? id, OpenAIImageModelInfo? info = null)
    {
        if (info?.ImageQualities is { Count: > 0 } values)
            return new(values.Distinct().ToArray(), "服务返回");
        if (id?.StartsWith("gpt-image-2.5-sunburst", StringComparison.OrdinalIgnoreCase) == true
            || id?.StartsWith("gpt-image-2.5-flare", StringComparison.OrdinalIgnoreCase) == true)
            return new(["auto", "low", "medium", "high", "xhigh", "max"], "内置兼容规则");
        if (id?.StartsWith("gpt-image-1", StringComparison.OrdinalIgnoreCase) == true
            || string.Equals(id, "gpt-image-2", StringComparison.OrdinalIgnoreCase)
            || id?.StartsWith("gpt-image-2-20", StringComparison.OrdinalIgnoreCase) == true
            || string.Equals(id, "chatgpt-image-latest", StringComparison.OrdinalIgnoreCase))
            return new(["auto", "low", "medium", "high"], "内置兼容规则");
        return new(["auto", "low", "medium", "high", "xhigh", "max"], "通用候选，服务未声明能力");
    }
}

public sealed record OpenAIWorkflowOptions(IReadOnlyList<string> Values, string Source);
