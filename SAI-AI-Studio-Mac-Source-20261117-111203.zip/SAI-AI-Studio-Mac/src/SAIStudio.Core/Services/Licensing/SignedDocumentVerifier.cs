using System.Security.Cryptography;
using System.Text.Json;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

public sealed class SignedDocumentVerifier(IReadOnlyDictionary<string, string> publicKeys)
{
    public static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    public T Verify<T>(SignedDocument document)
    {
        if (document.Payload.Length > 4 * 1024 * 1024 || !publicKeys.TryGetValue(document.KeyId, out var pem))
            throw new CryptographicException("签名密钥不受信任。");
        var payload = Convert.FromBase64String(document.Payload);
        using var key = ECDsa.Create();
        key.ImportFromPem(pem);
        if (key.KeySize != 256 || !key.VerifyData(payload, Convert.FromBase64String(document.Signature),
                HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation))
            throw new CryptographicException("响应签名无效。");
        return JsonSerializer.Deserialize<T>(payload, JsonOptions)
            ?? throw new CryptographicException("签名内容为空。");
    }

    public LicenseClaims VerifyLicense(SignedDocument document, string deviceId)
    {
        var claims = Verify<LicenseClaims>(document);
        if (claims.Product != LicenseProtocol.Product || claims.ProtocolVersion != LicenseProtocol.Version ||
            claims.Purpose != "license" || claims.DeviceId != deviceId || claims.Revision < 1 ||
            !Enum.IsDefined(claims.State) || string.IsNullOrWhiteSpace(claims.EndEventId) ||
            claims.GraceSeconds is < LicenseProtocol.MinimumGraceSeconds or > LicenseProtocol.MaximumGraceSeconds ||
            claims.ServerUtc == default || claims.RegisteredUtc == default ||
            claims.RegisteredUtc > claims.ServerUtc ||
            (claims.State == EntitlementState.Pending &&
             (claims.AccessEndsUtc is null || claims.AccessEndsUtc < claims.RegisteredUtc.AddHours(24))) ||
            (claims.GraceStartedUtc is { } start && start > claims.ServerUtc))
            throw new CryptographicException("授权内容不符合协议。");
        return claims;
    }
}
