using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text.Json;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

/// <summary>固定协议端点、挑战签名和请求随机数；不保存通用下载凭据。</summary>
public sealed class LicenseHttpTransport : ILicenseTransport
{
    private readonly HttpClient _http;
    private readonly Uri _baseUri;
    private readonly IDeviceIdentity _identity;
    private readonly SignedDocumentVerifier _verifier;
    private readonly string _version;

    public LicenseHttpTransport(HttpClient http, Uri baseUri, IDeviceIdentity identity,
        SignedDocumentVerifier verifier, string version, bool allowLoopbackHttp = false)
    {
        if (baseUri.Scheme != Uri.UriSchemeHttps &&
            !(allowLoopbackHttp && baseUri.Scheme == Uri.UriSchemeHttp && baseUri.IsLoopback))
            throw new ArgumentException("授权服务必须使用 HTTPS。");
        if (!string.IsNullOrEmpty(baseUri.UserInfo) || !string.IsNullOrEmpty(baseUri.Query) ||
            !string.IsNullOrEmpty(baseUri.Fragment))
            throw new ArgumentException("授权服务地址不合法。");
        _http = http; _baseUri = baseUri; _identity = identity; _verifier = verifier; _version = version;
    }

    public async Task<SignedDocument> CheckAsync(LicenseClientState state, string? invitation, CancellationToken ct)
    {
        // ResponseHeadersRead 的 HttpClient 超时不覆盖正文读取，整次校验必须另有限时。
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        var maximum = TimeSpan.FromSeconds(30);
        timeout.CancelAfter(_http.Timeout > TimeSpan.Zero && _http.Timeout < maximum ? _http.Timeout : maximum);
        ct = timeout.Token;
        var operation = state.Document is null && !string.IsNullOrWhiteSpace(invitation) ? "enroll" : "check";
        var (proof, nonce) = await CreateProofAsync(operation, null, state, invitation, ct);
        using var request = NewRequest("v1/license", proof);
        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        var document = await ReadBoundedJsonAsync<SignedDocument>(response, 128 * 1024, ct);
        if (_verifier.VerifyLicense(document, _identity.DeviceId).RequestNonce != nonce)
            throw new CryptographicException("授权响应与本次请求不匹配。");
        return document;
    }

    public async Task<HttpResponseMessage> SendAuthorizedAsync(string operation, string? resource, CancellationToken ct)
    {
        var (proof, _) = await CreateProofAsync(operation, resource, new(), null, ct);
        using var request = NewRequest(operation == "update-manifest" ? "v1/updates/latest" : "v1/updates/download", proof);
        var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        try { response.EnsureSuccessStatusCode(); return response; }
        catch { response.Dispose(); throw; }
    }

    private async Task<(DeviceProof Proof, string Nonce)> CreateProofAsync(string operation, string? resource,
        LicenseClientState state, string? invitation, CancellationToken ct)
    {
        using var request = NewRequest("v1/challenge", new { product = LicenseProtocol.Product, publicKey = _identity.PublicKey, operation });
        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        var challenge = await ReadBoundedJsonAsync<DeviceChallenge>(response, 8192, ct);
        if (string.IsNullOrWhiteSpace(challenge.Id) || challenge.Id.Length > 256 ||
            string.IsNullOrWhiteSpace(challenge.Nonce) || challenge.Nonce.Length > 256)
            throw new CryptographicException("授权挑战无效。");
        var nonce = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        var payload = JsonSerializer.SerializeToUtf8Bytes(new LicenseRequest(
            LicenseProtocol.Product, LicenseProtocol.Version, operation, challenge.Id, nonce, challenge.Nonce,
            _identity.DeviceId, _version, invitation, resource, state.EndEventId, state.GraceStartedUtc, state.HighestRevision),
            SignedDocumentVerifier.JsonOptions);
        return (new(_identity.PublicKey, challenge.Id, Convert.ToBase64String(payload),
            Convert.ToBase64String(_identity.Sign(payload))), nonce);
    }

    private HttpRequestMessage NewRequest(string path, object body) =>
        new(HttpMethod.Post, new Uri(_baseUri, path)) { Content = JsonContent.Create(body, options: SignedDocumentVerifier.JsonOptions) };

    public static async Task<T> ReadBoundedJsonAsync<T>(HttpResponseMessage response, int maximumBytes, CancellationToken ct)
    {
        if (response.Content.Headers.ContentLength > maximumBytes) throw new InvalidDataException("响应过大。");
        await using var input = await response.Content.ReadAsStreamAsync(ct);
        using var output = new MemoryStream();
        var buffer = new byte[8192];
        int read;
        while ((read = await input.ReadAsync(buffer, ct)) > 0)
        {
            if (output.Length + read > maximumBytes) throw new InvalidDataException("响应过大。");
            output.Write(buffer, 0, read);
        }
        return JsonSerializer.Deserialize<T>(output.ToArray(), SignedDocumentVerifier.JsonOptions)
            ?? throw new InvalidDataException("响应为空。");
    }
}
