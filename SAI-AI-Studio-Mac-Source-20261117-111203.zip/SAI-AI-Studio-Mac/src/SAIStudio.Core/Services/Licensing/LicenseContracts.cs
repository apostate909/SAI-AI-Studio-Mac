using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

public interface IDeviceIdentity
{
    string DeviceId { get; }
    string PublicKey { get; }
    byte[] Sign(byte[] payload);
}
public interface ILicenseStateStore
{
    LicenseClientState Load();
    void Save(LicenseClientState state);
}
public interface ILicenseTransport
{
    Task<SignedDocument> CheckAsync(LicenseClientState state, string? invitation, CancellationToken ct);
}
public interface IApplicationAccess
{
    AccessSnapshot Snapshot { get; }
    void EnsureBusinessAllowed();
}
public sealed class LicenseAccessException(string message) : InvalidOperationException(message);
