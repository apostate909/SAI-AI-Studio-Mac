using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

public sealed class UnavailableLicenseTransport : ILicenseTransport
{
    public Task<SignedDocument> CheckAsync(LicenseClientState state, string? invitation, CancellationToken ct) =>
        Task.FromException<SignedDocument>(new InvalidOperationException("尚未配置授权服务。"));
}
