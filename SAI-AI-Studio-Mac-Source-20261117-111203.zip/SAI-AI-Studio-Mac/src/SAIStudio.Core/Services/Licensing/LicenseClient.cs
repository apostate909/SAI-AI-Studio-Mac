using System.Security.Cryptography;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

public sealed class LicenseClient : IApplicationAccess
{
    private readonly ILicenseStateStore _store;
    private readonly ILicenseTransport _transport;
    private readonly SignedDocumentVerifier _verifier;
    private readonly string _deviceId;
    private readonly TimeProvider _time;
    private readonly bool _development;
    private readonly bool _configured;
    private readonly SemaphoreSlim _mutex = new(1, 1);
    private LicenseClientState _state = new();
    private LicenseClaims? _claims;
    private DateTimeOffset _anchorUtc;
    private DateTimeOffset _wallAtAnchor;
    private long _anchorTimestamp;
    private AccessSnapshot _snapshot = new(ClientAccessState.ActivationRequired, false, false, "正在读取授权。");
    private sealed record BusinessGate(DateTimeOffset Now, DateTimeOffset Wall, long Timestamp, DateTimeOffset? Deadline);
    private BusinessGate? _businessGate;
    public AccessSnapshot Snapshot => Volatile.Read(ref _snapshot);
    public event Action? Changed;
    public string DeviceId => _deviceId;

    public LicenseClient(ILicenseStateStore store, ILicenseTransport transport, SignedDocumentVerifier verifier,
        string deviceId, bool configured = true, bool development = false, TimeProvider? time = null)
    {
        _store = store; _transport = transport; _verifier = verifier; _deviceId = deviceId;
        _configured = configured; _development = development; _time = time ?? TimeProvider.System;
    }

    // 只读本机记录，必须在显示业务窗口之前完成；没有网络等待。
    public async Task InitializeAsync()
    {
        await _mutex.WaitAsync();
        try
        {
            _anchorUtc = _time.GetUtcNow();
            _wallAtAnchor = _anchorUtc;
            _anchorTimestamp = _time.GetTimestamp();
            if (_development) { Publish(new(ClientAccessState.Development, true, false, "开发版本：未接入授权服务。")); return; }
            if (!_configured) { Publish(new(ClientAccessState.Unconfigured, false, false, "授权服务尚未配置，请联系分发者。")); return; }
            try
            {
                _state = _store.Load();
                if (_state.Document is not null)
                {
                    _claims = _verifier.VerifyLicense(_state.Document, _deviceId);
                    if (_claims.Revision < _state.HighestRevision) throw new CryptographicException();
                }
                if (_wallAtAnchor.AddMinutes(5) < _state.LastWallUtc)
                    _state.RequiresOnlineVerification = true;
                if (_state.LastObservedUtc != default && _state.LastWallUtc != default)
                    _anchorUtc = _state.LastObservedUtc + Positive(_wallAtAnchor - _state.LastWallUtc);
                // 上次校验尚未完成就退出：本次打开才确认校验失败，不能靠反复短启动无限放行。
                if (_state.VerificationPending && _claims is not null)
                    _state.OfflineSinceUtc ??= _anchorUtc;
                _state.VerificationPending = false;
                EvaluateAndSave();
            }
            catch
            {
                _state.RequiresOnlineVerification = true;
                Publish(new(ClientAccessState.VerificationRequired, false, false, "授权记录需要联网恢复。"));
            }
        }
        finally { _mutex.Release(); }
    }

    public async Task CheckAsync(string? invitation = null, CancellationToken ct = default)
    {
        if (!_configured || _development) return;
        await _mutex.WaitAsync(ct);
        try
        {
            try
            {
                _state.VerificationPending = true;
                EvaluateAndSave();
                var document = await _transport.CheckAsync(_state, invitation, ct);
                var claims = _verifier.VerifyLicense(document, _deviceId);
                if (claims.Revision < _state.HighestRevision ||
                    (_claims is not null && claims.ServerUtc < _claims.ServerUtc))
                    throw new CryptographicException("拒绝旧授权响应。");
                if (_claims is not null && claims.Revision == _claims.Revision &&
                    (claims.State != _claims.State || claims.EndEventId != _claims.EndEventId ||
                     claims.AccessEndsUtc != _claims.AccessEndsUtc || claims.CanUpdate != _claims.CanUpdate ||
                     claims.GraceSeconds != _claims.GraceSeconds))
                    throw new CryptographicException("相同授权版本的权限发生变化。");

                // 同一结束事件不得延期；恢复或新授权必须使用递增版本。
                if (_state.EndEventId is not null && claims.EndEventId != _state.EndEventId &&
                    !(claims.Revision > _state.HighestRevision && claims.State == EntitlementState.Active &&
                      (claims.AccessEndsUtc is null || claims.AccessEndsUtc > claims.ServerUtc)))
                    throw new CryptographicException("拒绝重置授权结束事件。");
                var validByServer = claims.State is EntitlementState.Active or EntitlementState.Pending &&
                    (claims.AccessEndsUtc is null || claims.AccessEndsUtc > claims.ServerUtc);
                // 系统时钟跳到未来造成的假到期，可由同版本的新鲜签名时间纠正；
                // 真正撤销过的权限仍必须通过递增授权版本恢复。
                var correctedFutureClock = validByServer && claims.Revision == _state.HighestRevision &&
                    _claims?.State == claims.State && _state.GraceStartedUtc > claims.ServerUtc &&
                    claims.GraceStartedUtc is null;
                if ((claims.Revision > _state.HighestRevision && claims.State == EntitlementState.Active && validByServer) ||
                    correctedFutureClock)
                {
                    _state.EndEventId = null; _state.GraceStartedUtc = null;
                    _state.GraceEndsUtc = null; _state.WarnedEventId = null;
                }
                if (_state.GraceStartedUtc > claims.ServerUtc)
                {
                    _state.GraceStartedUtc = claims.ServerUtc;
                    var boundedEnd = claims.ServerUtc.AddSeconds(claims.GraceSeconds);
                    _state.GraceEndsUtc = _state.GraceEndsUtc is { } existing ? Min(existing, boundedEnd) : boundedEnd;
                }
                if (_state.EndEventId == claims.EndEventId && claims.GraceStartedUtc is { } start)
                {
                    _state.GraceStartedUtc = _state.GraceStartedUtc is { } old ? Min(old, start) : start;
                    var deadline = _state.GraceStartedUtc.Value.AddSeconds(claims.GraceSeconds);
                    _state.GraceEndsUtc = _state.GraceEndsUtc is { } oldEnd ? Min(oldEnd, deadline) : deadline;
                }
                _claims = claims;
                _state.Document = document;
                _state.HighestRevision = claims.Revision;
                _state.RequiresOnlineVerification = false;
                _state.VerificationPending = false;
                // 明确结束的授权不清除既有离线期限。
                if (claims.State is EntitlementState.Active or EntitlementState.Pending &&
                    (claims.AccessEndsUtc is null || claims.AccessEndsUtc > claims.ServerUtc))
                    _state.OfflineSinceUtc = null;
                _anchorUtc = claims.ServerUtc;
                _wallAtAnchor = _time.GetUtcNow();
                _anchorTimestamp = _time.GetTimestamp();
                _state.LastObservedUtc = claims.ServerUtc;
                EvaluateAndSave();
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch
            {
                _state.VerificationPending = false;
                // 网络故障、拒绝或无效响应均不能签发新权限、清掉宽限或冒充撤销。
                if (_claims is not null) _state.OfflineSinceUtc ??= Now();
                EvaluateAndSave();
            }
        }
        finally { _mutex.Release(); }
    }

    public async Task TickAsync()
    {
        if (!_configured || _development || !await _mutex.WaitAsync(0)) return;
        try
        {
            if (_time.GetUtcNow().AddMinutes(5) < _state.LastWallUtc)
                _state.RequiresOnlineVerification = true;
            EvaluateAndSave();
        }
        finally { _mutex.Release(); }
    }

    public async Task AcknowledgeWarningAsync()
    {
        await _mutex.WaitAsync();
        try { _state.WarnedEventId = _state.EndEventId; EvaluateAndSave(); }
        finally { _mutex.Release(); }
    }

    public async Task<bool> BeginWarningAsync()
    {
        await _mutex.WaitAsync();
        try
        {
            if (!Snapshot.WarningPending || _claims is null) return false;
            if (_state.GraceEndsUtc is null)
            {
                _state.EndEventId = _claims.EndEventId;
                _state.GraceStartedUtc = Now();
                _state.GraceEndsUtc = _state.GraceStartedUtc.Value.AddSeconds(_claims.GraceSeconds);
                EvaluateAndSave();
            }
            return Snapshot.WarningPending;
        }
        finally { _mutex.Release(); }
    }

    public void EnsureBusinessAllowed()
    {
        // 业务调用本身也检查时间，避免后台计时器尚未运行产生短暂放行。
        var status = Snapshot;
        var gate = Volatile.Read(ref _businessGate);
        var now = gate is null ? _time.GetUtcNow() : gate.Now +
            Max(_time.GetElapsedTime(gate.Timestamp), Positive(_time.GetUtcNow() - gate.Wall));
        if (!status.CanUse || (gate?.Deadline is { } end && now >= end) ||
            (gate is not null && _time.GetUtcNow().AddMinutes(5) < gate.Wall))
            throw new LicenseAccessException(status.CanUse ? "需要重新验证授权。" : status.Message);
    }

    private DateTimeOffset Now() => Max(_state.LastObservedUtc, _anchorUtc +
        Max(_time.GetElapsedTime(_anchorTimestamp), Positive(_time.GetUtcNow() - _wallAtAnchor)));
    private void EvaluateAndSave()
    {
        var now = Now();
        _state.LastObservedUtc = now;
        _state.LastWallUtc = _time.GetUtcNow();
        var snapshot = LicensePolicy.Evaluate(_state, _claims, now);
        try { _store.Save(_state); }
        catch
        {
            _state.RequiresOnlineVerification = true;
            snapshot = new(ClientAccessState.VerificationRequired, false, false, "无法保存授权状态，请检查本机存储后重新验证。");
        }
        var deadline = _state.GraceEndsUtc;
        if (_state.OfflineSinceUtc is { } offline)
            deadline = deadline is { } end ? Min(end, offline.AddDays(7)) : offline.AddDays(7);
        Volatile.Write(ref _businessGate, new(now, _state.LastWallUtc, _time.GetTimestamp(), deadline));
        Publish(snapshot);
    }
    private void Publish(AccessSnapshot snapshot)
    {
        if (snapshot == _snapshot) return;
        Volatile.Write(ref _snapshot, snapshot);
        Changed?.Invoke();
    }
    private static DateTimeOffset Max(DateTimeOffset a, DateTimeOffset b) => a > b ? a : b;
    private static DateTimeOffset Min(DateTimeOffset a, DateTimeOffset b) => a < b ? a : b;
    private static TimeSpan Positive(TimeSpan value) => value < TimeSpan.Zero ? TimeSpan.Zero : value;
    private static TimeSpan Max(TimeSpan a, TimeSpan b) => a > b ? a : b;
}
