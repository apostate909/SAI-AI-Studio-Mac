using SAIStudio.Shared.Licensing;

namespace SAIStudio.Core.Services.Licensing;

/// <summary>纯状态规则；不联网、不随机、不依赖 UI。时长来自服务器签名。</summary>
public static class LicensePolicy
{
    public static AccessSnapshot Evaluate(LicenseClientState state, LicenseClaims? claims, DateTimeOffset now)
    {
        if (claims is null)
            return new(ClientAccessState.ActivationRequired, false, false, "首次使用需要联网登记，请连接网络后重新验证。");
        if (state.RequiresOnlineVerification)
            return new(ClientAccessState.VerificationRequired, false, false, "需要联网重新验证授权。");

        var ended = claims.State is EntitlementState.Revoked or EntitlementState.Expired ||
                    claims.AccessEndsUtc is { } end && now >= end;
        if (ended && state.GraceEndsUtc is null)
        {
            // 新事件先请求展示提醒；展示窗口前再持久化起点，避免启动失败也消耗保存时间。
            state.EndEventId = claims.EndEventId;
            if (claims.GraceStartedUtc is { } serverStart)
            {
                state.GraceStartedUtc = serverStart;
                state.GraceEndsUtc = serverStart.AddSeconds(claims.GraceSeconds);
            }
            else if (state.OfflineSinceUtc is not { } failed || now < failed.AddDays(7))
                return new(ClientAccessState.Grace, true, claims.CanUpdate, LicenseProtocol.EndWarning, WarningPending: true);
        }
        if (state.GraceEndsUtc is { } graceEnd)
        {
            if (now >= graceEnd)
                return new(ClientAccessState.Disabled, false, claims.CanUpdate, "使用已结束，请联系分发者恢复授权。");
            if (state.OfflineSinceUtc is { } failure && now >= failure.AddDays(7))
                return new(ClientAccessState.VerificationRequired, false, false, "离线使用时间已结束，请联网重新验证。");
            return new(ClientAccessState.Grace, true, claims.CanUpdate, LicenseProtocol.EndWarning,
                state.WarnedEventId != state.EndEventId);
        }
        if (state.OfflineSinceUtc is { } offline)
            return now >= offline.AddDays(7)
                ? new(ClientAccessState.VerificationRequired, false, false, "离线使用时间已结束，请联网重新验证。")
                : new(ClientAccessState.Offline, true, claims.CanUpdate, "暂时无法验证授权，当前可继续使用。");
        return claims.State == EntitlementState.Pending
            ? new(ClientAccessState.Trial, true, claims.CanUpdate, "试用中，等待分发者批准。")
            : new(ClientAccessState.Active, true, claims.CanUpdate, "授权正常。");
    }
}
