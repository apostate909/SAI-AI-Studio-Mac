using SAIStudio.Shared;

namespace SAIStudio.Core.Services;

/// <summary>
/// AI 后端的公共抽象。
/// 每种后端（ComfyUI / Cloud API / Qwen-Agent）各自实现。
/// </summary>
public interface IAIBackend
{
    BackendType Type { get; }
    string DisplayName { get; }

    /// <summary>健康检查——后端是否可达。</summary>
    Task<bool> PingAsync(CancellationToken ct = default);

    /// <summary>发起一次图生图（image-to-image）生成。</summary>
    Task<byte[]> GenerateAsync(
        byte[] sourceImage,
        byte[]? maskImage,
        string? prompt,
        EditStrength? strength,
        double? denoisingStrength,
        int seed,
        CancellationToken ct = default);
}

public interface IAIBackendRequestDiagnostics
{
    string? LastRequestDiagnosticText { get; }
}
