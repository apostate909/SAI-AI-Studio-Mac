namespace SAIStudio.Shared.Licensing;

public sealed record LicenseClaims
{
    public string Product { get; init; } = LicenseProtocol.Product;
    public int ProtocolVersion { get; init; } = LicenseProtocol.Version;
    public string Purpose { get; init; } = "license";
    public string DeviceId { get; init; } = "";
    public long Revision { get; init; }
    public string RequestNonce { get; init; } = "";
    public DateTimeOffset ServerUtc { get; init; }
    public DateTimeOffset RegisteredUtc { get; init; }
    public EntitlementState State { get; init; }
    public bool CanUpdate { get; init; }
    public DateTimeOffset? AccessEndsUtc { get; init; }
    // 即使尚未到期也预先签发事件和随机时长，以便离线到期时使用同一规则。
    public string EndEventId { get; init; } = "";
    public int GraceSeconds { get; init; }
    public DateTimeOffset? GraceStartedUtc { get; init; }
}
