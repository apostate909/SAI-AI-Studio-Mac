namespace SAIStudio.Shared.Licensing;

public sealed record LicenseClientState
{
    public SignedDocument? Document { get; set; }
    public long HighestRevision { get; set; }
    public DateTimeOffset LastObservedUtc { get; set; }
    public DateTimeOffset LastWallUtc { get; set; }
    public DateTimeOffset? OfflineSinceUtc { get; set; }
    public string? EndEventId { get; set; }
    public DateTimeOffset? GraceStartedUtc { get; set; }
    public DateTimeOffset? GraceEndsUtc { get; set; }
    public string? WarnedEventId { get; set; }
    public bool RequiresOnlineVerification { get; set; }
    public bool VerificationPending { get; set; }
}
