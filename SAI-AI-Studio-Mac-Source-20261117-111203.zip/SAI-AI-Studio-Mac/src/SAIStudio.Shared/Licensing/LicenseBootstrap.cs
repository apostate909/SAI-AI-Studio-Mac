namespace SAIStudio.Shared.Licensing;

public sealed record LicenseBootstrap
{
    public string ServiceUrl { get; init; } = "";
    public Dictionary<string, string> PublicKeys { get; init; } = new();
}
