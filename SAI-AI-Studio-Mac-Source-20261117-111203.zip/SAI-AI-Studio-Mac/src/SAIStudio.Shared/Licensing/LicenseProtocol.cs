namespace SAIStudio.Shared.Licensing;

// 协议只包含公开数据；私钥和管理员凭据不得进入客户端。
public static class LicenseProtocol
{
    public const string Product = "SAI-AI-Studio";
    public const int Version = 1;
    public const string EndWarning = "结束了，赶快保存文件哟";
    public const int MinimumGraceSeconds = 48 * 3600;
    public const int MaximumGraceSeconds = 120 * 3600;
}
public enum EntitlementState { Pending, Active, Revoked, Expired }
public enum ClientAccessState { ActivationRequired, Active, Trial, Grace, Offline, Disabled, VerificationRequired, Unconfigured, Development }
public sealed record SignedDocument(string KeyId, string Payload, string Signature);
public sealed record DeviceChallenge(string Id, string Nonce, DateTimeOffset ExpiresUtc);
public sealed record DeviceProof(string PublicKey, string ChallengeId, string Payload, string Signature);
public sealed record LicenseRequest(string Product, int ProtocolVersion, string Operation, string ChallengeId,
    string Nonce, string ChallengeNonce, string DeviceId, string ClientVersion, string? Invitation, string? Resource,
    string? EndEventId, DateTimeOffset? GraceStartedUtc, long KnownRevision);


public sealed record AccessSnapshot(ClientAccessState State, bool CanUse, bool CanUpdate,
    string Message, bool WarningPending = false);
public sealed record InvitationFile(string Token);
