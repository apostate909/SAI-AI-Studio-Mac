namespace SAIStudio.Shared;

/// <summary>
/// Placeholder — Shared types will be added in Phase 0.5.
/// </summary>
public static class Anchor
{
    public const string Namespace = "SAIStudio.Shared";
}
