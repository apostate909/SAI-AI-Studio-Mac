namespace SAIStudio.Shared;

/// <summary>
/// 历史记录容量限制。
/// </summary>
public static class HistoryLimits
{
    public const int MaxImageRecords = 20;
    public const int MaxAnalysisTextRecords = 20;
}
