namespace SAIStudio.Shared;

/// <summary>
/// 一个 AI 生成结果。
/// </summary>
/// <param name="ImageData">用于回填和导出的结果，可包含整画布定位及遮罩。</param>
/// <param name="OriginalImageData">缩放和合成前的生成图；与结果相同时可省略。</param>
public record GenerationResult(
    Guid Id,
    FunctionMode SourceMode,
    byte[] ImageData,
    string? Prompt,
    string? AnalysisText,
    DateTime CreatedAt,
    int Index,
    Guid? BatchId = null,
    byte[]? OriginalImageData = null
);

/// <summary>
/// 历史记录中存储的条目摘要。
/// </summary>
public record HistoryEntry(
    Guid Id,
    FunctionMode SourceMode,
    DateTime CreatedAt,
    string? PromptPreview,
    byte[]? ThumbnailData,
    bool HasImage,
    bool HasAnalysis,
    int ResultIndex,
    int ResultCount,
    bool IsFavorited,
    Guid? BatchId = null
)
{
    public bool HasMultipleResults => ResultCount > 1;
    public int DisplayIndex => ResultIndex + 1;
    public string? BatchPositionText => HasMultipleResults ? $"#{DisplayIndex}/{ResultCount}" : null;
}

/// <summary>
/// 历史栏中的一组记录；多结果生成会按 BatchId 聚合。
/// </summary>
public record HistoryBatchGroup(
    Guid Id,
    Guid? BatchId,
    IReadOnlyList<HistoryEntry> Entries,
    bool IsExpanded = true
)
{
    public HistoryEntry? PrimaryEntry => Entries.FirstOrDefault();
    public IReadOnlyList<HistoryEntry> VisibleEntries => IsExpanded ? Entries : Entries.Take(1).ToList();
    public int VisibleCount => VisibleEntries.Count;
    public int ResultCount => PrimaryEntry?.ResultCount ?? VisibleCount;
    public bool HasMultipleResults => ResultCount > 1;
    public string Title => HasMultipleResults ? $"批次 {ResultCount} 张" : "单张";
    public string? VisibleCountText => HasMultipleResults && VisibleCount != ResultCount
        ? $"显示 {VisibleCount}/{ResultCount}"
        : null;
}

/// <summary>
/// 提示词预设的一项。
/// </summary>
public record PromptPresetInfo(
    Guid Id,
    string Name,
    string Category,
    string PromptText,
    bool IsFavorite
);

/// <summary>
/// 提示词分类的概要。
/// </summary>
public record PromptCategoryInfo(
    string Name,
    int PresetCount
);
