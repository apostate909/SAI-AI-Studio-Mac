namespace SAIStudio.Shared.Updates;

public sealed record UpdateFile(string Path, long Length, string Sha256);
public sealed record UpdateManifest
{
    public string Product { get; init; } = "SAI-AI-Studio";
    public string Purpose { get; init; } = "update";
    public int ProtocolVersion { get; init; } = 1;
    public string Platform { get; init; } = "win-x64";
    public string Version { get; init; } = "";
    public long ReleaseSequence { get; init; }
    public string PackagePath { get; init; } = "";
    public long PackageLength { get; init; }
    public string PackageSha256 { get; init; } = "";
    public string Notes { get; init; } = "";
    public List<UpdateFile> Files { get; init; } = new();
}
