namespace SAIStudio.Shared.Services;

public interface ISaiBridge
{
    string TargetVersion { get; }

    Task<SaiBridgeStatus> GetStatusAsync(CancellationToken ct = default);

    Task<SaiBridgeImageResult> CaptureCanvasAsync(CancellationToken ct = default);

    Task<SaiBridgeImageResult> CaptureSelectionAsync(CancellationToken ct = default);

    Task<SaiFullCanvasMaskCaptureResult> CaptureSelectionWithFullCanvasMaskAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> CreateLayerAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> GetCoordinateMappingAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> LocateSelectionInCanvasAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> DiagnoseSelectionFillBackOffsetAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> PasteSelectionToCanvasAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> RunPreflightAsync(CancellationToken ct = default);

    Task<SaiBridgeOperationResult> FillBackAsync(byte[] pngImage, CancellationToken ct = default);

    Task<SaiBridgeOperationResult> FillBackToSelectionAsync(
        byte[] pngImage,
        SaiSelectionFillBackMode mode,
        SaiSelectionSnapshot? selectionSnapshot = null,
        CancellationToken ct = default,
        PhotoshopDocumentReference? targetDocument = null);

    Task StampVisibleBeforeCaptureAsync(CancellationToken ct = default);
}

public enum SaiSelectionFillBackMode
{
    AutoMoveToSelection,
    PasteOnly,
    FullCanvasMask
}

public record SaiBridgeStatus(
    bool IsAvailable,
    string TargetVersion,
    string Message,
    string? DiagnosticText = null
);

public record SaiBridgeOperationResult(
    bool Success,
    string Message,
    string? DiagnosticText = null
);

public record SaiBridgeImageResult(
    bool Success,
    string Message,
    byte[]? ImageData = null,
    int? Width = null,
    int? Height = null,
    string? DiagnosticText = null,
    PhotoshopDocumentReference? SourceDocument = null
);

public record SaiFullCanvasMaskCaptureResult(
    bool Success,
    string Message,
    SaiBridgeImageResult? SelectionImage = null,
    SaiBridgeImageResult? FullCanvasMask = null,
    string? DiagnosticText = null,
    SaiSelectionBounds? SelectionBounds = null,
    int? CanvasWidth = null,
    int? CanvasHeight = null,
    string? CoordinateSource = null
);

public record SaiSelectionBounds(
    int X,
    int Y,
    int Width,
    int Height
);

public record SaiSelectionSnapshot(
    byte[] ImageData,
    DateTime CreatedAtUtc,
    int? Width = null,
    int? Height = null,
    string? SnapshotPath = null,
    string? CaptureMessage = null,
    string? CaptureDiagnosticText = null,
    PhotoshopDocumentReference? SourceDocument = null
);
