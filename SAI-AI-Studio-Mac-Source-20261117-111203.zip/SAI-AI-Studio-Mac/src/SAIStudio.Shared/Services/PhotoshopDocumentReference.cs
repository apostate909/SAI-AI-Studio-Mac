namespace SAIStudio.Shared.Services;

/// <summary>只在当前插件会话内有效的 PS 来源文档，不用于按名称重新打开文件。</summary>
public sealed record PhotoshopDocumentReference(
    string SessionId,
    int DocumentId,
    string DocumentName,
    int CanvasWidth,
    int CanvasHeight)
{
    [System.Text.Json.Serialization.JsonIgnore]
    public bool IsValid => !string.IsNullOrWhiteSpace(SessionId)
        && DocumentId > 0 && CanvasWidth > 0 && CanvasHeight > 0;
}
