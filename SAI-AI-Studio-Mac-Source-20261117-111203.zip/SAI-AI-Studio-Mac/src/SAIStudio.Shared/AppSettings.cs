using SAIStudio.Shared.Services;

namespace SAIStudio.Shared;

/// <summary>
/// appsettings.json 中 Settings 节点的强类型映射。
/// </summary>
public class AppSettings
{
    public const string Section = "Settings";

    public string DefaultBackend { get; set; } = "StableDiffusionWebUI";
    /// <summary>安装器选择的绘画程序，作为首次使用时的默认值。</summary>
    public DrawingApplication DrawingApplication { get; set; } = DrawingApplication.Auto;
    /// <summary>高级设置中明确选择的绘画程序；未选择时沿用安装目标。</summary>
    public DrawingApplication? DrawingApplicationOverride { get; set; }
    public OpenAIImageSettings OpenAIImage { get; set; } = new();
    public StableDiffusionWebUISettings StableDiffusionWebUI { get; set; } = new();
    public ComfyUISettings ComfyUI { get; set; } = new();
    public CloudAPISettings CloudAPI { get; set; } = new();
    public OutputSettings Output { get; set; } = new();
    public SAISettings SAI { get; set; } = new();
    public BrowserWorkspaceSettings BrowserWorkspace { get; set; } = new();
    public PhotoshopBridgeSettings PhotoshopBridge { get; set; } = new();
    public WindowLayoutSettings WindowLayout { get; set; } = new();
}

public class OpenAIImageSettings
{
    public bool Enabled { get; set; }
    public string BaseUrl { get; set; } = "https://api.openai.com/v1";
    public string ApiKey { get; set; } = "";
    public string Model { get; set; } = "gpt-image-2.5-sunburst";
    public string TextModel { get; set; } = "gpt-6-luna";
    public string TextReasoningEffort { get; set; } = "max";
    public string ImageQuality { get; set; } = "max";
    public bool EnableReview { get; set; }
    public string Size { get; set; } = "1024x1024";
    public OpenAIImageSizeStrategy SizeStrategy { get; set; } = OpenAIImageSizeStrategy.SourceImage;
    public int Width { get; set; } = 1024;
    public int Height { get; set; } = 1024;
    public double Scale { get; set; } = 1.0;
    /// <summary>Responses 工作流每个阶段的等待上限，单位秒。</summary>
    public int TimeoutSeconds { get; set; } = 900;
}

public class StableDiffusionWebUISettings
{
    public bool Enabled { get; set; } = true;
    public string BaseUrl { get; set; } = "http://127.0.0.1:7860";
    public int TimeoutSeconds { get; set; } = 120;
    public string ModelTitle { get; set; } = "";
    public string LoraName { get; set; } = "";
    public double LoraWeight { get; set; } = 1.0;
    public string SamplerName { get; set; } = "Euler a";
    public int Steps { get; set; } = 20;
    public double CfgScale { get; set; } = 7.0;
    public string NegativePrompt { get; set; } = "low quality,badhand";
    public StableDiffusionSizeStrategy SizeStrategy { get; set; } = StableDiffusionSizeStrategy.SourceImage;
    public int Width { get; set; } = 512;
    public int Height { get; set; } = 512;
}

public class ComfyUISettings
{
    public bool Enabled { get; set; }
    public string BaseUrl { get; set; } = "http://127.0.0.1:8188";
    public int TimeoutSeconds { get; set; } = 120;
}

public class CloudAPISettings
{
    public string Provider { get; set; } = "";
    public string ApiKey { get; set; } = "";
    public string Model { get; set; } = "";
}

public class OutputSettings
{
    public int DefaultCount { get; set; } = 1;
    public int MaxHistoryRecords { get; set; } = 200;
    public string ImageCachePath { get; set; } = "cache/images";
}

public class SAISettings
{
    public string ProcessName { get; set; } = "sai2";
    public string WindowTitle { get; set; } = "";
    public int PollIntervalMs { get; set; } = 500;
    public SaiSelectionFillBackMode SelectionFillBackMode { get; set; } = SaiSelectionFillBackMode.FullCanvasMask;
    public SaiFullCanvasMaskHotkeys FullCanvasMaskHotkeys { get; set; } = new();
}

public class BrowserWorkspaceSettings
{
    public int ChatInputPollIntervalMs { get; set; } = 250;
    public int ChatInputReadyTimeoutMs { get; set; } = 15000;
    public int WaitAfterFocusChatInputMs { get; set; } = 200;
    public int WaitAfterPromptInsertMs { get; set; } = 500;
    public int UploadPollIntervalMs { get; set; } = 500;
    public int UploadReadyTimeoutMs { get; set; } = 30000;
    public int WaitBeforeSendMs { get; set; }
    public int WaitAfterSendMs { get; set; } = 500;
}

public class PhotoshopBridgeSettings
{
    public string InstallationDirectory { get; set; } = "";
    public bool UxpEnabled { get; set; } = true;
    public int LocalCommandPort { get; set; } = 47872;
    public int CommandTimeoutSeconds { get; set; } = 20;
    public int UxpMinimumMajorVersion { get; set; } = 23;
}

public enum DrawingApplication
{
    Auto,
    Sai2,
    PhotoshopUxp
}

public class SaiFullCanvasMaskHotkeys
{
    public bool PrepareSelectionBeforeCapture { get; set; } = true;
    public bool DisableStartupSafety { get; set; }
    public string SaveDocumentBeforeCapture { get; set; } = "Ctrl+S";
    public string MergeVisibleToTop { get; set; } = "Ctrl+Shift+F1";
    public int CleanupPreparationRepeat { get; set; } = 1;
    public bool SetFillColorBeforeCapture { get; set; } = true;
    public string OpenFillColorDialog { get; set; } = "F12";
    public string FillColorText { get; set; } = "000000";
    public string ConfirmFillColor { get; set; } = "Enter";
    public string CreateLayer { get; set; } = "Ctrl+Shift+N";
    public string InvertSelection { get; set; } = "Ctrl+Shift+I";
    public string FillSelection { get; set; } = "Alt+Delete";
    public string Copy { get; set; } = "Ctrl+C";
    public string Cleanup { get; set; } = "Ctrl+Z";
    public int CleanupRepeat { get; set; } = 3;
    public int WaitAfterSaveDocumentMs { get; set; } = 2500;
    public int WaitAfterMergeVisibleMs { get; set; } = 800;
    public int WaitForTargetForegroundMs { get; set; } = 1000;
    public int WaitAfterBringToFrontMs { get; set; } = 300;
    public int FillColorDialogPollIntervalMs { get; set; } = 25;
    public int FillColorDialogOpenTimeoutMs { get; set; } = 2000;
    public int FillColorDialogCloseTimeoutMs { get; set; } = 2000;
    public int WaitAfterOpenFillColorDialogMs { get; set; } = 100;
    public int FillColorCharacterIntervalMs { get; set; } = 50;
    public int WaitAfterFillColorTextMs { get; set; }
    public int WaitAfterConfirmFillColorMs { get; set; } = 100;
    public int WaitAfterCreateLayerMs { get; set; } = 200;
    public int WaitAfterInvertSelectionMs { get; set; } = 150;
    public int WaitAfterFillMs { get; set; } = 200;
    public int WaitAfterCopyMs { get; set; } = 500;
    public int WaitAfterCleanupMs { get; set; } = 120;
}

public class WindowLayoutSettings
{
    public bool HasSavedLayout { get; set; }
    public double Left { get; set; }
    public double Top { get; set; }
    public double Width { get; set; } = 1100;
    public double Height { get; set; } = 800;
    public bool IsCustomMaximized { get; set; }
    public double SettingsColumnWidth { get; set; } = 220;
    public double HistoryRowHeight { get; set; } = 112;
    public double InputRowHeight { get; set; } = 50;
    public int InputLayoutVersion { get; set; }
    public double PanelRowHeight { get; set; } = 210;
    public bool HasFloatingButtonPosition { get; set; }
    public double FloatingButtonLeft { get; set; }
    public double FloatingButtonTop { get; set; }
}
