namespace SAIStudio.Shared;

/// <summary>
/// 五个功能面板的标识。
/// </summary>
public enum FunctionMode
{
    /// <summary>A — 分析画像</summary>
    Analysis,
    /// <summary>B — 配色探索</summary>
    Color,
    /// <summary>C — 草稿补全</summary>
    Complete,
    /// <summary>D — 细化/重绘</summary>
    Edit,
    /// <summary>F — 提示词管理</summary>
    Prompt
}

/// <summary>
/// D 编辑面板的发挥程度滑块。
/// </summary>
public enum EditStrength
{
    /// <summary>0% — 仅细化，不改变设计意图</summary>
    Refine = 0,
    /// <summary>25% — 少量修改，微调配色/版型</summary>
    Light = 25,
    /// <summary>50% — 中度修改，重新设计同类型</summary>
    Medium = 50,
    /// <summary>75% — 大幅修改，风格迁移</summary>
    Strong = 75,
    /// <summary>100% — 完全重设计</summary>
    Free = 100
}

/// <summary>
/// B 配色探索的方案数量。
/// </summary>
public enum ColorSchemeCount
{
    Two = 2,
    Four = 4,
    Eight = 8
}

/// <summary>
/// B 配色探索的显示模式。
/// </summary>
public enum ColorDisplayMode
{
    /// <summary>平涂色块</summary>
    Flat,
    /// <summary>半完成（简单渐变/半厚涂）</summary>
    HalfFinish
}

/// <summary>
/// A 分析面板的工作模式。
/// </summary>
public enum AnalysisMode
{
    /// <summary>A1 — 仅输出文字分析</summary>
    AnalyzeOnly,
    /// <summary>A2 — 分析并生成编辑结果</summary>
    AnalyzeAndGenerate
}

/// <summary>
/// 单次生成的输出数量（通用，跨面板）。
/// </summary>
public enum GenerationCount
{
    One = 1,
    Two = 2,
    Four = 4,
    Eight = 8
}

/// <summary>
/// AI 后端的类型标识。
/// </summary>
public enum BackendType
{
    OpenAIImage,
    StableDiffusionWebUI,
    ComfyUI,
    CloudAPI,
    QwenAgent
}

/// <summary>
/// Stable Diffusion WebUI img2img 的输出尺寸策略。
/// </summary>
public enum StableDiffusionSizeStrategy
{
    /// <summary>不发送宽高，由 WebUI 使用自身默认行为。</summary>
    WebUIDefault,
    /// <summary>读取输入图像尺寸并发送给 WebUI。</summary>
    SourceImage,
    /// <summary>使用配置中的固定宽高。</summary>
    Fixed
}

/// <summary>
/// GPT Image 请求尺寸策略。
/// </summary>
public enum OpenAIImageSizeStrategy
{
    /// <summary>使用 SAI 选区尺寸。</summary>
    SourceImage,
    /// <summary>使用手动输入的固定宽高。</summary>
    Fixed,
    /// <summary>按 SAI 选区尺寸乘以比例。</summary>
    Scale
}

/// <summary>
/// 生成任务的状态。
/// </summary>
public enum GenerationStatus
{
    Queued,
    Running,
    Completed,
    Failed,
    Cancelled
}
