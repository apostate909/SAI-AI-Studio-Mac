using System.Text;
using System.Text.Json;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.MacCore.Licensing;
using SAIStudio.Shared;

namespace SAIStudio.Mac.Storage;

public sealed class MacSettingsStore(ISecretStore secrets, string directory)
{
    private string SettingsPath => Path.Combine(directory, "settings.json");
    public AppSettings Load()
    {
        var settings = File.Exists(SettingsPath)
            ? JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(SettingsPath), SignedDocumentVerifier.JsonOptions) ?? new()
            : new AppSettings();
        settings.OpenAIImage.ApiKey = Encoding.UTF8.GetString(secrets.Read("openai-api-key") ?? []);
        return settings;
    }
    public void Save(AppSettings settings)
    {
        secrets.Write("openai-api-key", Encoding.UTF8.GetBytes(settings.OpenAIImage.ApiKey));
        var copy = JsonSerializer.Deserialize<AppSettings>(JsonSerializer.Serialize(settings))!;
        copy.OpenAIImage.ApiKey = "";
        Directory.CreateDirectory(directory);
        File.WriteAllText(SettingsPath + ".tmp", JsonSerializer.Serialize(copy, SignedDocumentVerifier.JsonOptions));
        File.Move(SettingsPath + ".tmp", SettingsPath, true);
    }
}
