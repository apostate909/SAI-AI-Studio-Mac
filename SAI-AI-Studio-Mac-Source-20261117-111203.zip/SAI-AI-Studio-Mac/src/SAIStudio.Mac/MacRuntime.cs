using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using SAIStudio.Bridge;
using SAIStudio.Core.Backends;
using SAIStudio.Core.Services;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Mac.Licensing;
using SAIStudio.Mac.Storage;
using SAIStudio.MacCore.Backends;
using SAIStudio.MacCore.Licensing;
using SAIStudio.MacCore.Photoshop;
using SAIStudio.MacCore.Services;
using SAIStudio.MacCore.Storage;
using SAIStudio.Shared;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Mac;

public sealed class MacRuntime : IDisposable
{
    private readonly MacDeviceIdentity _identity;
    private readonly HttpClient _licenseHttp;
    private readonly HttpClient _imageHttp = new(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = Timeout.InfiniteTimeSpan };
    private readonly PhotoshopUxpBridgeServer _server;
    private readonly FileStream _instance;
    public string DataDirectory { get; }
    public LicenseClient License { get; }
    public AppSettings Settings { get; }
    public MacSettingsStore SettingsStore { get; }
    public MacHistoryStore History { get; }
    public MacWorkflow Workflow { get; }
    public IMacPhotoshop Photoshop { get; }
    public string DeviceId => _identity.DeviceId;

    public MacRuntime()
    {
        var bootstrap = MacBootstrap.Load();
        DataDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "Application Support", "SAI-AI-Studio");
        Directory.CreateDirectory(DataDirectory);
        // 文件锁随进程退出释放；单个 Mac 用户不能用多个 Studio 实例竞争 PS 命令队列。
        _instance = new FileStream(Path.Combine(DataDirectory, "studio.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        try
        {
            _identity = new MacDeviceIdentity();
            var secrets = new MacSecretStore();
            SettingsStore = new MacSettingsStore(secrets, DataDirectory);
            Settings = SettingsStore.Load();
            var verifier = new SignedDocumentVerifier(bootstrap.PublicKeys);
            _licenseHttp = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = TimeSpan.FromSeconds(15) };
            var transport = new LicenseHttpTransport(_licenseHttp, new Uri(bootstrap.ServiceUrl), _identity, verifier,
                typeof(MacRuntime).Assembly.GetName().Version!.ToString());
            License = new LicenseClient(new KeychainLicenseStateStore(secrets, DataDirectory, _identity.DeviceId), transport, verifier, _identity.DeviceId);
            var options = Options.Create(Settings);
            _server = new PhotoshopUxpBridgeServer(options, NullLogger<PhotoshopUxpBridgeServer>.Instance);
            Photoshop = new MacPhotoshop(new PhotoshopUxpBridge(_server, NullLogger<PhotoshopUxpBridge>.Instance));
            History = new MacHistoryStore(Path.Combine(DataDirectory, "History"));
            Workflow = new MacWorkflow(License, Photoshop, History);
        }
        catch
        {
            _server?.Dispose(); _licenseHttp?.Dispose(); _identity?.Dispose(); _imageHttp.Dispose();
            _instance.Dispose(); throw;
        }
    }
    public IAIBackend CreateBackend()
    {
        License.EnsureBusinessAllowed();
        // 固定本轮设置，用户之后的调整只影响下一次请求。
        var settings = System.Text.Json.JsonSerializer.Deserialize<AppSettings>(System.Text.Json.JsonSerializer.Serialize(Settings))!;
        return settings.DefaultBackend == "StableDiffusionWebUI"
            ? new MacWebUiBackend(_imageHttp, settings.StableDiffusionWebUI)
            : new OpenAIImageBackend(_imageHttp, Options.Create(settings), NullLogger<OpenAIImageBackend>.Instance);
    }
    public Task<IReadOnlyList<OpenAIImageModelInfo>> ReadModelsAsync(CancellationToken ct) =>
        new OpenAIImageModelService(_imageHttp, NullLogger<OpenAIImageModelService>.Instance).GetModelsAsync(Settings.OpenAIImage, ct);
    public string? ReadInvitation()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "invitation.json");
        return File.Exists(path) && new FileInfo(path).Length <= 8192
            ? System.Text.Json.JsonSerializer.Deserialize<InvitationFile>(File.ReadAllText(path), SignedDocumentVerifier.JsonOptions)?.Token : null;
    }
    public void Dispose()
    {
        _server.Dispose(); _imageHttp.Dispose(); _licenseHttp.Dispose(); _identity.Dispose(); _instance.Dispose();
    }
}
