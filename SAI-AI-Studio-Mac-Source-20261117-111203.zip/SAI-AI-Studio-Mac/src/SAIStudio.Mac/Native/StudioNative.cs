using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace SAIStudio.Mac.Native;

internal static class StudioNative
{
    private const string Library = "StudioNative";
    [DllImport(Library, EntryPoint = "sai_free")] internal static extern void Free(nint value);
    [DllImport(Library, EntryPoint = "sai_release")] internal static extern void Release(nint value);
    [DllImport(Library, EntryPoint = "sai_key_open")] internal static extern nint KeyOpen();
    [DllImport(Library, EntryPoint = "sai_key_public")] internal static extern nint KeyPublic(nint key);
    [DllImport(Library, EntryPoint = "sai_key_sign")] internal static extern nint KeySign(nint key, byte[] payload, int length);
    [DllImport(Library, EntryPoint = "sai_secret_read")] internal static extern int SecretRead([MarshalAs(UnmanagedType.LPUTF8Str)] string account, out nint value);
    [DllImport(Library, EntryPoint = "sai_secret_write")] internal static extern int SecretWrite([MarshalAs(UnmanagedType.LPUTF8Str)] string account, [MarshalAs(UnmanagedType.LPUTF8Str)] string value);
    [DllImport(Library, EntryPoint = "sai_secret_delete")] internal static extern int SecretDelete([MarshalAs(UnmanagedType.LPUTF8Str)] string account);
    [DllImport(Library, EntryPoint = "sai_web_create")] internal static extern nint WebCreate();
    [DllImport(Library, EntryPoint = "sai_web_load")] internal static extern void WebLoad(nint view, [MarshalAs(UnmanagedType.LPUTF8Str)] string url);
    [DllImport(Library, EntryPoint = "sai_web_back")] internal static extern void WebBack(nint view);
    [DllImport(Library, EntryPoint = "sai_web_reload")] internal static extern void WebReload(nint view);
    [DllImport(Library, EntryPoint = "sai_clipboard_image_read")] internal static extern nint ClipboardImageRead();
    [DllImport(Library, EntryPoint = "sai_clipboard_image_write")] internal static extern int ClipboardImageWrite([MarshalAs(UnmanagedType.LPUTF8Str)] string encoded);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] internal delegate void ResultCallback(nint context, nint text);
    [DllImport(Library, EntryPoint = "sai_web_eval")] internal static extern void WebEval(nint view, [MarshalAs(UnmanagedType.LPUTF8Str)] string script, ResultCallback callback, nint context);
    [DllImport(Library, EntryPoint = "sai_web_snapshot")] internal static extern void WebSnapshot(nint view, ResultCallback callback, nint context);
    internal static string TakeString(nint value)
    {
        if (value == 0) throw new CryptographicException("无法访问 macOS 钥匙串，请解锁登录钥匙串并允许此应用访问。");
        try { return Marshal.PtrToStringUTF8(value)!; }
        finally { Free(value); }
    }
}
