using System.Runtime.InteropServices;
using Avalonia.Controls;
using Avalonia.Platform;
using SAIStudio.Mac.Native;

namespace SAIStudio.Mac.Browser;

/// <summary>嵌入 macOS 原生 WebKit；登录资料由 WKWebsiteDataStore 持久化。</summary>
public sealed class MacBrowserView : NativeControlHost, IDisposable
{
    private nint _view;
    private string _url = "https://chatgpt.com/";
    private static readonly StudioNative.ResultCallback Callback = Complete;
    protected override IPlatformHandle CreateNativeControlCore(IPlatformHandle parent)
    {
        if (!OperatingSystem.IsMacOS()) return base.CreateNativeControlCore(parent);
        // Tab 切换只拆装原生父视图，保留 WKWebView 与正在进行的会话。
        if (_view == 0)
        {
            _view = StudioNative.WebCreate();
            StudioNative.WebLoad(_view, _url);
        }
        return new PlatformHandle(_view, "NSView");
    }
    protected override void DestroyNativeControlCore(IPlatformHandle control)
    {
        if (OperatingSystem.IsMacOS())
        {
            // 独立持有的 retain 在窗口关闭时释放，避免切换结果页导致网页重载。
        }
        else base.DestroyNativeControlCore(control);
    }
    public void Navigate(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("https" or "http"))
            throw new InvalidOperationException("请输入有效的网页地址。");
        _url = url;
        if (_view != 0) StudioNative.WebLoad(_view, url);
    }
    public void Back() { if (_view != 0) StudioNative.WebBack(_view); }
    public void Reload() { if (_view != 0) StudioNative.WebReload(_view); }
    public void Dispose()
    {
        if (_view != 0) { StudioNative.Release(_view); _view = 0; }
    }
    public Task<string> EvaluateAsync(string script) => InvokeAsync(h => StudioNative.WebEval(_view, script, Callback, h));
    public async Task<byte[]> SnapshotAsync() => Convert.FromBase64String(await InvokeAsync(h => StudioNative.WebSnapshot(_view, Callback, h)));
    private Task<string> InvokeAsync(Action<nint> action)
    {
        if (_view == 0) throw new InvalidOperationException("请先打开浏览器工作区。");
        var completion = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var handle = GCHandle.Alloc(completion);
        try { action(GCHandle.ToIntPtr(handle)); }
        catch { handle.Free(); throw; }
        return completion.Task.WaitAsync(TimeSpan.FromSeconds(30));
    }
    private static void Complete(nint context, nint text)
    {
        var handle = GCHandle.FromIntPtr(context);
        try
        {
            var task = (TaskCompletionSource<string>)handle.Target!;
            var value = Marshal.PtrToStringUTF8(text) ?? "";
            if (value.StartsWith("ERROR:")) task.TrySetException(new InvalidOperationException(value[6..]));
            else task.TrySetResult(value);
        }
        finally { handle.Free(); }
    }
}
