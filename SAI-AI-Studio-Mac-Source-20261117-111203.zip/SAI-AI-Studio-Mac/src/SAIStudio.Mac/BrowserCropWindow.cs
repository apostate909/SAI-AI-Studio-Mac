using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Controls.Shapes;
using SAIStudio.MacCore.Imaging;
using SkiaSharp;

namespace SAIStudio.Mac;

/// <summary>框选原生 WebKit 截图，按等比显示的实际图像区域换算像素坐标。</summary>
public sealed class BrowserCropWindow : Window
{
    private readonly byte[] _image;
    private readonly Bitmap _bitmap;
    private readonly Grid _surface;
    private readonly Rectangle _selection;
    private Point? _start;
    private Rect _bounds;
    public BrowserCropWindow(byte[] image)
    {
        _image = image; _bitmap = new Bitmap(new MemoryStream(image));
        Title = "拖拽框选生成图区域"; Width = 1000; Height = 760; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        var root = new Grid { RowDefinitions = new RowDefinitions("*,Auto"), Margin = new Thickness(12) };
        _surface = new Grid { Background = Brushes.Black, ClipToBounds = true };
        _surface.Children.Add(new Image { Source = _bitmap, Stretch = Stretch.Uniform });
        var overlay = new Canvas(); _selection = new Rectangle { Stroke = Brushes.White, StrokeThickness = 2, Fill = new SolidColorBrush(Color.FromArgb(35, 120, 180, 255)) };
        overlay.Children.Add(_selection); _surface.Children.Add(overlay);
        _surface.PointerPressed += Press; _surface.PointerMoved += Move; _surface.PointerReleased += Release;
        var buttons = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Margin = new Thickness(0, 10) };
        var confirm = new Button { Content = "导入框选区域", Margin = new Thickness(0, 0, 10, 0) }; confirm.Click += (_, _) => Confirm();
        var cancel = new Button { Content = "取消" }; cancel.Click += (_, _) => Close(null);
        buttons.Children.Add(confirm); buttons.Children.Add(cancel); Grid.SetRow(buttons, 1); root.Children.Add(_surface); root.Children.Add(buttons); Content = root;
        Closed += (_, _) => _bitmap.Dispose();
    }
    private void Press(object? sender, PointerPressedEventArgs e)
    {
        _start = e.GetPosition(_surface); e.Pointer.Capture(_surface); Update(_start.Value);
    }
    private void Move(object? sender, PointerEventArgs e) { if (_start is not null) Update(e.GetPosition(_surface)); }
    private void Release(object? sender, PointerReleasedEventArgs e) { if (_start is not null) Update(e.GetPosition(_surface)); _start = null; e.Pointer.Capture(null); }
    private void Update(Point current)
    {
        if (_start is not { } start) return;
        _bounds = new Rect(start, current).Normalize();
        Canvas.SetLeft(_selection, _bounds.X); Canvas.SetTop(_selection, _bounds.Y); _selection.Width = _bounds.Width; _selection.Height = _bounds.Height;
    }
    private void Confirm()
    {
        using var source = MacImages.Decode(_image);
        var scale = Math.Min(_surface.Bounds.Width / source.Width, _surface.Bounds.Height / source.Height);
        var ox = (_surface.Bounds.Width - source.Width * scale) / 2; var oy = (_surface.Bounds.Height - source.Height * scale) / 2;
        var left = Math.Clamp((int)Math.Floor((_bounds.Left - ox) / scale), 0, source.Width);
        var top = Math.Clamp((int)Math.Floor((_bounds.Top - oy) / scale), 0, source.Height);
        var right = Math.Clamp((int)Math.Ceiling((_bounds.Right - ox) / scale), left, source.Width);
        var bottom = Math.Clamp((int)Math.Ceiling((_bounds.Bottom - oy) / scale), top, source.Height);
        if (right <= left || bottom <= top) return;
        using var crop = new SKBitmap(right - left, bottom - top);
        using (var canvas = new SKCanvas(crop)) canvas.DrawBitmap(source, -left, -top);
        Close(MacImages.Encode(crop));
    }
}
