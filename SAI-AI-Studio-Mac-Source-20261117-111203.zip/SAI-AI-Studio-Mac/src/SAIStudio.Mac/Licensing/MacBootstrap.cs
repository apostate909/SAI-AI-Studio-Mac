using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Mac.Licensing;

internal static class MacBootstrap
{
    public static LicenseBootstrap Load()
    {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("SAIStudio.LicenseBootstrap")
            ?? throw new InvalidOperationException("安装包缺少内置授权配置，请重新打包。");
        var result = JsonSerializer.Deserialize<LicenseBootstrap>(stream, SignedDocumentVerifier.JsonOptions)
            ?? throw new InvalidDataException("内置授权配置无效。");
        if (!Uri.TryCreate(result.ServiceUrl, UriKind.Absolute, out var uri) || uri.Scheme != "https" ||
            !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment) ||
            !string.IsNullOrEmpty(uri.UserInfo) || !uri.AbsolutePath.EndsWith('/') || result.PublicKeys.Count == 0)
            throw new InvalidDataException("内置授权配置必须包含 HTTPS 服务和验签公钥。");
        foreach (var pem in result.PublicKeys.Values)
        {
            if (pem.Contains("PRIVATE KEY", StringComparison.Ordinal)) throw new InvalidDataException("客户端禁止包含服务端私钥。");
            using var key = ECDsa.Create(); key.ImportFromPem(pem);
            if (key.KeySize != 256) throw new InvalidDataException("授权验签公钥必须为 P-256。");
        }
        return result;
    }
}
