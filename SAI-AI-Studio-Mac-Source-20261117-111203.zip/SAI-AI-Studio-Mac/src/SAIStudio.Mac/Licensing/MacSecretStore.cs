using System.Security.Cryptography;
using SAIStudio.Mac.Native;
using SAIStudio.MacCore.Licensing;

namespace SAIStudio.Mac.Licensing;

public sealed class MacSecretStore : ISecretStore
{
    public byte[]? Read(string account)
    {
        var status = StudioNative.SecretRead(account, out var value);
        if (status == -25300) return null;
        if (status != 0) throw new CryptographicException($"钥匙串读取失败（{status}）。");
        return Convert.FromBase64String(StudioNative.TakeString(value));
    }
    public void Write(string account, byte[] value)
    {
        var status = StudioNative.SecretWrite(account, Convert.ToBase64String(value));
        if (status != 0) throw new CryptographicException($"钥匙串保存失败（{status}）。");
    }
}
