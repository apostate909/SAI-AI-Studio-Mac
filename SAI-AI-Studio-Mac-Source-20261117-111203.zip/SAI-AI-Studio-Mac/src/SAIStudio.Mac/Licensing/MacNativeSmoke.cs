using System.Security.Cryptography;
using SAIStudio.Mac.Native;
using SAIStudio.MacCore.Licensing;

namespace SAIStudio.Mac.Licensing;

/// <summary>在编译 Mac 上显式检查原生签名及钥匙串记录；不登记服务端、不签发授权。</summary>
internal static class MacNativeSmoke
{
    public static void Run()
    {
        using var first = new MacDeviceIdentity();
        using var second = new MacDeviceIdentity();
        if (first.DeviceId != second.DeviceId) throw new CryptographicException("Mac 设备身份没有保持稳定。");
        var message = RandomNumberGenerator.GetBytes(64);
        var signature = first.Sign(message);
        using var verifier = ECDsa.Create(); verifier.ImportSubjectPublicKeyInfo(Convert.FromBase64String(first.PublicKey), out _);
        if (!verifier.VerifyData(message, signature, HashAlgorithmName.SHA256, DSASignatureFormat.IeeeP1363FixedFieldConcatenation))
            throw new CryptographicException("Mac 原生签名与现有服务器协议不兼容。");
        var marker = "smoke-" + Guid.NewGuid().ToString("N");
        var directory = Path.Combine(Path.GetTempPath(), "SAIStudio-MacNative-" + marker);
        var secrets = new MacSecretStore();
        try
        {
            var store = new KeychainLicenseStateStore(secrets, directory, marker);
            store.Save(new() { HighestRevision = 7 });
            if (store.Load().HighestRevision != 7) throw new CryptographicException("Mac 钥匙串记录无法恢复。");
            File.Delete(Path.Combine(directory, "license-state.bin"));
            var recovered = store.Load();
            if (!recovered.RequiresOnlineVerification || recovered.HighestRevision != 7)
                throw new CryptographicException("Mac 授权记录删除保护失败。");
        }
        finally
        {
            StudioNative.SecretDelete("license-state-v1-" + marker);
            StudioNative.SecretDelete("license-state-v1-" + marker + "-key");
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }
        Console.WriteLine("Mac Keychain identity, P-256 protocol signature and protected license storage: valid");
    }
}
