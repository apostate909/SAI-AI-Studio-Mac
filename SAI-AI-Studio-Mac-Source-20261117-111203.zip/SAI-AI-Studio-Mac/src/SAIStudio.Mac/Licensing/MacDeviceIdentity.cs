using System.Formats.Asn1;
using System.Security.Cryptography;
using SAIStudio.Core.Services.Licensing;
using SAIStudio.Mac.Native;

namespace SAIStudio.Mac.Licensing;

/// <summary>钥匙串持久化不可导出 P-256 私钥；只导出协议需要的 SPKI 公钥。</summary>
public sealed class MacDeviceIdentity : IDeviceIdentity, IDisposable
{
    private nint _key;
    public string DeviceId { get; }
    public string PublicKey { get; }
    public MacDeviceIdentity()
    {
        if (!OperatingSystem.IsMacOS()) throw new PlatformNotSupportedException("此发行工程仅在 macOS 运行。");
        _key = StudioNative.KeyOpen();
        if (_key == 0) throw new CryptographicException("无法建立 Mac 设备密钥，请检查钥匙串权限。");
        try
        {
            var raw = Convert.FromBase64String(StudioNative.TakeString(StudioNative.KeyPublic(_key)));
            if (raw.Length != 65 || raw[0] != 4) throw new CryptographicException("Mac 设备公钥格式异常。");
            using var key = ECDsa.Create(new ECParameters
            {
                Curve = ECCurve.NamedCurves.nistP256,
                Q = new ECPoint { X = raw[1..33], Y = raw[33..65] }
            });
            var spki = key.ExportSubjectPublicKeyInfo();
            PublicKey = Convert.ToBase64String(spki);
            DeviceId = Convert.ToHexString(SHA256.HashData(spki));
        }
        catch { Dispose(); throw; }
    }
    public byte[] Sign(byte[] payload)
    {
        if (_key == 0) throw new ObjectDisposedException(nameof(MacDeviceIdentity));
        var der = Convert.FromBase64String(StudioNative.TakeString(StudioNative.KeySign(_key, payload, payload.Length)));
        return ConvertSignature(der);
    }
    public static byte[] ConvertSignature(byte[] der)
    {
        var reader = new AsnReader(der, AsnEncodingRules.DER);
        var sequence = reader.ReadSequence();
        var signature = new byte[64];
        for (var i = 0; i < 2; i++)
        {
            var integer = sequence.ReadIntegerBytes().Span;
            if ((integer[0] & 128) != 0) throw new CryptographicException("签名整数无效。");
            if (integer.Length == 33 && integer[0] == 0) integer = integer[1..];
            if (integer.Length > 32) throw new CryptographicException("签名长度无效。");
            integer.CopyTo(signature.AsSpan((i + 1) * 32 - integer.Length));
        }
        sequence.ThrowIfNotEmpty(); reader.ThrowIfNotEmpty();
        return signature;
    }
    public void Dispose()
    {
        if (_key != 0) { StudioNative.Release(_key); _key = 0; }
    }
}
