using System.Collections.ObjectModel;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SAIStudio.Bridge;
using SAIStudio.Core;
using SAIStudio.Core.Services;
using SAIStudio.Mac.Services;
using SAIStudio.MacCore.Imaging;
using SAIStudio.MacCore.Storage;
using SAIStudio.Shared;
using SAIStudio.Shared.Licensing;

namespace SAIStudio.Mac.ViewModels;

public partial class MacStudioViewModel : ViewModelBase, IDisposable
{
    private readonly MacRuntime _runtime;
    private readonly IMacUserInteraction _ui;
    private readonly CancellationTokenSource _lifetime = new();
    private CancellationTokenSource? _operation;
    private DispatcherTimer? _timer;
    private DateTimeOffset _nextCheck;
    private bool _checking;
    private bool _warning;
    private PhotoshopUxpSelectionCapture? _browserCapture;
    private MacResult? _result;
    private IReadOnlyList<OpenAIImageModelInfo> _models = [];
    public AppSettings Settings => _runtime.Settings;
    public string DeviceId => _runtime.DeviceId;
    public ObservableCollection<MacHistoryItemViewModel> History { get; } = [];
    public ObservableCollection<string> TextModels { get; } = [];
    public ObservableCollection<string> ImageModels { get; } = [];
    public ObservableCollection<string> TextEfforts { get; } = [];
    public ObservableCollection<string> ImageQualities { get; } = [];
    public string[] Backends { get; } = ["OpenAIImage", "StableDiffusionWebUI", "BrowserWorkspace"];
    public OpenAIImageSizeStrategy[] ImageSizeStrategies { get; } = Enum.GetValues<OpenAIImageSizeStrategy>();
    public StableDiffusionSizeStrategy[] WebUiSizeStrategies { get; } = Enum.GetValues<StableDiffusionSizeStrategy>();
    [ObservableProperty] private string _prompt = "";
    [ObservableProperty] private string _invitation = "";
    [ObservableProperty] private string _status = "正在启动…";
    [ObservableProperty] private string _licenseStatus = "正在读取授权…";
    [ObservableProperty] private string _pluginStatus = "等待 Photoshop 插件";
    [ObservableProperty] private string _diagnostics = "";
    [ObservableProperty] private bool _licensed;
    [ObservableProperty] private bool _autoPaste = true;
    [ObservableProperty] private bool _compare;
    [ObservableProperty] private bool _favoritesOnly;
    [ObservableProperty] private double _strength = 0.5;
    [ObservableProperty] private int _seed = -1;
    [ObservableProperty] private string _textModel = "";
    [ObservableProperty] private string _imageModel = "";
    [ObservableProperty] private string _textEffort = "auto";
    [ObservableProperty] private string _imageQuality = "auto";
    [ObservableProperty] private string _selectedBackend = "OpenAIImage";
    [ObservableProperty] private Bitmap? _preview;
    [ObservableProperty] private Bitmap? _sourcePreview;
    [ObservableProperty] private MacHistoryItemViewModel? _selectedHistory;
    public bool CanRun => Licensed && !IsBusy;
    public bool HasResult => _result is not null;

    public MacStudioViewModel(MacRuntime runtime, IMacUserInteraction ui) { _runtime = runtime; _ui = ui; }
    public override async Task InitializeAsync()
    {
        TextModel = Settings.OpenAIImage.TextModel; ImageModel = Settings.OpenAIImage.Model;
        TextEffort = Settings.OpenAIImage.TextReasoningEffort; ImageQuality = Settings.OpenAIImage.ImageQuality;
        SelectedBackend = Settings.DefaultBackend;
        TextModels.Add(TextModel); ImageModels.Add(ImageModel); RefreshOptions();
        _runtime.License.Changed += LicenseChanged;
        PropertyChanged += (_, e) =>
        {
            if (e.PropertyName is nameof(IsBusy) or nameof(Licensed)) RefreshCommands();
        };
        await _runtime.License.InitializeAsync();
        RefreshAccess(); await ReloadHistoryAsync();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(15) };
        _timer.Tick += TimerTick; _timer.Start();
        await CheckLicenseAsync();
    }
    partial void OnTextModelChanged(string value) { Settings.OpenAIImage.TextModel = value; RefreshOptions(); }
    partial void OnImageModelChanged(string value) { Settings.OpenAIImage.Model = value; RefreshOptions(); }
    partial void OnTextEffortChanged(string value) => Settings.OpenAIImage.TextReasoningEffort = value;
    partial void OnImageQualityChanged(string value) => Settings.OpenAIImage.ImageQuality = value;
    partial void OnSelectedBackendChanged(string value) => Settings.DefaultBackend = value;
    partial void OnFavoritesOnlyChanged(bool value) => _ = ReloadHistoryAsync();
    partial void OnSelectedHistoryChanged(MacHistoryItemViewModel? value)
    {
        if (value is not null) ShowResult(value.Result);
    }
    private void RefreshOptions()
    {
        var effort = OpenAIWorkflowCapabilities.Reasoning(TextModel, _models.FirstOrDefault(x => x.Id == TextModel)).Values;
        var quality = OpenAIWorkflowCapabilities.Quality(ImageModel, _models.FirstOrDefault(x => x.Id == ImageModel)).Values;
        Replace(TextEfforts, effort); Replace(ImageQualities, quality);
        if (!effort.Contains(TextEffort)) TextEffort = effort[0];
        if (!quality.Contains(ImageQuality)) ImageQuality = quality[0];
    }
    private static void Replace(ObservableCollection<string> collection, IEnumerable<string> values)
    {
        collection.Clear(); foreach (var value in values) collection.Add(value);
    }
    private void RefreshCommands()
    {
        OnPropertyChanged(nameof(CanRun));
        GenerateCommand.NotifyCanExecuteChanged(); CaptureCommand.NotifyCanExecuteChanged();
        PrepareBrowserCommand.NotifyCanExecuteChanged(); ImportFileCommand.NotifyCanExecuteChanged();
        ImportClipboardCommand.NotifyCanExecuteChanged(); GrabBrowserCommand.NotifyCanExecuteChanged();
        SnapshotBrowserCommand.NotifyCanExecuteChanged(); PasteSourceCommand.NotifyCanExecuteChanged();
        PasteCurrentCommand.NotifyCanExecuteChanged();
    }
    private void LicenseChanged() => Dispatcher.UIThread.Post(RefreshAccess);
    private void RefreshAccess()
    {
        if (_lifetime.IsCancellationRequested) return;
        var access = _runtime.License.Snapshot;
        Licensed = access.CanUse; LicenseStatus = access.Message;
        PluginStatus = _runtime.Photoshop.IsConnected ? "Photoshop 插件已连接" : "请打开 Photoshop 和桥接插件面板";
        if (access.WarningPending && !_warning) _ = ShowWarningAsync();
    }
    private async Task ShowWarningAsync()
    {
        _warning = true;
        try
        {
            if (await _runtime.License.BeginWarningAsync())
            {
                await _ui.WarnAsync(LicenseProtocol.EndWarning);
                await _runtime.License.AcknowledgeWarningAsync();
            }
        }
        catch (Exception ex) { Status = ex.Message; }
        finally { _warning = false; }
    }
    private async void TimerTick(object? sender, EventArgs e)
    {
        try
        {
            await _runtime.License.TickAsync(); RefreshAccess();
            if (DateTimeOffset.UtcNow >= _nextCheck && !_checking) await CheckLicenseAsync();
        }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task CheckLicenseAsync()
    {
        if (_checking || _lifetime.IsCancellationRequested) return;
        _checking = true; _nextCheck = DateTimeOffset.UtcNow.AddMinutes(15);
        try
        {
            await _runtime.License.CheckAsync(string.IsNullOrWhiteSpace(Invitation) ? _runtime.ReadInvitation() : Invitation.Trim(), _lifetime.Token);
            RefreshAccess(); Status = LicenseStatus;
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { Status = ex.Message; }
        finally { _checking = false; }
    }
    private async Task RunAsync(Func<CancellationToken, Task> operation)
    {
        if (IsBusy) return;
        IsBusy = true;
        using var ct = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
        _operation = ct;
        try { _runtime.License.EnsureBusinessAllowed(); await operation(ct.Token); }
        catch (OperationCanceledException) { Status = "操作已停止。"; }
        catch (Exception ex) { Status = ex.Message; Diagnostics = ex.Message; }
        finally { _operation = null; IsBusy = false; }
    }
    [RelayCommand] private void Stop() => _operation?.Cancel();
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task CaptureAsync() => RunAsync(async ct =>
    {
        _browserCapture = await _runtime.Workflow.CaptureAsync(false, ct);
        SetSource(MacImages.Png(Convert.FromBase64String(_browserCapture.ImageBase64)));
        Status = $"已获取选区：{_browserCapture.SourceDocument!.DocumentName}";
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task GenerateAsync() => RunAsync(async ct =>
    {
        if (SelectedBackend == "BrowserWorkspace") { await PrepareAsync(ct); return; }
        _runtime.SettingsStore.Save(Settings);
        Status = "正在获取 Photoshop 选区…";
        var capture = await _runtime.Workflow.CaptureAsync(false, ct);
        var prompt = Prompt;
        SetSource(MacImages.Png(Convert.FromBase64String(capture.ImageBase64)));
        var backend = _runtime.CreateBackend();
        if (backend is IGenerationStageReporting stages)
            stages.StageChanged += text => Dispatcher.UIThread.Post(() => Status = text);
        Status = "正在生成…";
        var result = await _runtime.Workflow.GenerateAsync(backend, capture, prompt, Strength, Seed, ct);
        ShowResult(result); await ReloadHistoryAsync();
        Status = "生成完成，结果已保存。";
        if (AutoPaste)
        {
            ct.ThrowIfCancellationRequested();
            try { await _runtime.Workflow.PasteToSourceAsync(result, ct); Status = "生成完成，已回填来源文档的新图层。"; }
            catch (Exception ex) when (ex is not OperationCanceledException) { Status = $"生成已保存；回填失败：{ex.Message}"; }
        }
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task PrepareBrowserAsync() => RunAsync(PrepareAsync);
    private async Task PrepareAsync(CancellationToken ct)
    {
        _browserCapture = await _runtime.Workflow.CaptureAsync(false, ct);
        var png = MacImages.Png(Convert.FromBase64String(_browserCapture.ImageBase64));
        SetSource(png); await _ui.PrepareBrowserAsync(Prompt, png);
        Status = "已准备来源选区和提示词；在网页确认附件后发送，生成后导入结果。";
    }
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task ImportFileAsync() => RunAsync(async ct =>
    {
        var image = await _ui.OpenImageAsync();
        if (image is not null) await ImportAsync(image, ct);
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task ImportClipboardAsync() => RunAsync(async ct =>
    {
        var image = await _ui.ReadClipboardImageAsync() ?? throw new InvalidOperationException("剪贴板中没有图片。");
        await ImportAsync(image, ct);
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task GrabBrowserAsync() => RunAsync(async ct =>
    {
        var image = await _ui.BrowserImageAsync(false);
        if (image is not null) await ImportAsync(image, ct);
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task SnapshotBrowserAsync() => RunAsync(async ct =>
    {
        var image = await _ui.BrowserImageAsync(true);
        if (image is not null) await ImportAsync(image, ct);
    });
    private async Task ImportAsync(byte[] image, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        var result = _runtime.Workflow.Import(image, _browserCapture, Prompt);
        ShowResult(result); await ReloadHistoryAsync(); Status = "结果已导入并保存。";
        if (AutoPaste && _browserCapture is not null)
        {
            ct.ThrowIfCancellationRequested();
            try { await _runtime.Workflow.PasteToSourceAsync(result, ct); Status = "已导入并回填来源文档的新图层。"; }
            catch (Exception ex) when (ex is not OperationCanceledException) { Status = $"导入结果已保存；回填失败：{ex.Message}"; }
        }
    }
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task PasteSourceAsync() => RunAsync(async ct =>
    {
        await _runtime.Workflow.PasteToSourceAsync(_result ?? throw new InvalidOperationException("请先选择结果。"), ct);
        Status = "已回填来源文档。";
    });
    [RelayCommand(CanExecute = nameof(CanRun))]
    private Task PasteCurrentAsync() => RunAsync(async ct =>
    {
        await _runtime.Workflow.PasteToCurrentAsync(_result ?? throw new InvalidOperationException("请先选择结果。"), ct);
        Status = "已加入当前选区的新图层。";
    });
    [RelayCommand]
    private async Task ExportAsync()
    {
        try { if (_result is not null) await _ui.SaveImageAsync(_result.Image, $"{DateTime.Now:yyyyMMdd-HHmmss}-{_result.Id.ToString("N")[..8]}.png"); }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task ExportSourceAsync()
    {
        try
        {
            if (_browserCapture is null) throw new InvalidOperationException("请先获取选区。");
            await _ui.SaveImageAsync(MacImages.Png(Convert.FromBase64String(_browserCapture.ImageBase64)), "selection.png");
        }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task CopyPromptAsync() { try { await _ui.WriteTextAsync(Prompt); } catch (Exception ex) { Status = ex.Message; } }
    [RelayCommand]
    private async Task CopySourceAsync()
    {
        try
        {
            var source = _browserCapture is null ? _result?.Source : MacImages.Png(Convert.FromBase64String(_browserCapture.ImageBase64));
            if (source is null || source.Length == 0) throw new InvalidOperationException("请先获取选区。");
            await _ui.WriteClipboardImageAsync(source); Status = "已复制选区图片，可在网页粘贴。";
        }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task SaveSettingsAsync()
    {
        try { _runtime.SettingsStore.Save(Settings); Status = "设置已保存，API Key 保存在钥匙串中。"; }
        catch (Exception ex) { Status = ex.Message; }
        await Task.CompletedTask;
    }
    [RelayCommand]
    private async Task RefreshModelsAsync()
    {
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
            timeout.CancelAfter(TimeSpan.FromSeconds(30));
            _models = await _runtime.ReadModelsAsync(timeout.Token);
            var text = TextModel; var image = ImageModel;
            Replace(TextModels, _models.Where(OpenAIWorkflowCapabilities.IsTextModel).Select(x => x.Id));
            Replace(ImageModels, _models.Where(x => OpenAIWorkflowCapabilities.IsImageModel(x.Id)).Select(x => x.Id));
            TextModel = TextModels.Contains(text) ? text : TextModels.FirstOrDefault() ?? "";
            ImageModel = ImageModels.Contains(image) ? image : ImageModels.FirstOrDefault() ?? "";
            RefreshOptions(); Status = $"已读取 {_models.Count} 个模型。";
        }
        catch (OperationCanceledException) { Status = "读取模型已取消或超时。"; }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task FavoriteAsync()
    {
        if (_result is null) return;
        try { _result = _result with { Favorite = !_result.Favorite }; _runtime.History.Save(_result); await ReloadHistoryAsync(); }
        catch (Exception ex) { Status = ex.Message; }
    }
    [RelayCommand]
    private async Task DeleteAsync()
    {
        if (_result is null || !await _ui.ConfirmDeleteAsync()) return;
        try
        {
            _runtime.History.Delete(_result.Id); _result = null; Preview?.Dispose(); Preview = null;
            SourcePreview?.Dispose(); SourcePreview = null; Diagnostics = ""; OnPropertyChanged(nameof(HasResult));
            await ReloadHistoryAsync();
        }
        catch (Exception ex) { Status = ex.Message; }
    }
    private async Task ReloadHistoryAsync()
    {
        var results = await Task.Run(_runtime.History.Load);
        foreach (var entry in History) entry.Dispose(); History.Clear();
        foreach (var entry in results.Where(x => !FavoritesOnly || x.Favorite)) History.Add(new(entry));
    }
    private void ShowResult(MacResult result)
    {
        _result = result; Preview?.Dispose();
        Preview = new Bitmap(new MemoryStream(result.Original));
        SetSource(result.Source); Diagnostics = result.Diagnostics; Prompt = result.Prompt;
        OnPropertyChanged(nameof(HasResult));
    }
    private void SetSource(byte[] bytes)
    {
        SourcePreview?.Dispose(); SourcePreview = bytes.Length == 0 ? null : new Bitmap(new MemoryStream(bytes));
    }
    public void Dispose()
    {
        _timer?.Stop(); _lifetime.Cancel(); _operation?.Cancel();
        _runtime.License.Changed -= LicenseChanged;
        Preview?.Dispose(); SourcePreview?.Dispose(); foreach (var entry in History) entry.Dispose();
    }
}
