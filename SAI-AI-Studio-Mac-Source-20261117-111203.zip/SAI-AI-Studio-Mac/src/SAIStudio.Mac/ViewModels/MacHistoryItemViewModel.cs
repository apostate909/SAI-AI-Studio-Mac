using Avalonia.Media.Imaging;
using SAIStudio.MacCore.Storage;

namespace SAIStudio.Mac.ViewModels;

public sealed class MacHistoryItemViewModel : IDisposable
{
    public MacResult Result { get; }
    public Bitmap Preview { get; }
    public string Label => $"{(Result.Favorite ? "★ " : "")}{Result.CreatedUtc.ToLocalTime():MM-dd HH:mm}  {Result.Prompt}";
    public MacHistoryItemViewModel(MacResult result)
    {
        Result = result;
        using var stream = new MemoryStream(result.Original);
        Preview = Bitmap.DecodeToWidth(stream, 160);
    }
    public void Dispose() => Preview.Dispose();
}
