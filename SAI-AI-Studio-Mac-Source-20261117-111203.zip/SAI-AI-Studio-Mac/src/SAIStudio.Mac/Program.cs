using Avalonia;
using SAIStudio.Mac.Licensing;

namespace SAIStudio.Mac;

internal static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        // 只验证编译资源；不创建业务窗口、不触发设备注册，也不绕过授权。
        if (args is ["--verify-bootstrap"])
        {
            try { MacBootstrap.Load(); Console.WriteLine("Embedded production license bootstrap: valid"); return 0; }
            catch (Exception ex) { Console.Error.WriteLine(ex.Message); return 1; }
        }
        if (args is ["--verify-native"])
        {
            try { MacBootstrap.Load(); MacNativeSmoke.Run(); return 0; }
            catch (Exception ex) { Console.Error.WriteLine(ex.Message); return 1; }
        }
        BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        return 0;
    }
    public static AppBuilder BuildAvaloniaApp() => AppBuilder.Configure<App>().UsePlatformDetect().LogToTrace();
}
