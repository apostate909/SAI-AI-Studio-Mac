namespace SAIStudio.Mac.Services;

public interface IMacUserInteraction
{
    Task<byte[]?> OpenImageAsync();
    Task SaveImageAsync(byte[] bytes, string suggestedName);
    Task<byte[]?> ReadClipboardImageAsync();
    Task WriteClipboardImageAsync(byte[] bytes);
    Task WriteTextAsync(string text);
    Task WarnAsync(string text);
    Task<bool> ConfirmDeleteAsync();
    Task PrepareBrowserAsync(string prompt, byte[] source);
    Task<byte[]?> BrowserImageAsync(bool snapshot);
}
