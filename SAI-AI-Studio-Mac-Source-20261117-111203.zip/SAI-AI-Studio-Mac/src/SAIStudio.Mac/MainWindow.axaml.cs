using System.Text.Json;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Platform.Storage;
using SAIStudio.Mac.Native;
using SAIStudio.Mac.Services;
using SAIStudio.Mac.ViewModels;

namespace SAIStudio.Mac;

public partial class MainWindow : Window, IMacUserInteraction
{
    private MacRuntime? _runtime;
    private MacStudioViewModel? _viewModel;
    public MainWindow() => InitializeComponent();
    protected override async void OnOpened(EventArgs e)
    {
        base.OnOpened(e);
        try
        {
            _runtime = new MacRuntime();
            _viewModel = new MacStudioViewModel(_runtime, this); DataContext = _viewModel;
            await _viewModel.InitializeAsync();
        }
        catch (Exception ex)
        {
            this.FindControl<TextBlock>("StatusLabel")!.Text = "启动失败：" + ex.Message;
            await WarnAsync("启动失败：" + ex.Message);
        }
    }
    protected override void OnClosed(EventArgs e)
    {
        _viewModel?.Dispose(); Browser.Dispose(); _runtime?.Dispose(); base.OnClosed(e);
    }
    private void BrowserBack(object? sender, RoutedEventArgs e) => Browser.Back();
    private void BrowserNavigate(object? sender, RoutedEventArgs e)
    {
        try { Browser.Navigate(this.FindControl<TextBox>("BrowserAddress")!.Text ?? "https://chatgpt.com/"); }
        catch (Exception ex) { if (_viewModel is not null) _viewModel.Status = ex.Message; }
    }
    public async Task<byte[]?> OpenImageAsync()
    {
        var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "导入生成结果", AllowMultiple = false,
            FileTypeFilter = [new FilePickerFileType("图片") { Patterns = ["*.png", "*.jpg", "*.jpeg", "*.webp"] }]
        });
        if (files.Count == 0) return null;
        await using var stream = await files[0].OpenReadAsync();
        if (stream.Length > 64 * 1024 * 1024) throw new InvalidOperationException("图片超过 64 MB。");
        using var output = new MemoryStream(); await stream.CopyToAsync(output); return output.ToArray();
    }
    public async Task SaveImageAsync(byte[] bytes, string suggestedName)
    {
        var file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "保存 PNG", SuggestedFileName = suggestedName, DefaultExtension = "png",
            FileTypeChoices = [new FilePickerFileType("PNG 图片") { Patterns = ["*.png"] }]
        });
        if (file is null) return;
        await using var output = await file.OpenWriteAsync(); output.SetLength(0); await output.WriteAsync(bytes);
    }
    public Task<byte[]?> ReadClipboardImageAsync()
    {
        var value = StudioNative.ClipboardImageRead();
        return Task.FromResult(value == 0 ? null : Convert.FromBase64String(StudioNative.TakeString(value)));
    }
    public Task WriteClipboardImageAsync(byte[] bytes)
    {
        if (StudioNative.ClipboardImageWrite(Convert.ToBase64String(bytes)) == 0) throw new InvalidOperationException("无法写入图片剪贴板。");
        return Task.CompletedTask;
    }
    public async Task WriteTextAsync(string text)
    {
        if (Clipboard is { } clipboard) await clipboard.SetTextAsync(text);
    }
    public async Task WarnAsync(string text) => await DialogAsync(text, false);
    public Task<bool> ConfirmDeleteAsync() => DialogAsync("删除这张历史结果？", true);
    private async Task<bool> DialogAsync(string text, bool confirmation)
    {
        var dialog = new Window { Title = "SAI AI Studio", Width = 430, Height = 190, CanResize = false, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        var buttons = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right };
        var yes = new Button { Content = confirmation ? "删除" : "知道了", Margin = new(8) }; yes.Click += (_, _) => dialog.Close(true); buttons.Children.Add(yes);
        if (confirmation) { var no = new Button { Content = "取消", Margin = new(8) }; no.Click += (_, _) => dialog.Close(false); buttons.Children.Add(no); }
        dialog.Content = new StackPanel { Margin = new(22), Spacing = 20, Children = { new TextBlock { Text = text, TextWrapping = Avalonia.Media.TextWrapping.Wrap }, buttons } };
        return await dialog.ShowDialog<bool>(this);
    }
    public async Task PrepareBrowserAsync(string prompt, byte[] source)
    {
        this.FindControl<TabControl>("WorkspaceTabs")!.SelectedIndex = 1;
        // 网页附件由 paste 事件交给站点处理；网页改版不影响手工复制/上传的回退入口。
        var script = "(function(){const el=document.querySelector('#prompt-textarea,[contenteditable=\"true\"],textarea');if(!el)throw new Error('找不到输入框，请登录后重试或使用复制按钮。');el.focus();"
            + "const raw=atob(" + JsonSerializer.Serialize(Convert.ToBase64String(source)) + ");const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));const dt=new DataTransfer();dt.items.add(new File([bytes],'selection.png',{type:'image/png'}));el.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));"
            + "const prompt=" + JsonSerializer.Serialize(prompt) + ";if(el.tagName==='TEXTAREA'){el.value=prompt;el.dispatchEvent(new Event('input',{bubbles:true}));}else{document.execCommand('insertText',false,prompt);}return 'prepared';})()";
        await Browser.EvaluateAsync(script);
    }
    public async Task<byte[]?> BrowserImageAsync(bool snapshot)
    {
        this.FindControl<TabControl>("WorkspaceTabs")!.SelectedIndex = 1;
        if (snapshot) return await new BrowserCropWindow(await Browser.SnapshotAsync()).ShowDialog<byte[]?>(this);
        // 只处理用户主动触发的当前页面最新图片；下载原图也可通过“从文件导入”。
        var script = "(async()=>{const images=[...document.querySelectorAll('main img')].filter(i=>i.naturalWidth>=256&&i.naturalHeight>=256);const image=images.at(-1);if(!image)throw new Error('当前网页没有可导入的大图，请打开生成图或从下载文件导入。');const response=await fetch(image.currentSrc||image.src,{credentials:'include'});if(!response.ok)throw new Error('网页图片下载失败，请使用下载原图后导入。');const blob=await response.blob();if(blob.size>67108864)throw new Error('图片超过64MB');return await new Promise((ok,fail)=>{const reader=new FileReader();reader.onload=()=>ok(reader.result.split(',')[1]);reader.onerror=fail;reader.readAsDataURL(blob);});})()";
        var result = await Browser.EvaluateAsync(script);
        return Convert.FromBase64String(result);
    }
}
