using System.Text.Json;
using Microsoft.Extensions.Logging;
using SAIStudio.Shared.Services;

namespace SAIStudio.Bridge;

public sealed class PhotoshopUxpBridge
{
    private const string PanelUpdateMessage = "请更新并重新加载 PS 桥接插件至 0.2.3 或更新版本，以识别生成结果的来源文档。";
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private readonly PhotoshopUxpBridgeServer _server;
    private readonly ILogger<PhotoshopUxpBridge> _logger;

    public PhotoshopUxpBridge(
        PhotoshopUxpBridgeServer server,
        ILogger<PhotoshopUxpBridge> logger)
    {
        _server = server;
        _logger = logger;
    }

    public bool IsConnected => _server.IsAvailable && _server.IsPluginConnected;

    public string? LastSelectionCaptureFailureMessage { get; private set; }

    public async Task<PhotoshopUxpStatus?> GetStatusAsync(CancellationToken ct = default)
    {
        var result = await _server.SendCommandAsync("status", null, ct);
        if (!result.Success || result.Data == null)
        {
            return null;
        }

        return result.Data.Value.Deserialize<PhotoshopUxpStatus>(JsonOptions);
    }

    public async Task<PhotoshopUxpSelectionCapture?> CaptureSelectionAsync(CancellationToken ct = default)
        => await CaptureImageAsync("captureSelection", ct);

    public async Task<PhotoshopUxpSelectionCapture?> CaptureCanvasAsync(CancellationToken ct = default)
        => await CaptureImageAsync("captureCanvas", ct);

    private async Task<PhotoshopUxpSelectionCapture?> CaptureImageAsync(string command, CancellationToken ct)
    {
        LastSelectionCaptureFailureMessage = null;
        var result = await _server.SendCommandAsync(command, null, ct);
        if (!result.Success || result.Data == null)
        {
            LastSelectionCaptureFailureMessage = result.Success && result.Data == null
                ? "Photoshop UXP selection capture returned no data."
                : result.Message;
            _logger.LogWarning("Photoshop UXP selection capture failed: {Message}", LastSelectionCaptureFailureMessage);
            return null;
        }

        var capture = result.Data.Value.Deserialize<PhotoshopUxpSelectionCapture>(JsonOptions);
        if (capture?.SourceDocument is not { IsValid: true })
        {
            LastSelectionCaptureFailureMessage = PanelUpdateMessage;
            _logger.LogWarning("Photoshop capture did not include a valid source document reference.");
            return null;
        }
        return capture;
    }

    public async Task<PhotoshopUxpPasteResult> PasteImageAsync(
        byte[] pngImage,
        bool preserveTransparency,
        CancellationToken ct = default,
        bool alignToCanvasOrigin = false,
        PhotoshopDocumentReference? targetDocument = null)
    {
        try
        {
            var payload = new
            {
                imageBase64 = Convert.ToBase64String(pngImage),
                preserveTransparency,
                placement = alignToCanvasOrigin ? "canvasOrigin" : "center",
                createLayer = true,
                targetDocument
            };

            // 使用独立命令，旧插件会明确拒绝，不会忽略目标字段后贴到当前文档。
            var result = await _server.SendCommandAsync(targetDocument == null ? "pasteImage" : "pasteImageToDocument", payload, ct);
            return new PhotoshopUxpPasteResult(
                result.Success,
                targetDocument != null && !result.Success && result.Message.Contains("Unknown command", StringComparison.OrdinalIgnoreCase)
                    ? PanelUpdateMessage : result.Message,
                result.Data);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "Photoshop UXP pixel fill-back failed.");
            return new PhotoshopUxpPasteResult(false, $"Photoshop 回填失败：{ex.Message}");
        }
    }
}

public sealed record PhotoshopUxpStatus(
    string PhotoshopVersion,
    bool HasActiveDocument,
    int? DocumentWidth,
    int? DocumentHeight,
    bool HasSelection);

public sealed record PhotoshopUxpSelectionCapture(
    string ImageBase64,
    int Width,
    int Height,
    PhotoshopUxpBounds Bounds,
    int DocumentWidth,
    int DocumentHeight,
    string DiagnosticText,
    PhotoshopDocumentReference? SourceDocument = null);

public sealed record PhotoshopUxpBounds(
    int Left,
    int Top,
    int Right,
    int Bottom)
{
    public int Width => Math.Max(0, Right - Left);
    public int Height => Math.Max(0, Bottom - Top);
}

public sealed record PhotoshopUxpPasteResult(
    bool Success,
    string Message,
    JsonElement? Data = null);
