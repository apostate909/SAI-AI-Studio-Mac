# 授权服务公网连接性

检查时间：2026-11-17 10:32（北京时间）。

正式地址：`https://apostate.tail19fb9.ts.net:8443/`

该地址是已经部署的 Tailscale **Funnel 公网入口**，访问者不需要安装 Tailscale 或加入分发者的私网。早期工程说明将它当成仅私网可用的地址，这是错误的，已修正。客户端地址无需替换，验签公钥也不变。

## 实测结果

通过 Cloudflare 公共 DNS 解析域名，固定连接解析得到的公网中继 IP，保留原始域名、TLS SNI 与正常证书验证，不使用 Tailscale 的私网设备地址。

| 检查 | 结果 |
| --- | --- |
| 公共 DNS | 返回 `185.40.234.37`、`185.40.234.172`、`185.40.234.210` |
| 三个公网中继的 `GET /health` | 全部 HTTP 200，返回 `{"status":"ok"}` |
| HTTPS 证书 | 三个中继均校验通过 |
| `POST /v1/challenge` | HTTP 200，成功取得授权挑战 |
| 使用临时 P-256 密钥签名的 `check` 请求 | HTTP 403，返回预期的 `device_not_registered` |
| 公网 `/admin/devices` | HTTP 404，管理接口没有暴露到公开入口 |

临时检查没有注册新设备、没有消耗邀请码，也没有修改已有设备的授权。403 在这里表示未登记设备被正常拒绝，不是连接失败。没有执行真实 Mac 的首次登记与生成回填验收。

Google 公共 DNS 的 HTTPS 查询在本次测试环境失败；公网解析结果与服务检查来自成功的 Cloudflare 查询。以上确认的是检查当时的公网通路，不代表接收方当地网络已经实测通过。公网中继 IP 可能变化，不应写死到客户端或 hosts 文件。

## 接收方如何检查

直接在 Mac 浏览器打开：

`https://apostate.tail19fb9.ts.net:8443/health`

看到 `{"status":"ok"}` 后，即可在 App 中输入新的邀请码并联网验证授权。如果页面无法打开，检查当地网络能否访问 HTTPS 8443 端口，以及服务器 Funnel 和授权服务是否在线。

参考：[Tailscale Funnel 官方说明](https://tailscale.com/docs/features/tailscale-funnel)明确说明，公开入口可供未使用 Tailscale 的访问者使用。
