# Mac 工程验证记录

初始验证：2026-11-16；交付复查：2026-11-17。开发环境：Windows，.NET SDK 8.0.425。

## 已通过

- `SAI-AI-Studio.Mac.sln` Release 编译：0 警告，0 错误。
- Mac 共用层：52 / 52 自动化测试通过，覆盖共享授权协议、离线及到期规则、状态回拨、加密记录、Apple DER 签名转换、选区外透明合成、来源文档回填、历史容量、WebUI 参数和取消行为。
- 上述测试包含实际回环 HTTP 的 Photoshop 协议测试。Mac 使用 Kestrel，不依赖 Windows HTTP.SYS 与 URL ACL。
- Windows 原有 Core 测试：358 / 358 通过。
- Photoshop 插件脚本 `Test-PhotoshopUxp.cjs`、`Test-PhotoshopUxpLifecycle.cjs` 通过，覆盖来源身份、同名文档、关闭重开、插件会话变化、画布尺寸变化、像素 / Alpha / DPI、模态取消回滚及 PS 26 / 27.11 生命周期。
- 编译程序集的 `--verify-bootstrap` 通过，验证正式 HTTPS 服务与 P-256 公钥。
- 缺失授权引导文件时，构建被 `RequireLicenseBootstrap` 拒绝。
- 源码发送脚本会逐个校验显式项目 / 源文件链接，校验 ZIP 必需文件，并生成 SHA-256 文件。

## 必须在接收方 Mac 完成

当前 Windows 环境没有 Apple SDK，不能在这里声明以下项目已验证：

1. `xcrun swiftc` 原生桥接编译，以及 Intel / Apple Silicon 实际运行。
2. macOS 钥匙串访问提示、设备密钥不可导出和重装后复用。
3. WKWebView 在 Avalonia 中的布局、登录、附件上传、下载及截图。
4. Mac Photoshop 安装插件、捕获选区、生成及带透明度的新图层回填。
5. Developer ID 签名、公证与 Gatekeeper 分发验证。

Mac 编译脚本默认运行自动化测试、编译源码、检查应用签名、编译资源及真实钥匙串自检：

```bash
bash macOS/build-mac.sh
```

`--verify-native` 会使用真实 Mac 钥匙串检查身份复用、签名协议与加密授权记录；此检查未在 Windows 执行，不会请求服务端授权或消耗邀请码。

2026-11-17 复查修正：软件四段版本与苹果构建号分离，原生授权自检改为默认执行，WebKit 桥接显式遵守主线程隔离，DMG 增加 Applications 拖拽入口，Photoshop 增加 CCX / Creative Cloud 安装入口，正式分发流程增加应用和 DMG 的公证票据验证及 Gatekeeper 检查。以上 Apple 工具步骤仍需由接收方 Mac 实际执行。

本次核对的官方资料：

- [Apple CFBundleVersion](https://developer.apple.com/documentation/BundleResources/Information-Property-List/CFBundleVersion)
- [Apple 站外软件公证要求](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)
- [Microsoft .NET macOS 发布说明](https://learn.microsoft.com/en-us/dotnet/core/deploying/macos)
- [Adobe UXP 插件安装说明](https://developer.adobe.com/uxp/guides/how-to/distribution/install/)

## 行为边界

- Mac 与 Windows 授权使用同一套源码和服务端协议，但设备身份分别生成。
- API / WebUI 生成失败不会创建 mock 结果或继续自动回填。
- 生成完成后若授权变为不可用，会保留结果并拒绝回填。
- 默认打包携带授权机制与公钥，不包含已经批准的授权，也不复制 Windows 本机设备记录。
- Mac 客户端当前通过重新分发新 `.app` 更新，未接入 Windows 在线更新器。
- 2026-11-17 公网连接性复查：当前 `.ts.net:8443` 地址通过 Funnel 对公网提供服务，接收方不需要安装 Tailscale；已纠正早期说明中的错误私网要求。地址和验签公钥保持正式部署值，测试详情见 `CONNECTIVITY.md`。
