import AppKit
import WebKit
import Security

// 仅此小桥接库依赖 Apple SDK；业务与授权协议仍由共享 C# 源码执行。
private func text(_ value: String) -> UnsafeMutablePointer<CChar>? { strdup(value) }
private func key(_ ptr: UnsafeRawPointer) -> SecKey {
    Unmanaged<AnyObject>.fromOpaque(ptr).takeUnretainedValue() as! SecKey
}
@MainActor private func web(_ ptr: UnsafeRawPointer) -> WKWebView {
    Unmanaged<WKWebView>.fromOpaque(ptr).takeUnretainedValue()
}

@_cdecl("sai_free") public func saiFree(_ value: UnsafeMutableRawPointer?) { free(value) }
@_cdecl("sai_release") public func saiRelease(_ value: UnsafeRawPointer) {
    Unmanaged<AnyObject>.fromOpaque(value).release()
}

@_cdecl("sai_key_open") public func saiKeyOpen() -> UnsafeMutableRawPointer? {
    let tag = Data("SAIStudio.DeviceIdentity.macOS.v1".utf8)
    let query: [String: Any] = [kSecClass as String: kSecClassKey,
        kSecAttrApplicationTag as String: tag, kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
        kSecAttrKeyClass as String: kSecAttrKeyClassPrivate, kSecReturnRef as String: true]
    var found: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &found)
    if status == errSecSuccess, let found = found { return Unmanaged.passRetained(found).toOpaque() }
    // 钥匙串锁定/拒绝访问不能被当成新设备，也不能自动覆盖旧密钥。
    guard status == errSecItemNotFound else { return nil }
    let attrs: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
        kSecAttrKeySizeInBits as String: 256,
        kSecPrivateKeyAttrs as String: [kSecAttrIsPermanent as String: true,
            kSecAttrApplicationTag as String: tag, kSecAttrIsExtractable as String: false,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]]
    var error: Unmanaged<CFError>?
    guard let generated = SecKeyCreateRandomKey(attrs as CFDictionary, &error) else { return nil }
    return Unmanaged.passRetained(generated).toOpaque()
}

@_cdecl("sai_key_public") public func saiKeyPublic(_ ptr: UnsafeRawPointer) -> UnsafeMutablePointer<CChar>? {
    guard let publicKey = SecKeyCopyPublicKey(key(ptr)) else { return nil }
    var error: Unmanaged<CFError>?
    guard let data = SecKeyCopyExternalRepresentation(publicKey, &error) as Data? else { return nil }
    return text(data.base64EncodedString())
}

@_cdecl("sai_key_sign") public func saiKeySign(_ ptr: UnsafeRawPointer, _ bytes: UnsafePointer<UInt8>, _ count: Int32) -> UnsafeMutablePointer<CChar>? {
    let data = Data(bytes: bytes, count: Int(count))
    var error: Unmanaged<CFError>?
    guard let signature = SecKeyCreateSignature(key(ptr), .ecdsaSignatureMessageX962SHA256, data as CFData, &error) as Data? else { return nil }
    return text(signature.base64EncodedString())
}

private func secretQuery(_ account: String) -> [String: Any] {
    [kSecClass as String: kSecClassGenericPassword,
     kSecAttrService as String: "SAI-AI-Studio.macOS", kSecAttrAccount as String: account,
     kSecAttrSynchronizable as String: false]
}

@_cdecl("sai_secret_read") public func saiSecretRead(_ account: UnsafePointer<CChar>, _ result: UnsafeMutablePointer<UnsafeMutablePointer<CChar>?>) -> Int32 {
    var query = secretQuery(String(cString: account))
    query[kSecReturnData as String] = true
    query[kSecMatchLimit as String] = kSecMatchLimitOne
    var item: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &item)
    if status == errSecSuccess, let data = item as? Data { result.pointee = text(data.base64EncodedString()) }
    return status
}

@_cdecl("sai_secret_write") public func saiSecretWrite(_ account: UnsafePointer<CChar>, _ encoded: UnsafePointer<CChar>) -> Int32 {
    guard let data = Data(base64Encoded: String(cString: encoded)) else { return errSecParam }
    let query = secretQuery(String(cString: account))
    let status = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
    if status != errSecItemNotFound { return status }
    var insert = query
    insert[kSecValueData as String] = data
    insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
    return SecItemAdd(insert as CFDictionary, nil)
}
@_cdecl("sai_secret_delete") public func saiSecretDelete(_ account: UnsafePointer<CChar>) -> Int32 {
    SecItemDelete(secretQuery(String(cString: account)) as CFDictionary)
}

// 作为 WKWebView 的 delegate 保持到 view 释放；下载由用户选择保存位置。
@MainActor private final class StudioWebView: WKWebView, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    override init(frame: NSRect, configuration: WKWebViewConfiguration) {
        super.init(frame: frame, configuration: configuration)
        navigationDelegate = self; uiDelegate = self
        allowsBackForwardNavigationGestures = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) unsupported") }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { webView.load(URLRequest(url: url)) }
        return nil
    }
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
        initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel(); panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.canChooseDirectories = parameters.allowsDirectories
        panel.begin { response in completionHandler(response == .OK ? panel.urls : nil) }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(navigationAction.shouldPerformDownload ? .download : .allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
        decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
        suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let panel = NSSavePanel(); panel.nameFieldStringValue = suggestedFilename
        panel.begin { response in completionHandler(response == .OK ? panel.url : nil) }
    }
}

@MainActor @_cdecl("sai_web_create") public func saiWebCreate() -> UnsafeMutableRawPointer {
    let config = WKWebViewConfiguration()
    config.websiteDataStore = .default()
    let view = StudioWebView(frame: NSRect(x: 0, y: 0, width: 800, height: 600), configuration: config)
    return Unmanaged.passRetained(view).toOpaque()
}
@MainActor @_cdecl("sai_web_load") public func saiWebLoad(_ ptr: UnsafeRawPointer, _ url: UnsafePointer<CChar>) {
    guard let target = URL(string: String(cString: url)), ["https", "http"].contains(target.scheme ?? "") else { return }
    web(ptr).load(URLRequest(url: target))
}
@MainActor @_cdecl("sai_web_back") public func saiWebBack(_ ptr: UnsafeRawPointer) { web(ptr).goBack() }
@MainActor @_cdecl("sai_web_reload") public func saiWebReload(_ ptr: UnsafeRawPointer) { web(ptr).reload() }
@MainActor @_cdecl("sai_clipboard_image_read") public func saiClipboardImageRead() -> UnsafeMutablePointer<CChar>? {
    guard let image = NSImage(pasteboard: .general), let tiff = image.tiffRepresentation,
        let bitmap = NSBitmapImageRep(data: tiff), let png = bitmap.representation(using: .png, properties: [:]) else { return nil }
    return text(png.base64EncodedString())
}
@MainActor @_cdecl("sai_clipboard_image_write") public func saiClipboardImageWrite(_ encoded: UnsafePointer<CChar>) -> Int32 {
    guard let data = Data(base64Encoded: String(cString: encoded)) else { return 0 }
    NSPasteboard.general.clearContents()
    return NSPasteboard.general.setData(data, forType: .png) ? 1 : 0
}
public typealias ResultCallback = @convention(c) (UnsafeMutableRawPointer?, UnsafePointer<CChar>?) -> Void

@MainActor @_cdecl("sai_web_eval") public func saiWebEval(_ ptr: UnsafeRawPointer, _ script: UnsafePointer<CChar>,
    _ callback: @escaping ResultCallback, _ context: UnsafeMutableRawPointer?) {
    // callAsyncJavaScript 会等待 Promise，适用于下载网页原图等异步脚本。
    web(ptr).callAsyncJavaScript("return await (" + String(cString: script) + ");", arguments: [:], in: nil, in: .page) { result in
        let output: String
        switch result {
        case .success(let value): output = value as? String ?? ""
        case .failure(let error): output = "ERROR: \(error.localizedDescription)"
        }
        output.withCString { callback(context, $0) }
    }
}
@MainActor @_cdecl("sai_web_snapshot") public func saiWebSnapshot(_ ptr: UnsafeRawPointer,
    _ callback: @escaping ResultCallback, _ context: UnsafeMutableRawPointer?) {
    web(ptr).takeSnapshot(with: nil) { image, error in
        guard let tiff = image?.tiffRepresentation,
            let bitmap = NSBitmapImageRep(data: tiff),
            let png = bitmap.representation(using: .png, properties: [:]) else {
            "ERROR: 浏览器截图失败".withCString { callback(context, $0) }; return
        }
        png.base64EncodedString().withCString { callback(context, $0) }
    }
}
