#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash macOS/build-mac.sh
printf '\nPress Return to close.\n'
read -r
