#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
# 优先通过 Creative Cloud 正式登记 UXP 插件；目录复制仅作为兼容安装入口。
if [[ "${1:-}" != '--folder' && -f "$HERE/SAI-AI-Studio-Photoshop-Bridge.ccx" ]]; then
  /usr/bin/open "$HERE/SAI-AI-Studio-Photoshop-Bridge.ccx"
  echo 'Complete the installation in Creative Cloud, then restart Photoshop and open SAI AI Studio Bridge.'
  exit 0
fi
SOURCE="$HERE/Photoshop Bridge"
if [[ ! -d "$SOURCE" ]]; then SOURCE="$HERE/../integrations/photoshop-uxp-bridge"; fi
[[ -f "$SOURCE/manifest.json" ]] || { echo 'Photoshop plugin files not found.'; exit 1; }
# 原有 Plug-ins 安装位置优先；使用 Finder 选择已安装 Photoshop 的 Plug-ins 目录。
TARGET="$(osascript -e 'POSIX path of (choose folder with prompt "请选择 Photoshop 安装目录内的 Plug-ins 文件夹")')"
[[ -d "$TARGET" && "$(basename "${TARGET%/}")" == 'Plug-ins' ]] || { echo 'Please select the Photoshop Plug-ins folder.'; exit 1; }
DEST="${TARGET%/}/SAI AI Studio Bridge"
if [[ -e "$DEST" ]]; then
  BACKUP="$DEST.backup-$(date +%Y%m%d-%H%M%S)"
  [[ ! -e "$BACKUP" ]] || { echo 'Backup already exists.'; exit 1; }
  mv "$DEST" "$BACKUP"
fi
mkdir -p "$DEST"
for name in manifest.json index.html main.js style.css; do cp "$SOURCE/$name" "$DEST/$name"; done
echo 'Plugin installed. Restart Photoshop, then open Plugins > SAI AI Studio Bridge.'
