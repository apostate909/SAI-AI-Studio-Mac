[CmdletBinding()]
param([string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $repo 'dist' }
$output = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $output -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$stage = Join-Path $repo "artifacts\mac-source-$stamp\SAI-AI-Studio-Mac"
if (Test-Path -LiteralPath $stage) { throw 'Use a new staging directory.' }
New-Item -ItemType Directory -Path $stage -Force | Out-Null
# 严格按源码白名单打包，不包含 Windows 用户设置、私钥、缓存、数据库或既有邀请。
$files = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($folder in @('src/SAIStudio.Shared','src/SAIStudio.MacCore','src/SAIStudio.Mac','tests/SAIStudio.MacCore.Tests','macOS')) {
    Get-ChildItem -LiteralPath (Join-Path $repo $folder) -Recurse -File | Where-Object {
        $_.FullName -notmatch '[\\/](bin|obj|\.vs|\.idea)[\\/]' -and
        $_.Extension -in @('.cs','.csproj','.axaml','.swift','.json','.sh','.command','.plist','.md')
    } | ForEach-Object { [void]$files.Add([IO.Path]::GetRelativePath($repo, $_.FullName)) }
}
$coreFiles = @('IAIBackend.cs','IGenerationStageReporting.cs','OpenAIImageApiUrl.cs','OpenAIImageSize.cs',
    'OpenAIImageModelService.cs','IOpenAIImageModelService.cs','OpenAIWorkflowCapabilities.cs')
foreach ($file in $coreFiles) { [void]$files.Add("src/SAIStudio.Core/Services/$file") }
Get-ChildItem -LiteralPath (Join-Path $repo 'src/SAIStudio.Core/Services/Licensing') -Filter '*.cs' -File |
    ForEach-Object { [void]$files.Add([IO.Path]::GetRelativePath($repo, $_.FullName)) }
foreach ($file in @('src/SAIStudio.Core/Backends/OpenAIImageBackend.cs','src/SAIStudio.Core/ViewModels/ViewModelBase.cs',
    'src/SAIStudio.Bridge/PhotoshopUxpBridge.cs',
    'tests/SAIStudio.Core.Tests/Licensing/LicenseClientTests.cs','tests/SAIStudio.Core.Tests/Licensing/LicenseHttpTransportTests.cs',
    'tests/SAIStudio.Bridge.Tests/PhotoshopUxpBridgeServerTests.cs',
    'SAI-AI-Studio.Mac.sln','scripts/Package-MacSource.ps1','README.md','.gitignore','.gitattributes')) { [void]$files.Add($file) }
foreach ($name in @('manifest.json','index.html','main.js','style.css','README.md')) {
    [void]$files.Add("integrations/photoshop-uxp-bridge/$name")
}
foreach ($relative in $files) {
    $source = Join-Path $repo $relative
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing required source: $relative" }
    $destination = Join-Path $stage $relative
    New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination
}
Copy-Item -LiteralPath (Join-Path $repo 'macOS/README.md') -Destination (Join-Path $stage 'START-HERE.md')
# shell / Swift / plist 固定 LF + UTF-8；ZIP 跨 Windows/Mac 不依赖可执行位，说明中使用 bash。
Get-ChildItem -LiteralPath $stage -Recurse -File | Where-Object { $_.Extension -in @('.sh','.command','.swift','.plist') } | ForEach-Object {
    $text = [IO.File]::ReadAllText($_.FullName).Replace("`r`n", "`n")
    [IO.File]::WriteAllText($_.FullName, $text, [Text.UTF8Encoding]::new($false))
}
$trust = Get-Content -LiteralPath (Join-Path $stage 'macOS/license-bootstrap.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $trust.ServiceUrl.StartsWith('https://') -or -not $trust.PublicKeys) { throw 'Missing production license bootstrap.' }
if ((Get-Content -LiteralPath (Join-Path $stage 'macOS/license-bootstrap.json') -Raw) -match 'PRIVATE KEY|ApiKey|AdminToken') {
    throw 'Source package contains forbidden secret fields.'
}
# 解析每个显式 Compile / ProjectReference，确保 ZIP 中的相对链接全部闭合。
foreach ($project in Get-ChildItem -LiteralPath $stage -Filter '*.csproj' -File -Recurse) {
    [xml]$xml = Get-Content -LiteralPath $project.FullName -Raw
    foreach ($item in @($xml.Project.ItemGroup.Compile) + @($xml.Project.ItemGroup.ProjectReference)) {
        if (-not $item -or -not $item.Include -or $item.Include.Contains('$')) { continue }
        $target = Join-Path $project.DirectoryName $item.Include
        if (-not (Test-Path -Path $target)) { throw "Unresolved project reference in $($project.Name): $($item.Include)" }
    }
}
$zip = Join-Path $output "SAI-AI-Studio-Mac-Source-$stamp.zip"
Compress-Archive -LiteralPath $stage -DestinationPath $zip -CompressionLevel Optimal
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($zip)
try {
    $names = @($archive.Entries | ForEach-Object { $_.FullName.Replace('\','/') })
    foreach ($required in @('macOS/build-mac.sh','macOS/native/StudioNative.swift','macOS/license-bootstrap.json',
        'src/SAIStudio.Mac/SAIStudio.Mac.csproj','SAI-AI-Studio.Mac.sln','START-HERE.md')) {
        if (-not ($names | Where-Object { $_.EndsWith('/' + $required) })) { throw "ZIP is missing $required" }
    }
} finally { $archive.Dispose() }
$hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
"$hash  $([IO.Path]::GetFileName($zip))" | Set-Content -LiteralPath ($zip + '.sha256') -Encoding UTF8
[ordered]@{ Archive = $zip; Sha256 = $hash; SourceFiles = $files.Count; Staging = $stage } | ConvertTo-Json
