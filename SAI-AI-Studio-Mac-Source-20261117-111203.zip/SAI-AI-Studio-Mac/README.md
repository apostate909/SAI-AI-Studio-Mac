# SAI AI Studio · Mac 工程

这是独立的 macOS / Photoshop 客户端工程，包含现有授权协议，以及 Photoshop 选区 → API / 浏览器 → 历史 → 新图层回填工作流。Windows 的 WPF 主工程独立保留。

## 收到压缩包后怎么编译

1. 解压整个 `SAI-AI-Studio-Mac` 文件夹，不要只复制 `macOS` 子文件夹。
2. 在 Mac 安装 [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)，按 Mac 芯片选择 Arm64 或 x64。
3. 打开“终端”，执行 `xcode-select --install` 安装 Apple 命令行工具，按系统提示完成安装。
4. 在终端输入 `cd `，拖入解压后的 `SAI-AI-Studio-Mac` 文件夹，再按回车。
5. 执行：

```bash
bash macOS/build-mac.sh
```

默认会执行真实 Mac 钥匙串自检。首次构建可能弹出钥匙串访问请求，应允许本应用访问自己的设备密钥；自检失败会停止打包，不会把失败版本当成成品交付。

脚本会识别当前电脑的芯片，下载 NuGet 依赖，编译 C# 与 Swift 桥接库，生成带 .NET 运行时的 `.app`、应用 ZIP 和 DMG。成品在 `artifacts` 中，最终用户无需安装 .NET SDK。

明确指定平台和版本：

```bash
bash macOS/build-mac.sh osx-arm64 1.1.11.4
bash macOS/build-mac.sh osx-x64 1.1.11.4
```

最低系统版本：macOS 12。Apple Silicon 和 Intel 使用各自的包；本工程不合并为 Universal 二进制。Xcode 可编辑 Swift 文件，但主工程是 .NET / Avalonia，使用上面的脚本编译，不是 `.xcodeproj`。

苹果的 `CFBundleShortVersionString` 使用前三段（例如 `1.1.11`）；`CFBundleVersion` 使用递增的 Mac 构建号，默认取第四段（例如 `4`），完整软件版本另保存在程序集与 `SAIStudioSoftwareVersion` 字段。再次分发新构建时应提高构建号，例如 `BUNDLE_BUILD=5 bash macOS/build-mac.sh`。构建号取值为 1–9999。

## 授权已经内置

`macOS/license-bootstrap.json` 包含当前 Windows 发布包同一套授权服务地址与验签**公钥**。构建时将其嵌入程序集，运行时不从用户可编辑设置中更换信任根。

- Mac 与 Windows 编译同一份 `LicenseClient`、`LicensePolicy`、挑战签名与响应验证源码，沿用现有后台的设备批准、撤销、到期、离线和宽限规则。
- 每台 Mac 在钥匙串中生成自己的不可导出 P-256 设备私钥；设备码在重装、换安装目录后保持稳定，只要原钥匙串设备密钥仍存在。
- 授权记录由钥匙串密钥加密，并与钥匙串副本对照，删除或单独回滚磁盘记录需要联网恢复。
- 没有授权不允许选区捕获、生成、导入和回填；默认没有 Debug 免授权模式。
- 首次使用输入分发者提供的**新邀请码**，点击“联网验证授权”；Mac 是新设备，不能继承 Windows 已绑定设备的邀请码或本机授权文件。
- 服务目前为 `https://apostate.tail19fb9.ts.net:8443/`，这是已经通过 **Tailscale Funnel 对公网开放**的 HTTPS 入口。接收方 Mac **无需安装 Tailscale、无需加入分发者的私网**，只需其网络能够访问此地址的 8443 端口。不要仅因域名以 `.ts.net` 结尾而将其判断为私网专用地址。
- API Key 单独保存在 Mac 钥匙串中，源码包不包含 API Key、服务端私钥、管理员凭据、用户浏览器登录资料或现成设备授权。

需要分发带指定邀请码的包时，在 Mac 编译前设置：

```bash
INVITATION_FILE=/absolute/path/to/invitation.json bash macOS/build-mac.sh
```

邀请码文件格式为 `{"token":"分发者提供的新邀请码"}`，只应交给对应设备的使用者。授权服务和验签配置已经具备，不等于自动给收件人永久授权。

接收方可先在普通浏览器打开 `https://apostate.tail19fb9.ts.net:8443/health`，应看到 `{"status":"ok"}`。2026-11-17 已通过公共 DNS 解析的三个公网中继验证 HTTPS 和授权挑战接口，详情见 `CONNECTIVITY.md`。授权登记仍需要新邀请码；健康检查成功不等于已经获准使用软件。

## Photoshop 与生成

1. 使用支持 UXP Imaging API 的新版 Photoshop。插件清单及源码与 Windows 当前版本相同，包含来源文档定位保护。
2. 在生成目录双击 `SAI-AI-Studio-Photoshop-Bridge.ccx`，通过 Creative Cloud 安装插件；`Install Photoshop Bridge.command` 默认也会打开该安装包。若需要沿用目录安装方式，可运行 `bash "Install Photoshop Bridge.command" --folder`，再选择 Photoshop 安装目录里的 `Plug-ins` 文件夹。开发调试可在 Adobe UXP Developer Tool 加载 `manifest.json`，Adobe 也推荐通过该工具打包与验证 CCX。
3. 重启 Photoshop，打开“插件 → SAI AI Studio Bridge”面板并保持开启。本地桥接端口为 `127.0.0.1:47872`。
4. 在 Studio 验证授权，Photoshop 画出选区，再在 Studio 点击获取选区或生成。
5. API 模式配置 Base URL / API Key / 思考模型及档位 / 图片模型及档位，可读取模型列表，可启用审核后最多一次修改。图生图使用与 Windows 相同的 Responses 工作流。
6. WebUI 模式连接开启 `--api` 的本机或远程 WebUI，填写 checkpoint、LoRA、采样器、步数、CFG、负面提示词与修改强度。
7. 生成图片会保存原始结果，并合成为与来源画布同尺寸、选区外透明的 PNG，再通过插件写入来源文档的新像素图层。
8. 生成期间切换文档不会改变回填目标；来源文档关闭、画布尺寸变化或插件重启时，插件会拒绝旧目标。结果仍保留，可通过“加入当前选区”手动重新定位。

## 浏览器工作区

内置 macOS WebKit，默认打开 ChatGPT，登录资料由系统 WebKit 持久化。

- “准备选区与提示词”固定来源选区和文档，尝试把图片附件和文字填入网页，用户确认后发送。
- 网页更新或不接受程序触发的粘贴时，使用“复制源图”“复制提示词”“导出源图”手动粘贴或上传。此回退入口不依赖网站 DOM。
- “导入网页最新图”尝试读取页面最后一张大图；网页访问限制或无法定位时，先下载原图，再从文件导入。
- 支持剪贴板导入和框选 WebKit 当前视口截图；截图是页面显示分辨率，需要原始像素时优先下载原图。
- 导入结果进入历史与预览，并按“准备”时记录的来源文档回填；没有来源选区的图片仅保存，需要手动点击“加入当前选区”。

历史保留最近 20 张，支持收藏、筛选、恢复、删除、源图对比、导出及再次回填。用户设置和历史位于 `~/Library/Application Support/SAI-AI-Studio`，不写入签名 `.app` 内。

## 签名与公证

默认脚本使用本机临时签名，适合编译者在自己 Mac 上测试；这不等于已经通过 Apple 公证或可以在其他 Mac 无提示打开。对其他 Mac 正式分发时，使用自己的 Developer ID Application 证书，并启用公证：

```bash
CODESIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
NOTARY_PROFILE="studio-notary" \
bash macOS/build-mac.sh
```

`studio-notary` 需事先用 `xcrun notarytool store-credentials` 配置。正式流程会验证应用签名，公证应用和最终 DMG，装订并验证票据，再执行 Gatekeeper 应用检查。签名、公证与本软件的业务授权是两个独立机制。工程不包含任何 Apple 开发者证书。

## 验证与边界

```bash
dotnet build SAI-AI-Studio.Mac.sln -c Release
dotnet test tests/SAIStudio.MacCore.Tests/SAIStudio.MacCore.Tests.csproj
```

默认打包会验证真实钥匙串的设备身份复用、原生 P-256 签名与本机授权记录保护，可能出现 macOS 钥匙串访问提示；它不会联网注册设备或消耗邀请码。仅在交叉编译或受控调试时可用 `VERIFY_NATIVE=0` 跳过自检；此时不能把打包成功当作原生授权已经验证。

Windows 环境已验证的结果见同目录 `VALIDATION.md`。Mac 专用的 Swift 编译、WebKit 原生嵌入、钥匙串权限、应用签名以及真实 Mac Photoshop 闭环必须在 Mac 实机验证；不能把 C# 编译和单元测试通过当成这些环节已经验证。

当前不迁移 Windows 的 SAI2 Win32 桥接、SAI2 补丁器、WebView2、Windows 安装器与 Windows 在线更新器。Mac 发布更新先通过重新分发新 `.app` 完成，不会下载或执行服务器上的 Windows 更新包。
