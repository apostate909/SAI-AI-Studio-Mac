#!/bin/bash
set -euo pipefail
# 在 Mac 终端运行：bash macOS/build-mac.sh [osx-arm64|osx-x64] [版本]
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RID="${1:-}"
if [[ -z "$RID" ]]; then
  case "$(uname -m)" in arm64) RID=osx-arm64;; x86_64) RID=osx-x64;; *) echo 'Unsupported Mac architecture'; exit 1;; esac
fi
case "$RID" in osx-arm64) ARCH=arm64;; osx-x64) ARCH=x86_64;; *) echo 'Use osx-arm64 or osx-x64'; exit 1;; esac
VERSION="${2:-1.1.11.4}"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo 'Version must contain four numeric parts.'; exit 1; }
# Apple 的构建版本使用一至三段数字；软件四段版本另存，不让第四段被系统忽略。
MARKETING_VERSION="${VERSION%.*}"
BUNDLE_BUILD="${BUNDLE_BUILD:-${VERSION##*.}}"
[[ "$BUNDLE_BUILD" =~ ^[1-9][0-9]{0,3}$ ]] || { echo 'BUNDLE_BUILD must be an increasing integer from 1 to 9999, e.g. BUNDLE_BUILD=5.'; exit 1; }
[[ "$(uname -s)" == Darwin ]] || { echo 'Run this script on macOS.'; exit 1; }
command -v dotnet >/dev/null || { echo 'Install the .NET 8 SDK first: https://dotnet.microsoft.com/download/dotnet/8.0'; exit 1; }
dotnet --list-sdks | /usr/bin/grep '^8\.' >/dev/null || { echo 'The .NET 8 SDK is required. Install the Arm64 or x64 SDK matching this Mac.'; exit 1; }
xcrun --find swiftc >/dev/null || { echo 'Install Xcode command line tools: xcode-select --install'; exit 1; }
BOOTSTRAP="${LICENSE_BOOTSTRAP_FILE:-$ROOT/macOS/license-bootstrap.json}"
[[ -f "$BOOTSTRAP" ]] || { echo 'Missing embedded license bootstrap. Packaging stopped.'; exit 1; }
OUTPUT="$ROOT/artifacts/mac-$VERSION-$RID-$(date +%Y%m%d-%H%M%S)"
[[ ! -e "$OUTPUT" ]] || { echo 'Output directory already exists.'; exit 1; }
APP="$OUTPUT/SAI AI Studio.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/Photoshop Bridge"
dotnet test "$ROOT/tests/SAIStudio.MacCore.Tests/SAIStudio.MacCore.Tests.csproj" -c Release
dotnet publish "$ROOT/src/SAIStudio.Mac/SAIStudio.Mac.csproj" -c Release -r "$RID" --self-contained true \
  -p:UseAppHost=true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=false \
  -p:DebugType=embedded -p:PublishTrimmed=false -p:Version="$VERSION" -p:AssemblyVersion="$VERSION" \
  -p:LicenseBootstrapFile="$BOOTSTRAP" -o "$APP/Contents/MacOS"
# 本机 Swift / AppKit / Security / WebKit 桥接，不需要第三方浏览器运行时。
SDK="$(xcrun --sdk macosx --show-sdk-path)"
xcrun swiftc -swift-version 5 -O -emit-library -sdk "$SDK" -target "$ARCH-apple-macosx12.0" \
  -module-name StudioNative -framework AppKit -framework Security -framework WebKit \
  -Xlinker -install_name -Xlinker @rpath/libStudioNative.dylib \
  "$ROOT/macOS/native/StudioNative.swift" -o "$APP/Contents/MacOS/libStudioNative.dylib"
chmod +x "$APP/Contents/MacOS/SAIStudio.Mac"
for name in manifest.json index.html main.js style.css; do
  cp "$ROOT/integrations/photoshop-uxp-bridge/$name" "$APP/Contents/Resources/Photoshop Bridge/$name"
done
cp "$ROOT/macOS/install-photoshop-plugin.command" "$OUTPUT/Install Photoshop Bridge.command"
cp -R "$APP/Contents/Resources/Photoshop Bridge" "$OUTPUT/Photoshop Bridge"
(
  cd "$ROOT/integrations/photoshop-uxp-bridge"
  COPYFILE_DISABLE=1 /usr/bin/zip -q "$OUTPUT/SAI-AI-Studio-Photoshop-Bridge.ccx" manifest.json index.html main.js style.css
)
cp "$ROOT/macOS/README.md" "$OUTPUT/README.md"
chmod +x "$OUTPUT/Install Photoshop Bridge.command"
# 可选：只放分发者明确指定的邀请码，不复制 Windows 本机授权、设备密钥或 API Key。
if [[ -n "${INVITATION_FILE:-}" ]]; then
  [[ -f "$INVITATION_FILE" ]] || { echo 'Invitation file not found'; exit 1; }
  cp "$INVITATION_FILE" "$APP/Contents/MacOS/invitation.json"
fi
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>SAIStudio.Mac</string>
<key>CFBundleIdentifier</key><string>com.saiaistudio.mac</string>
<key>CFBundleName</key><string>SAI AI Studio</string>
<key>CFBundleDisplayName</key><string>SAI AI Studio</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleShortVersionString</key><string>$MARKETING_VERSION</string>
<key>CFBundleVersion</key><string>$BUNDLE_BUILD</string>
<key>SAIStudioSoftwareVersion</key><string>$VERSION</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSPrincipalClass</key><string>NSApplication</string>
<key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict></plist>
PLIST
plutil -lint "$APP/Contents/Info.plist"
# 使用稳定的 Developer ID 签名，可避免应用升级后钥匙串重复询问访问权限。
IDENTITY="${CODESIGN_IDENTITY:--}"
SIGN_ARGS=(--force --sign "$IDENTITY")
if [[ "$IDENTITY" != '-' ]]; then SIGN_ARGS+=(--timestamp --options runtime); fi
while IFS= read -r -d '' file; do
  if file -b "$file" | /usr/bin/grep -q 'Mach-O'; then codesign "${SIGN_ARGS[@]}" "$file"; fi
done < <(find "$APP/Contents/MacOS" -type f -print0)
codesign "${SIGN_ARGS[@]}" --entitlements "$ROOT/macOS/Entitlements.plist" "$APP"
codesign --verify --deep --strict "$APP"
# 发行前验证的是已编译进程序集的资源；缺失或无效则此处失败。
"$APP/Contents/MacOS/SAIStudio.Mac" --verify-bootstrap
if [[ "${VERIFY_NATIVE:-1}" == '1' ]]; then
  "$APP/Contents/MacOS/SAIStudio.Mac" --verify-native
fi
if [[ -n "${NOTARY_PROFILE:-}" ]]; then
  [[ "$IDENTITY" != '-' ]] || { echo 'Notarization requires a Developer ID signing identity.'; exit 1; }
  ditto -c -k --keepParent "$APP" "$OUTPUT/notarize.zip"
  xcrun notarytool submit "$OUTPUT/notarize.zip" --keychain-profile "$NOTARY_PROFILE" --wait
  xcrun stapler staple "$APP"
  xcrun stapler validate "$APP"
  spctl --assess --type execute --verbose=2 "$APP"
fi
ditto -c -k --keepParent "$APP" "$OUTPUT/SAI-AI-Studio-$VERSION-$RID.zip"
# 磁盘映像只包含交付文件，避免再把 ZIP 与中间产物重复装入 DMG。
DMG_STAGE="$OUTPUT/dmg-root"
mkdir -p "$DMG_STAGE"
ditto "$APP" "$DMG_STAGE/SAI AI Studio.app"
cp "$OUTPUT/Install Photoshop Bridge.command" "$DMG_STAGE/Install Photoshop Bridge.command"
cp -R "$OUTPUT/Photoshop Bridge" "$DMG_STAGE/Photoshop Bridge"
cp "$OUTPUT/SAI-AI-Studio-Photoshop-Bridge.ccx" "$DMG_STAGE/SAI-AI-Studio-Photoshop-Bridge.ccx"
cp "$OUTPUT/README.md" "$DMG_STAGE/README.md"
ln -s /Applications "$DMG_STAGE/Applications"
DMG="$OUTPUT/SAI-AI-Studio-$VERSION-$RID.dmg"
hdiutil create -volname 'SAI AI Studio' -srcfolder "$DMG_STAGE" -ov -format UDZO "$DMG"
if [[ "$IDENTITY" != '-' ]]; then
  codesign --force --sign "$IDENTITY" --timestamp "$DMG"
fi
if [[ -n "${NOTARY_PROFILE:-}" ]]; then
  xcrun notarytool submit "$DMG" --keychain-profile "$NOTARY_PROFILE" --wait
  xcrun stapler staple "$DMG"
  xcrun stapler validate "$DMG"
fi
printf '\nBuild completed: %s\n' "$OUTPUT"
